import re
from Sastrawi.Stemmer.StemmerFactory import StemmerFactory

class TextPreprocessor:
    def __init__(self):
        # Hanya gunakan stemmer, NONAKTIFKAN stopword remover Sastrawi
        self.stemmer = StemmerFactory().create_stemmer()
        
        # Custom normalization untuk typo & istilah cybersecurity
        self.normalization_dict = {
            'phising': 'phishing',
            'pishing': 'phishing',
            'fisyhing': 'phishing',
            'pising': 'phishing',
            'malwer': 'malware',
            'malwere': 'malware',
            'malware': 'malware',
            'firewol': 'firewall',
            'antivrus': 'antivirus',
            'enkripsi': 'encryption',
            'dekripsi': 'decryption',
            'ransomwer': 'ransomware',
            'ransomware': 'ransomware',
            'ddoss': 'ddos',
            'dos': 'ddos',
            'sosial': 'social',
            'enggenering': 'engineering',
            'heker': 'hacker',
            'hacker': 'hacker',
            'pasword': 'password',
            'passwod': 'password'
        }
        
        # Stopwords kustom (kata yang benar-benar tidak penting)
        self.custom_stopwords = {
            'apa', 'adalah', 'itu', 'ya', 'sih', 'dong', 
            'yah', 'kan', 'lah', 'kah', 'pun'
        }
    
    def normalize_text(self, text):
        """Normalisasi typo dan istilah cybersecurity"""
        text_lower = text.lower()
        words = text_lower.split()
        normalized_words = []
        for word in words:
            normalized_word = self.normalization_dict.get(word, word)
            normalized_words.append(normalized_word)
        return ' '.join(normalized_words)
    
    def clean_text(self, text):
        """Pembersihan teks dasar"""
        text = text.lower()
        text = re.sub(r'http\S+|www\S+', '', text)  # Hapus URL
        text = re.sub(r'\S+@\S+', '', text)         # Hapus email
        text = re.sub(r'[^a-z\s]', ' ', text)       # Hanya huruf dan spasi
        text = re.sub(r'\s+', ' ', text).strip()    # Normalisasi spasi
        return text
    
    def preprocess(self, text, remove_stopwords=True, apply_stemming=True):
        """Pipeline preprocessing lengkap"""
        if not text or text.strip() == '':
            return ''
        
        # 1. Normalisasi typo & istilah
        text = self.normalize_text(text)
        
        # 2. Pembersihan dasar
        text = self.clean_text(text)
        
        # 3. Hapus stopwords kustom (TANPA Sastrawi)
        if remove_stopwords:
            words = text.split()
            # Pertahankan kata sapaan seperti 'halo', 'hai', 'hi'
            greeting_words = {'halo', 'hai', 'hi', 'hello', 'hei', 'helo', 'yo', 'sup'}
            words = [
                w for w in words 
                if w in greeting_words or (w not in self.custom_stopwords and len(w) > 2)
]
            text = ' '.join(words)
            # ❌ JANGAN GUNAKAN: self.stopword_remover.remove(text)
        
        # 4. Stemming (opsional)
        if apply_stemming:
            text = self.stemmer.stem(text)
        
        return text.strip()