import json

# Baca file dengan encoding eksplisit
with open('intent_training_data_expanded.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

greetings = data.get('greeting', [])
print("Jumlah greeting:", len(greetings))
print("5 contoh pertama:")
for i, g in enumerate(greetings[:5]):
    print(f"  {i+1}. '{g}' (panjang: {len(g)})")