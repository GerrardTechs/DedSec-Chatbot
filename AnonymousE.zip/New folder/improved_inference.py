"""
═══════════════════════════════════════════════════════════════════════════════
🤖 IMPROVED CYBERSECURITY CHATBOT - INFERENCE ENGINE
═══════════════════════════════════════════════════════════════════════════════
Features:
- Unified preprocessing
- Confidence-based responses
- Semantic similarity fallback
- Conversation context tracking
- Multi-turn support
- Spell correction
- Active learning logging
═══════════════════════════════════════════════════════════════════════════════
"""

import joblib
import json
import numpy as np
import re
from datetime import datetime
from collections import deque
import warnings
warnings.filterwarnings('ignore')
from preprocessing import TextPreprocessor

# Optional: Semantic similarity
try:
    from sentence_transformers import SentenceTransformer, util
    SEMANTIC_AVAILABLE = True
except ImportError:
    SEMANTIC_AVAILABLE = False

# Indonesian NLP
try:
    from Sastrawi.Stemmer.StemmerFactory import StemmerFactory
    from Sastrawi.StopWordRemover.StopWordRemoverFactory import StopWordRemoverFactory
    SASTRAWI_AVAILABLE = True
except ImportError:
    SASTRAWI_AVAILABLE = False
    print("⚠️ Sastrawi not installed. Install: pip install Sastrawi")

# ═══════════════════════════════════════════════════════════════════════════
# 🔧 CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════

class ChatbotConfig:
    # Thresholds
    CONFIDENCE_HIGH = 0.75      # High confidence → direct answer
    CONFIDENCE_MEDIUM = 0.50    # Medium → ask clarification
    CONFIDENCE_LOW = 0.30       # Low → fallback response
    
    # Semantic similarity
    SEMANTIC_THRESHOLD = 0.70
    
    # Context
    MAX_CONTEXT_TURNS = 5
    
    # Model paths
    MODEL_DIR = 'model_improved/'
    RESPONSE_FILE = 'dataset_augmented.json'
    
    # Logging
    LOG_UNCERTAIN = True
    LOG_FEEDBACK = True

config = ChatbotConfig()

# ═══════════════════════════════════════════════════════════════════════════
# 📦 LOAD MODELS & DATA
# ═══════════════════════════════════════════════════════════════════════════

class ModelLoader:
    """Load all necessary models and data"""
    
    def __init__(self, model_dir=config.MODEL_DIR):
        print("\n" + "="*80)
        print("🤖 LOADING CYBERSECURITY CHATBOT")
        print("="*80)
        
        try:
            # Load ML model
            self.model = joblib.load(f'{model_dir}/intent_model.pkl')
            print("✅ Loaded: Intent Model")
            
            # Load vectorizer
            self.vectorizer = joblib.load(f'{model_dir}/vectorizer.pkl')
            print("✅ Loaded: TF-IDF Vectorizer")
            
            # Load preprocessor
            self.preprocessor = joblib.load(f'{model_dir}/preprocessor.pkl')
            print("✅ Loaded: Text Preprocessor")
            
            # Load metadata
            with open(f'{model_dir}/metadata.json', 'r', encoding='utf-8') as f:
                self.metadata = json.load(f)
            print("✅ Loaded: Model Metadata")
            
            # Load responses
            with open(config.RESPONSE_FILE, 'r', encoding='utf-8') as f:
                self.responses = json.load(f)
            print("✅ Loaded: Response Dataset")
            
            # Load semantic model (optional)
            self.semantic_model = None
            if SEMANTIC_AVAILABLE:
                try:
                    self.semantic_model = SentenceTransformer(
                        'paraphrase-multilingual-MiniLM-L12-v2'
                    )
                    print("✅ Loaded: Semantic Similarity Model")
                except Exception as e:
                    print(f"⚠️ Semantic model unavailable: {e}")
            
            print(f"\n📊 Model Info:")
            print(f"   Model Type: {self.metadata['model_type']}")
            print(f"   Accuracy: {self.metadata['accuracy']:.2%}")
            print(f"   Intents: {self.metadata['n_intents']}")
            print(f"   Training Date: {self.metadata['training_date']}")
            print("="*80 + "\n")
            
        except Exception as e:
            print(f"\n❌ Error loading models: {e}")
            print("💡 Make sure you've run improved_training.py first!")
            raise

# ═══════════════════════════════════════════════════════════════════════════
# 💬 CONVERSATION CONTEXT MANAGER
# ═══════════════════════════════════════════════════════════════════════════

class ConversationContext:
    """Manage conversation history and context"""
    
    def __init__(self, max_turns=config.MAX_CONTEXT_TURNS):
        self.history = deque(maxlen=max_turns)
        self.current_topic = None
        self.follow_up_count = 0
    
    def add_turn(self, user_input, intent, response, confidence):
        """Add a conversation turn"""
        turn = {
            'user': user_input,
            'intent': intent,
            'response': response,
            'confidence': confidence,
            'timestamp': datetime.now()
        }
        self.history.append(turn)
        
        # Update topic tracking
        if intent not in ['greeting', 'thanks', 'unknown']:
            if intent == self.current_topic:
                self.follow_up_count += 1
            else:
                self.current_topic = intent
                self.follow_up_count = 0
    
    def get_recent_intents(self, n=3):
        """Get last N intents"""
        if len(self.history) == 0:
            return []
        return [turn['intent'] for turn in list(self.history)[-n:]]
    
    def is_follow_up(self, query):
        """Detect if query is a follow-up question"""
        follow_up_indicators = [
            'itu', 'tersebut', 'tadi', 'yang kamu bilang',
            'lebih lanjut', 'lagi', 'juga', 'contoh lain',
            'gimana kalau', 'terus', 'lalu'
        ]
        
        query_lower = query.lower()
        return any(indicator in query_lower for indicator in follow_up_indicators)
    
    def resolve_reference(self, query):
        """Resolve references in follow-up questions"""
        if self.is_follow_up(query) and self.current_topic:
            # Add context to query
            return f"{query} {self.current_topic}"
        return query
    
    def clear(self):
        """Clear conversation history"""
        self.history.clear()
        self.current_topic = None
        self.follow_up_count = 0

# ═══════════════════════════════════════════════════════════════════════════
# 🎯 INTENT PREDICTION ENGINE
# ═══════════════════════════════════════════════════════════════════════════

class IntentPredictor:
    """Predict intent with multiple strategies"""
    
    def __init__(self, model_loader):
        self.ml_model = model_loader.model
        self.vectorizer = model_loader.vectorizer
        self.preprocessor = model_loader.preprocessor
        self.semantic_model = model_loader.semantic_model
        self.intents = model_loader.metadata['intents']
    
    def predict_ml(self, text):
        """Predict using ML model"""
        
        # Preprocess
        # Di dalam fungsi predict_ml(self, text):
        text_clean = self.preprocessor.preprocess(text)
        print(f"[DEBUG] Input: '{text}' → Preprocessed: '{text_clean}'")

        # DEBUG: Cek apakah 'halo' ada di vocabulary
        if "halo" in self.vectorizer.vocabulary_:
            print("✅ 'halo' dikenali oleh vectorizer")
        else:
            print("❌ 'halo' TIDAK dikenali oleh vectorizer!")
            print("Mungkin kamu belum training ulang setelah ubah preprocessing.")

        if not text_clean or len(text_clean.split()) < 2:
            return None, 0.0, []
        
        # Vectorize
        text_vec = self.vectorizer.transform([text_clean])
        
        text_vec = self.vectorizer.transform([text_clean])
        print(f"[DEBUG] Vector shape: {text_vec.shape}")
        print(f"[DEBUG] Non-zero elements: {text_vec.nnz}")

        # Cek nilai fitur untuk "halo"
        feature_idx = self.vectorizer.vocabulary_.get("halo")
        if feature_idx is not None:
            val = text_vec[0, feature_idx]
            print(f"[DEBUG] TF-IDF value for 'halo': {val}")
            
        # Predict
        intent = self.ml_model.predict(text_vec)[0]
        
        # Get probabilities
        if hasattr(self.ml_model, 'predict_proba'):
            probabilities = self.ml_model.predict_proba(text_vec)[0]
        else:
            # For models without predict_proba
            decision = self.ml_model.decision_function(text_vec)[0]
            exp_scores = np.exp(decision - np.max(decision))
            probabilities = exp_scores / exp_scores.sum()
        
        confidence = np.max(probabilities)
        
        # Get top intents
        top_intents = []
        for i, prob in enumerate(probabilities):
            if hasattr(self.ml_model, 'classes_'):
                intent_name = self.ml_model.classes_[i]
            else:
                intent_name = self.intents[i]
            top_intents.append((intent_name, prob))
        
        top_intents.sort(key=lambda x: x[1], reverse=True)
        
        return intent, confidence, top_intents[:3]
    
    def predict_semantic(self, text, training_examples):
        """Predict using semantic similarity (fallback)"""
        if not self.semantic_model:
            return None, 0.0
        
        # Encode query
        query_embedding = self.semantic_model.encode([text])[0]
        
        # Encode training examples
        example_texts = [ex['text'] for ex in training_examples]
        example_embeddings = self.semantic_model.encode(example_texts)
        
        # Calculate similarities
        similarities = util.cos_sim(query_embedding, example_embeddings)[0]
        
        # Find best match
        best_idx = similarities.argmax()
        best_similarity = similarities[best_idx].item()
        best_intent = training_examples[best_idx]['intent']
        
        return best_intent, best_similarity
    
    def predict_hybrid(self, text, context=None):
        """
        Hybrid prediction: ML + Semantic fallback + Context
        
        Returns: {
            'intent': predicted intent,
            'confidence': confidence score,
            'method': prediction method used,
            'top_intents': list of (intent, score) tuples
        }
        """
        # 1. Try ML model
        ml_intent, ml_confidence, top_intents = self.predict_ml(text)
        
        # Handle invalid input
        if ml_intent is None:
            return {
                'intent': 'unknown',
                'confidence': 0.0,
                'method': 'invalid_input',
                'top_intents': []
            }
        
        # 2. If high confidence, use ML result
        if ml_confidence >= config.CONFIDENCE_HIGH:
            return {
                'intent': ml_intent,
                'confidence': ml_confidence,
                'method': 'ml_model',
                'top_intents': top_intents
            }
        
        # 3. If medium confidence, check with context
        if ml_confidence >= config.CONFIDENCE_MEDIUM:
            # Use context to boost confidence if relevant
            if context and context.current_topic:
                if ml_intent == context.current_topic:
                    # Boost confidence for contextually relevant intent
                    boosted_confidence = min(ml_confidence + 0.1, 0.95)
                    return {
                        'intent': ml_intent,
                        'confidence': boosted_confidence,
                        'method': 'ml_with_context',
                        'top_intents': top_intents
                    }
            
            return {
                'intent': ml_intent,
                'confidence': ml_confidence,
                'method': 'ml_model',
                'top_intents': top_intents
            }
        
        # 4. Low confidence → try semantic fallback
        # TODO: Implement semantic fallback with training examples
        # For now, return ML result with low confidence flag
        
        return {
            'intent': ml_intent,
            'confidence': ml_confidence,
            'method': 'low_confidence',
            'top_intents': top_intents
        }

# ═══════════════════════════════════════════════════════════════════════════
# 💬 RESPONSE GENERATOR
# ═══════════════════════════════════════════════════════════════════════════

class ResponseGenerator:
    """Generate appropriate responses based on intent and context"""
    
    def __init__(self, responses_data):
        self.responses = responses_data
    
    def detect_question_type(self, text):
        """Detect what type of question is being asked"""
        text_lower = text.lower()
        
        if any(k in text_lower for k in ["contoh", "misalnya", "misal", "seperti"]):
            return "example"
        elif any(k in text_lower for k in ["cara kerja", "gimana", "bagaimana", "proses"]):
            return "process"
        elif any(k in text_lower for k in ["bahaya", "dampak", "berbahaya", "efek", "akibat"]):
            return "impact"
        elif any(k in text_lower for k in ["hindari", "mencegah", "solusi", "atasi", "proteksi"]):
            return "mitigation"
        elif any(k in text_lower for k in ["beda", "perbedaan", "vs", "versus", "dibanding"]):
            return "comparison"
        else:
            return "definition"
    
    def get_response(self, intent, query, confidence):
        """Get appropriate response for intent"""
        
        preprocessor = TextPreprocessor()
        cleaned_input = preprocessor.preprocess(
        query, 
        remove_stopwords=True,
        apply_stemming=True
        )

        # Handle special intents
        if intent == 'greeting':
            greetings = self.responses.get('greeting', {}).get('basic', [])
            if greetings:
                return np.random.choice(greetings)
            return "Halo! Ada yang bisa saya bantu tentang cybersecurity?"
        
        if intent == 'unknown' or confidence < config.CONFIDENCE_LOW:
            return self.get_fallback_response()
        
        # Get intent data
        intent_data = self.responses.get(intent, {})
        
        if not intent_data:
            return "Maaf, saya belum memiliki informasi tentang topik ini."
        
        # Detect question type
        question_type = self.detect_question_type(query)
        
        # Get response for question type
        response_list = intent_data.get(question_type, [])
        
        # Fallback to definition if question type not available
        if not response_list:
            response_list = intent_data.get('definition', [])
        
        # Fallback to any available response
        if not response_list:
            for key in intent_data:
                if isinstance(intent_data[key], list) and intent_data[key]:
                    response_list = intent_data[key]
                    break
        
        if response_list:
            return np.random.choice(response_list)
        
        return "Maaf, saya belum memiliki jawaban detail untuk pertanyaan ini."
    
    def get_fallback_response(self, top_intents=None):
        """Generate intelligent fallback response"""
        response = [
            "🤔 Maaf, saya kurang yakin dengan pertanyaan Anda.",
            "\n💡 Beberapa topik yang bisa saya bantu:",
        ]
        
        topics = [
            "• Phishing dan Social Engineering",
            "• Malware dan Ransomware",
            "• Password Security dan Encryption",
            "• Network Security dan Firewall",
            "• DDoS, SQL Injection, XSS",
            "• Incident Response",
            "• Security Tools (SIEM, IDS/IPS)"
        ]
        
        response.extend(topics)
        
        if top_intents:
            response.append("\n🎯 Atau mungkin maksud Anda:")
            for intent, score in top_intents[:3]:
                display_name = intent.replace('_', ' ').title()
                response.append(f"   - {display_name} ({score:.1%})")
        
        return '\n'.join(response)
    
    def get_clarification_response(self, top_intents):
        """Ask for clarification when confidence is medium"""
        response = [
            "🤔 Apakah yang Anda maksud adalah:\n"
        ]
        
        for i, (intent, score) in enumerate(top_intents[:3], 1):
            display_name = intent.replace('_', ' ').title()
            response.append(f"{i}. {display_name} ({score:.1%})")
        
        response.append("\nSilakan ketik nomor atau jelaskan lebih detail.")
        
        return '\n'.join(response)

# ═══════════════════════════════════════════════════════════════════════════
# 📊 ACTIVE LEARNING LOGGER
# ═══════════════════════════════════════════════════════════════════════════

class ActiveLearner:
    """Log uncertain predictions for model improvement"""
    
    def __init__(self):
        self.uncertain_log = []
        self.feedback_log = []
    
    def log_uncertain(self, query, intent, confidence, top_intents):
        """Log prediction dengan confidence rendah"""
        self.uncertain_log.append({
            'query': query,
            'predicted_intent': intent,
            'confidence': confidence,
            'top_intents': [(i, f"{s:.2f}") for i, s in top_intents],
            'timestamp': datetime.now().isoformat()
        })
    
    def log_feedback(self, query, predicted_intent, correct_intent, confidence):
        """Log user feedback/corrections"""
        self.feedback_log.append({
            'query': query,
            'predicted': predicted_intent,
            'correct': correct_intent,
            'confidence': confidence,
            'timestamp': datetime.now().isoformat()
        })
    
    def save_logs(self):
        """Save logs to files"""
        if self.uncertain_log:
            with open('uncertain_predictions.json', 'w', encoding='utf-8') as f:
                json.dump(self.uncertain_log, f, indent=2, ensure_ascii=False)
            print(f"💾 Saved {len(self.uncertain_log)} uncertain predictions")
        
        if self.feedback_log:
            with open('user_feedback.json', 'w', encoding='utf-8') as f:
                json.dump(self.feedback_log, f, indent=2, ensure_ascii=False)
            print(f"💾 Saved {len(self.feedback_log)} user feedbacks")

# ═══════════════════════════════════════════════════════════════════════════
# 🤖 MAIN CHATBOT CLASS
# ═══════════════════════════════════════════════════════════════════════════

class CybersecurityChatbot:
    """Main chatbot interface"""
    
    def __init__(self):
        # Load models
        self.loader = ModelLoader()
        
        # Initialize components
        self.predictor = IntentPredictor(self.loader)
        self.responder = ResponseGenerator(self.loader.responses)
        self.context = ConversationContext()
        self.learner = ActiveLearner()
    
    def chat(self, user_input):
        """
        Main chat function
        
        Returns: {
            'response': bot response text,
            'intent': predicted intent,
            'confidence': confidence score,
            'method': prediction method,
            'status': response status
        }
        """
        # Resolve context references
        resolved_input = self.context.resolve_reference(user_input)
        
        # Predict intent
        prediction = self.predictor.predict_hybrid(resolved_input, self.context)
        
        intent = prediction['intent']
        confidence = prediction['confidence']
        method = prediction['method']
        top_intents = prediction['top_intents']
        
        # Generate response based on confidence
        if confidence >= config.CONFIDENCE_HIGH:
            # High confidence → direct answer
            response = self.responder.get_response(intent, user_input, confidence)
            status = 'success'
            
        elif confidence >= config.CONFIDENCE_MEDIUM:
            # Medium confidence → clarification
            response = self.responder.get_clarification_response(top_intents)
            status = 'clarification'
            
        else:
            # Low confidence → fallback
            response = self.responder.get_fallback_response(top_intents)
            status = 'fallback'
            
            # Log for active learning
            if config.LOG_UNCERTAIN:
                self.learner.log_uncertain(user_input, intent, confidence, top_intents)
        
        # Update context
        self.context.add_turn(user_input, intent, response, confidence)
        
        return {
            'response': response,
            'intent': intent,
            'confidence': confidence,
            'method': method,
            'status': status,
            'top_intents': top_intents
        }
    
    def reset_context(self):
        """Reset conversation context"""
        self.context.clear()
    
    def save_session(self):
        """Save session data"""
        self.learner.save_logs()

# ═══════════════════════════════════════════════════════════════════════════
# 🎮 INTERACTIVE DEMO
# ═══════════════════════════════════════════════════════════════════════════

def run_interactive_demo():
    """Run interactive chatbot demo"""
    
    print("\n" + "="*80)
    print("💬 CYBERSECURITY CHATBOT - INTERACTIVE MODE")
    print("="*80)
    print("\n🤖 Halo! Saya chatbot cybersecurity yang telah ditingkatkan.")
    print("   Saya dapat membantu Anda dengan pertanyaan seputar keamanan siber.")
    print("\n💡 Commands:")
    print("   • 'exit', 'quit', 'keluar' → Exit chatbot")
    print("   • 'reset' → Reset conversation context")
    print("   • 'help' → Show example questions")
    print("="*80 + "\n")
    
    # Initialize chatbot
    chatbot = CybersecurityChatbot()
    
    try:
        while True:
            # Get user input
            user_input = input("👤 You: ").strip()
            
            # Handle commands
            if not user_input:
                continue
            
            if user_input.lower() in ['exit', 'quit', 'keluar', 'bye']:
                print("\n🤖 Bot: Terima kasih! Tetap waspada terhadap ancaman cyber! 🔒")
                chatbot.save_session()
                break
            
            if user_input.lower() == 'reset':
                chatbot.reset_context()
                print("\n🤖 Bot: Conversation context direset. Mari mulai dari awal!\n")
                continue
            
            if user_input.lower() == 'help':
                print("\n🤖 Bot: Contoh pertanyaan yang bisa saya jawab:")
                print("   • 'Apa itu phishing?'")
                print("   • 'Bagaimana cara kerja ransomware?'")
                print("   • 'Apa bedanya malware dan virus?'")
                print("   • 'Bagaimana cara mencegah DDoS attack?'")
                print("   • 'Apa itu SQL injection?'")
                print("   • 'Jelaskan tentang social engineering'")
                print("   • 'Tools apa saja untuk security testing?'\n")
                continue
            
            # Get chatbot response
            result = chatbot.chat(user_input)
            
            # Display response
            print(f"\n🤖 Bot: {result['response']}")
            
            # Display metadata (untuk debugging)
            if result['status'] == 'success':
                print(f"\n📊 [Intent: {result['intent']} | "
                      f"Confidence: {result['confidence']:.1%} | "
                      f"Method: {result['method']}]")
            elif result['status'] in ['clarification', 'fallback']:
                print(f"\n⚠️ [Confidence: {result['confidence']:.1%}]")
            
            print()  # Empty line
    
    except KeyboardInterrupt:
        print("\n\n👋 Interrupted. Saving session...")
        chatbot.save_session()
    except Exception as e:
        print(f"\n❌ Error: {e}")
        chatbot.save_session()

# ═══════════════════════════════════════════════════════════════════════════
# 🚀 MAIN EXECUTION
# ═══════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    run_interactive_demo()