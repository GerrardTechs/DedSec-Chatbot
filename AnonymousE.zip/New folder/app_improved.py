"""
═══════════════════════════════════════════════════════════════════════════════
🚀 IMPROVED CYBERSECURITY CHATBOT - STREAMLIT WEB APP (FIXED VERSION)
═══════════════════════════════════════════════════════════════════════════════
"""

import streamlit as st
import json
from datetime import datetime
import pandas as pd

# ═══════════════════════════════════════════════════════════════════════════
# 🔧 IMPORT CHATBOT (WITH ERROR HANDLING)
# ═══════════════════════════════════════════════════════════════════════════

IMPROVED_AVAILABLE = False
CybersecurityChatbot = None
config = None

try:
    # Import dari improved_inference.py
    from improved_inference import CybersecurityChatbot, config
    IMPROVED_AVAILABLE = True
except ImportError as e:
    st.error(f"⚠️ Error importing: {e}")
except Exception as e:
    st.error(f"⚠️ Unexpected error: {e}")

# ═══════════════════════════════════════════════════════════════════════════
# 🎨 PAGE CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════

st.set_page_config(
    page_title="Cybersecurity Chatbot - Improved",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        color: #1e88e5;
        text-align: center;
        padding: 1rem 0;
    }
    
    .info-box {
        padding: 1rem;
        background-color: #d1ecf1;
        border-left: 4px solid #17a2b8;
        border-radius: 5px;
        margin: 1rem 0;
    }
    
    .success-box {
        padding: 1rem;
        background-color: #d4edda;
        border-left: 4px solid #28a745;
        border-radius: 5px;
        margin: 1rem 0;
    }
    
    .warning-box {
        padding: 1rem;
        background-color: #fff3cd;
        border-left: 4px solid #ffc107;
        border-radius: 5px;
        margin: 1rem 0;
    }
</style>
""", unsafe_allow_html=True)

# ═══════════════════════════════════════════════════════════════════════════
# 📊 SESSION STATE INITIALIZATION
# ═══════════════════════════════════════════════════════════════════════════

def init_session_state():
    """Initialize session state variables"""
    if 'chatbot' not in st.session_state:
        if IMPROVED_AVAILABLE:
            try:
                st.session_state.chatbot = CybersecurityChatbot()
            except Exception as e:
                st.session_state.chatbot = None
                st.error(f"Error initializing chatbot: {e}")
        else:
            st.session_state.chatbot = None
    
    if 'messages' not in st.session_state:
        st.session_state.messages = []
    
    if 'conversation_count' not in st.session_state:
        st.session_state.conversation_count = 0
    
    if 'show_debug' not in st.session_state:
        st.session_state.show_debug = False

init_session_state()

# ═══════════════════════════════════════════════════════════════════════════
# 🎯 SIDEBAR
# ═══════════════════════════════════════════════════════════════════════════

with st.sidebar:
    st.markdown("## ⚙️ Settings")
    
    # Model Info
    if IMPROVED_AVAILABLE and st.session_state.chatbot:
        st.markdown("### 📊 Model Info")
        try:
            metadata = st.session_state.chatbot.loader.metadata
            
            col1, col2 = st.columns(2)
            with col1:
                st.metric("Accuracy", f"{metadata['accuracy']:.1%}")
            with col2:
                st.metric("Intents", metadata['n_intents'])
            
            st.info(f"🤖 {metadata['model_type'].title()}")
        except:
            st.warning("Model metadata not available")
    
    st.markdown("---")
    
    # Debug Mode
    st.markdown("### 🔧 Options")
    st.session_state.show_debug = st.checkbox("Show Debug Info", value=False)
    
    # Thresholds Info
    if config:
        st.markdown("### 🎯 Thresholds")
        st.write(f"- High: {config.CONFIDENCE_HIGH:.0%}")
        st.write(f"- Medium: {config.CONFIDENCE_MEDIUM:.0%}")
        st.write(f"- Low: {config.CONFIDENCE_LOW:.0%}")
    
    st.markdown("---")
    
    # Stats
    st.markdown("### 📈 Stats")
    st.metric("Queries", st.session_state.conversation_count)
    st.metric("Messages", len(st.session_state.messages))
    
    # Clear Chat
    if st.button("🗑️ Clear Chat", use_container_width=True):
        st.session_state.messages = []
        st.session_state.conversation_count = 0
        if st.session_state.chatbot:
            st.session_state.chatbot.reset_context()
        st.rerun()
    
    # Export
    if st.session_state.messages:
        if st.button("💾 Export", use_container_width=True):
            export_data = {
                'timestamp': datetime.now().isoformat(),
                'messages': st.session_state.messages
            }
            json_str = json.dumps(export_data, indent=2, ensure_ascii=False)
            st.download_button(
                "📥 Download",
                json_str,
                f"chat_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
                "application/json",
                use_container_width=True
            )
    
    st.markdown("---")
    
    # Help
    with st.expander("❓ Help"):
        st.markdown("""
        **Contoh:**
        - Apa itu phishing?
        - Cara kerja ransomware?
        - Bedanya malware vs virus?
        - Tips password aman
        
        **Fitur:**
        - 30+ topik
        - Context-aware
        - Typo handling
        - 85%+ accuracy
        """)

# ═══════════════════════════════════════════════════════════════════════════
# 🎨 MAIN CONTENT
# ═══════════════════════════════════════════════════════════════════════════

st.markdown('<p class="main-header">🛡️ Cybersecurity Chatbot</p>', unsafe_allow_html=True)

# Welcome banner
if not st.session_state.messages:
    st.markdown("""
    <div class="info-box">
        <h4>👋 Welcome!</h4>
        <p>Saya chatbot cybersecurity yang telah ditingkatkan:</p>
        <ul>
            <li>✅ 30+ topik cybersecurity</li>
            <li>✅ 85%+ accuracy</li>
            <li>✅ Context-aware conversations</li>
            <li>✅ Typo & spell correction</li>
        </ul>
        <p>💬 Tanyakan apa saja!</p>
    </div>
    """, unsafe_allow_html=True)

# Check availability
if not IMPROVED_AVAILABLE or not st.session_state.chatbot:
    st.error("""
    ⚠️ **Chatbot tidak tersedia!**
    
    **Troubleshooting:**
    1. Pastikan file `improved_inference.py` ada di folder yang sama
    2. Jalankan training: `python improved_training.py`
    3. Pastikan folder `model_improved/` sudah dibuat
    4. Check error message di atas
    """)
    st.stop()

# Display messages
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])
        
        # Debug info
        if st.session_state.show_debug and msg["role"] == "assistant" and "metadata" in msg:
            meta = msg["metadata"]
            st.caption(
                f"🔍 Intent: `{meta.get('intent')}` | "
                f"Conf: `{meta.get('confidence', 0):.1%}` | "
                f"Method: `{meta.get('method')}` | "
                f"Status: `{meta.get('status')}`"
            )

# ═══════════════════════════════════════════════════════════════════════════
# 💬 CHAT INPUT
# ═══════════════════════════════════════════════════════════════════════════

user_input = st.chat_input("Tanyakan seputar cybersecurity...")

if user_input:
    # Add user message
    st.session_state.messages.append({
        "role": "user",
        "content": user_input,
        "timestamp": datetime.now().isoformat()
    })
    
    # Display user message
    with st.chat_message("user"):
        st.markdown(user_input)
    
    # Get bot response
    with st.chat_message("assistant"):
        with st.spinner("🤔 Thinking..."):
            try:
                result = st.session_state.chatbot.chat(user_input)
            except Exception as e:
                result = {
                    'response': f"❌ Error: {str(e)}",
                    'intent': 'error',
                    'confidence': 0.0,
                    'method': 'error',
                    'status': 'error'
                }
        
        # Display response
        st.markdown(result['response'])
        
        # Debug info
        if st.session_state.show_debug:
            st.caption(
                f"🔍 Intent: `{result['intent']}` | "
                f"Conf: `{result['confidence']:.1%}` | "
                f"Method: `{result['method']}` | "
                f"Status: `{result['status']}`"
            )
        
        # Confidence indicator
        confidence = result['confidence']
        if config:
            if confidence >= config.CONFIDENCE_HIGH:
                st.success("✅ High confidence")
            elif confidence >= config.CONFIDENCE_MEDIUM:
                st.warning("⚠️ Medium confidence")
            else:
                st.info("💡 Low confidence")
    
    # Add to history
    st.session_state.messages.append({
        "role": "assistant",
        "content": result['response'],
        "timestamp": datetime.now().isoformat(),
        "metadata": {
            "intent": result['intent'],
            "confidence": result['confidence'],
            "method": result['method'],
            "status": result['status']
        }
    })
    
    st.session_state.conversation_count += 1
    st.rerun()

# ═══════════════════════════════════════════════════════════════════════════
# 📊 FEEDBACK
# ═══════════════════════════════════════════════════════════════════════════

if st.session_state.messages and len(st.session_state.messages) >= 2:
    st.markdown("---")
    
    col1, col2, col3 = st.columns([2, 1, 1])
    
    with col1:
        st.markdown("### 💬 Feedback")
        st.write("Apakah jawaban membantu?")
    
    with col2:
        if st.button("👍 Helpful", use_container_width=True):
            st.success("Thanks for feedback!")
    
    with col3:
        if st.button("👎 Not Helpful", use_container_width=True):
            st.info("We'll improve!")

# ═══════════════════════════════════════════════════════════════════════════
# 🚀 QUICK ACTIONS
# ═══════════════════════════════════════════════════════════════════════════

st.markdown("---")
st.markdown("### 🚀 Quick Examples")

col1, col2, col3, col4 = st.columns(4)

examples = {
    "💡 Phishing": "apa itu phishing dan cara mencegahnya?",
    "💡 Ransomware": "jelaskan tentang ransomware",
    "💡 Password": "tips password yang aman",
    "💡 VPN": "apa fungsi vpn?"
}

for i, (col, (label, query)) in enumerate(zip([col1, col2, col3, col4], examples.items())):
    with col:
        if st.button(label, use_container_width=True, key=f"example_{i}"):
            # Simulate user input
            st.session_state.example_query = query
            st.rerun()

# ═══════════════════════════════════════════════════════════════════════════
# 📌 FOOTER
# ═══════════════════════════════════════════════════════════════════════════

st.markdown("---")
st.markdown("""
<div style='text-align: center; color: #666; padding: 1rem;'>
    <p>🛡️ <b>Cybersecurity Chatbot v2.0</b></p>
    <p>30+ Topics | 85%+ Accuracy | Context-Aware</p>
</div>
""", unsafe_allow_html=True)