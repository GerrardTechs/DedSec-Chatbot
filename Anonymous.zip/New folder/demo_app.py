import streamlit as st
import pickle

st.set_page_config(page_title="Cybersecurity Chatbot")

tfidf = pickle.load(open("tfidf_vectorizer.pkl", "rb"))
model = pickle.load(open("chatbot_model.pkl", "rb"))
responses = pickle.load(open("intent_responses.pkl", "rb"))

st.title("🤖 Cybersecurity Chatbot")

user_input = st.text_input("Tanyakan sesuatu tentang cybersecurity:")

if user_input:
    X = tfidf.transform([user_input])
    intent = model.predict(X)[0]
    response = responses[intent][0]

    st.markdown(f"**Intent:** `{intent}`")
    st.success(response)
