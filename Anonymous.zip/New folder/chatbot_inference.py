"""
╔══════════════════════════════════════════════════════════════════════════════╗
║         CYBERSECURITY CHATBOT - INFERENCE & DEMO                            ║
║         With Confidence Score & Intelligent Fallback                        ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import pickle
import numpy as np
import re
from datetime import datetime
from Sastrawi.Stemmer.StemmerFactory import StemmerFactory
from nltk.corpus import stopwords
import warnings
warnings.filterwarnings('ignore')

# ═══════════════════════════════════════════════════════════════════════════
# 🔧 CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════

CONFIDENCE_THRESHOLD = 0.80  # 80% confidence threshold
MIN_TEXT_LENGTH = 2          # Minimum 2 words

# ═══════════════════════════════════════════════════════════════════════════
# 📦 LOAD MODELS & ARTIFACTS
# ═══════════════════════════════════════════════════════════════════════════

print("\n" + "="*80)
print("🤖 LOADING CYBERSECURITY CHATBOT")
print("="*80)

# Load TF-IDF vectorizer
with open('tfidf_vectorizer.pkl', 'rb') as f:
    tfidf = pickle.load(f)
print("✅ Loaded: TF-IDF Vectorizer")

# Load trained model
with open('chatbot_model.pkl', 'rb') as f:
    model = pickle.load(f)
print("✅ Loaded: Trained Model")

# Load intent-response mapping
with open('intent_responses.pkl', 'rb') as f:
    intent_responses = pickle.load(f)
print("✅ Loaded: Intent Responses")

# Load metadata
with open('model_metadata.pkl', 'rb') as f:
    metadata = pickle.load(f)
print("✅ Loaded: Model Metadata")

print(f"\n📊 Model Information:")
print(f"   • Model: {metadata['model_name']}")
print(f"   • Accuracy: {metadata['accuracy']:.2%}")
print(f"   • Intents: {metadata['n_intents']}")
print(f"   • Training Samples: {metadata['n_samples']}")

# ═══════════════════════════════════════════════════════════════════════════
# 🧹 TEXT PREPROCESSING
# ═══════════════════════════════════════════════════════════════════════════

stop_words = set(stopwords.words('indonesian'))
stemmer = StemmerFactory().create_stemmer()

custom_stopwords = {'apa', 'adalah', 'bagaimana', 'jelaskan', 'tentang', 'yang'}
stop_words.update(custom_stopwords)

def preprocess_text(text):
    """Preprocess user input text"""
    if not text or text.strip() == '':
        return ''
    
    text = str(text).lower()
    text = re.sub(r'http\S+|www\S+', '', text)
    text = re.sub(r'\S+@\S+', '', text)
    text = re.sub(r'[^a-z\s]', ' ', text)
    text = re.sub(r'\s+', ' ', text).strip()
    
    tokens = text.split()
    tokens = [stemmer.stem(word) for word in tokens if word not in stop_words and len(word) > 2]
    
    return ' '.join(tokens)

# ═══════════════════════════════════════════════════════════════════════════
# 🤖 CHATBOT CORE FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════

def get_prediction_with_confidence(text):
    """
    Get intent prediction with confidence score
    Returns: (intent, confidence, all_probabilities)
    """
    # Preprocess text
    text_clean = preprocess_text(text)
    
    # Check if text is too short
    if len(text_clean.split()) < MIN_TEXT_LENGTH:
        return None, 0.0, None
    
    # Vectorize
    text_vec = tfidf.transform([text_clean])
    
    # Get prediction
    intent = model.predict(text_vec)[0]
    
    # Get confidence score
    if hasattr(model, 'predict_proba'):
        # For models with predict_proba
        probabilities = model.predict_proba(text_vec)[0]
        confidence = np.max(probabilities)
        
        # Get all probabilities for top intents
        intent_probs = list(zip(model.classes_, probabilities))
        intent_probs.sort(key=lambda x: x[1], reverse=True)
    else:
        # For models without predict_proba (like LinearSVC)
        decision = model.decision_function(text_vec)[0]
        # Convert decision scores to pseudo-probabilities using softmax
        exp_scores = np.exp(decision - np.max(decision))
        probabilities = exp_scores / exp_scores.sum()
        confidence = np.max(probabilities)
        
        # Get all probabilities for top intents
        intent_probs = list(zip(model.classes_, probabilities))
        intent_probs.sort(key=lambda x: x[1], reverse=True)
    
    return intent, confidence, intent_probs[:3]  # Return top 3

def get_fallback_response(confidence, top_intents):
    """
    Generate intelligent fallback response
    """
    responses = [
        f"🤔 Maaf, saya kurang yakin dengan pertanyaan Anda (confidence: {confidence:.1%}).",
        f"\nApakah yang Anda maksud salah satu dari:",
    ]
    
    for i, (intent, prob) in enumerate(top_intents, 1):
        responses.append(f"  {i}. {intent.replace('_', ' ').title()} ({prob:.1%})")
    
    responses.append("\n💡 Tips: Coba tanyakan dengan lebih spesifik tentang:")
    responses.append("   • Phishing, Malware, atau Ransomware")
    responses.append("   • Network Security atau Firewall")
    responses.append("   • Encryption atau Password Security")
    responses.append("   • Incident Response")
    responses.append("   • Social Engineering")
    
    return '\n'.join(responses)

def chatbot_response(user_input):
    """
    Main chatbot function with confidence-based response
    """
    # Get prediction with confidence
    intent, confidence, top_intents = get_prediction_with_confidence(user_input)
    
    # Handle very short or invalid input
    if intent is None:
        return {
            'response': "❓ Pertanyaan Anda terlalu singkat. Mohon berikan pertanyaan yang lebih lengkap tentang cybersecurity.",
            'intent': 'unknown',
            'confidence': 0.0,
            'status': 'invalid_input'
        }
    
    # Check confidence threshold
    if confidence < CONFIDENCE_THRESHOLD:
        return {
            'response': get_fallback_response(confidence, top_intents),
            'intent': intent,
            'confidence': confidence,
            'status': 'low_confidence',
            'suggestions': [i[0] for i in top_intents]
        }
    
    # Get response from intent
    if intent in intent_responses:
        response = np.random.choice(intent_responses[intent])
        return {
            'response': response,
            'intent': intent,
            'confidence': confidence,
            'status': 'success'
        }
    else:
        return {
            'response': "⚠️ Maaf, saya tidak memiliki jawaban untuk topik ini.",
            'intent': intent,
            'confidence': confidence,
            'status': 'no_response'
        }

# ═══════════════════════════════════════════════════════════════════════════
# 🎮 INTERACTIVE DEMO
# ═══════════════════════════════════════════════════════════════════════════

def run_chatbot_demo():
    """
    Run interactive chatbot demo
    """
    print("\n" + "="*80)
    print("💬 CYBERSECURITY CHATBOT - INTERACTIVE MODE")
    print("="*80)
    print("\n🤖 Halo! Saya chatbot cybersecurity.")
    print("   Saya dapat membantu Anda dengan pertanyaan seputar keamanan siber.")
    print(f"   Confidence threshold: {CONFIDENCE_THRESHOLD:.0%}")
    print("\n💡 Ketik 'exit', 'quit', atau 'keluar' untuk mengakhiri percakapan.")
    print("   Ketik 'help' untuk melihat contoh pertanyaan.")
    print("="*80)
    
    conversation_history = []
    
    while True:
        print("\n" + "-"*80)
        user_input = input("👤 Anda: ").strip()
        
        # Exit commands
        if user_input.lower() in ['exit', 'quit', 'keluar', 'bye']:
            print("\n🤖 Bot: Terima kasih telah menggunakan Cybersecurity Chatbot!")
            print("         Tetap waspada terhadap ancaman cyber! 🔒")
            break
        
        # Help command
        if user_input.lower() == 'help':
            print("\n🤖 Bot: Berikut beberapa contoh pertanyaan:")
            print("   • 'Apa itu phishing?'")
            print("   • 'Bagaimana cara mencegah malware?'")
            print("   • 'Jelaskan tentang enkripsi'")
            print("   • 'Apa itu firewall?'")
            print("   • 'Cara membuat password yang aman'")
            print("   • 'Apa yang harus dilakukan saat terjadi insiden keamanan?'")
            continue
        
        # Skip empty input
        if not user_input:
            continue
        
        # Get chatbot response
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        result = chatbot_response(user_input)
        
        # Display response
        print(f"\n🤖 Bot: {result['response']}")
        
        # Display metadata
        if result['status'] == 'success':
            print(f"\n📊 [Intent: {result['intent']} | Confidence: {result['confidence']:.1%}]")
        elif result['status'] == 'low_confidence':
            print(f"\n⚠️ [Low Confidence: {result['confidence']:.1%}]")
        
        # Save to conversation history
        conversation_history.append({
            'timestamp': timestamp,
            'user': user_input,
            'bot': result['response'],
            'intent': result['intent'],
            'confidence': result['confidence'],
            'status': result['status']
        })
    
    # Save conversation history
    if conversation_history:
        import pandas as pd
        history_df = pd.DataFrame(conversation_history)
        filename = f"conversation_history_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
        history_df.to_excel(filename, index=False)
        print(f"\n💾 Conversation history saved: {filename}")
    
    print("\n" + "="*80)

# ═══════════════════════════════════════════════════════════════════════════
# 🧪 TESTING MODE
# ═══════════════════════════════════════════════════════════════════════════

def test_chatbot():
    """
    Test chatbot with predefined questions
    """
    print("\n" + "="*80)
    print("🧪 TESTING CHATBOT")
    print("="*80)
    
    test_questions = [
        "Apa itu phishing?",
        "Bagaimana cara mencegah malware?",
        "Jelaskan tentang firewall",
        "Apa itu enkripsi?",
        "Cara membuat password yang aman",
        "Apa yang harus dilakukan saat terjadi insiden?",
        "Halo",
        "Terima kasih",
        "Apa itu nasi goreng?",  # Out of domain
        "test"  # Too short
    ]
    
    results = []
    
    for question in test_questions:
        print(f"\n{'='*80}")
        print(f"❓ Question: {question}")
        result = chatbot_response(question)
        print(f"🤖 Response: {result['response']}")
        print(f"📊 Intent: {result['intent']} | Confidence: {result['confidence']:.1%} | Status: {result['status']}")
        
        results.append({
            'question': question,
            'intent': result['intent'],
            'confidence': result['confidence'],
            'status': result['status']
        })
    
    # Summary
    import pandas as pd
    results_df = pd.DataFrame(results)
    
    print("\n" + "="*80)
    print("📊 TEST SUMMARY")
    print("="*80)
    print(f"\nTotal questions: {len(test_questions)}")
    print(f"Success: {len(results_df[results_df['status'] == 'success'])}")
    print(f"Low confidence: {len(results_df[results_df['status'] == 'low_confidence'])}")
    print(f"Invalid input: {len(results_df[results_df['status'] == 'invalid_input'])}")
    print(f"\nAverage confidence: {results_df['confidence'].mean():.1%}")
    
    results_df.to_excel('test_results.xlsx', index=False)
    print("\n💾 Test results saved: test_results.xlsx")

# ═══════════════════════════════════════════════════════════════════════════
# 🚀 MAIN EXECUTION
# ═══════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("\n" + "="*80)
    print("🚀 CYBERSECURITY CHATBOT SYSTEM")
    print("="*80)
    print("\nSelect mode:")
    print("1. 💬 Interactive Chat")
    print("2. 🧪 Run Tests")
    print("3. ❌ Exit")
    
    while True:
        choice = input("\nEnter choice (1-3): ").strip()
        
        if choice == '1':
            run_chatbot_demo()
            break
        elif choice == '2':
            test_chatbot()
            break
        elif choice == '3':
            print("\n👋 Goodbye!")
            break
        else:
            print("❌ Invalid choice. Please enter 1, 2, or 3.")