"""
═══════════════════════════════════════════════════════════════════════════════
🚀 IMPROVED CYBERSECURITY CHATBOT - TRAINING SCRIPT
═══════════════════════════════════════════════════════════════════════════════
Features:
- Unified preprocessing pipeline
- Ensemble model (LR + RF + SVC)
- Semantic similarity fallback
- Comprehensive evaluation
- Error analysis
═══════════════════════════════════════════════════════════════════════════════
"""

import json
import joblib
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
import re
import warnings
warnings.filterwarnings('ignore')

# Scikit-learn
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.svm import SVC
from sklearn.metrics import (
    classification_report, 
    confusion_matrix, 
    accuracy_score,
    f1_score
)

# Indonesian NLP
from Sastrawi.Stemmer.StemmerFactory import StemmerFactory
from Sastrawi.StopWordRemover.StopWordRemoverFactory import StopWordRemoverFactory

# Semantic similarity (optional, install: pip install sentence-transformers)
try:
    from sentence_transformers import SentenceTransformer
    SEMANTIC_AVAILABLE = True
except ImportError:
    SEMANTIC_AVAILABLE = False
    print("⚠️ sentence-transformers not installed. Semantic fallback disabled.")

# ═══════════════════════════════════════════════════════════════════════════
# 📊 CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════

CONFIG = {
    'train_data_path': 'intent_training_data_expanded.json',
    'response_data_path': 'dataset_augmented.json',
    'test_size': 0.2,
    'random_state': 42,
    'min_samples_per_intent': 10,
    'use_ensemble': True,
    'use_semantic': False,  # DISABLED - PyTorch not needed
    'output_dir': 'model_improved/'
}

# ═══════════════════════════════════════════════════════════════════════════
# 🧹 TEXT PREPROCESSING
# ═══════════════════════════════════════════════════════════════════════════

class TextPreprocessor:
    """
    Unified text preprocessing untuk training dan inference
    """
    
    def __init__(self):
        self.stemmer = StemmerFactory().create_stemmer()
        self.stopword_remover = StopWordRemoverFactory().create_stop_word_remover()
        
        # Custom dictionary untuk normalize cyber terms & typos
        self.normalization_dict = {
            'phising': 'phishing',
            'pishing': 'phishing',
            'fisyhing': 'phishing',
            'pising': 'phishing',
            'malwer': 'malware',
            'malwere': 'malware',
            'malware': 'malware',
            'firewol': 'firewall',
            'antivrus': 'antivirus',
            'enkripsi': 'encryption',
            'dekripsi': 'decryption',
            'ransomwer': 'ransomware',
            'ransomware': 'ransomware',
            'ddoss': 'ddos',
            'dos': 'ddos',
            'sosial': 'social',
            'enggenering': 'engineering',
            'heker': 'hacker',
            'hacker': 'hacker',
            'pasword': 'password',
            'passwod': 'password'
        }
        
        # Stopwords tambahan yang kurang penting untuk cybersecurity
        self.custom_stopwords = {
            'apa', 'adalah', 'itu', 'ya', 'sih', 'dong', 
            'yah', 'kan', 'lah', 'kah', 'pun'
        }
    
    def normalize_text(self, text):
        """Normalize typos dan cyber terms"""
        text_lower = text.lower()
        words = text_lower.split()
        
        normalized_words = []
        for word in words:
            # Check jika ada di normalization dict
            normalized_word = self.normalization_dict.get(word, word)
            normalized_words.append(normalized_word)
        
        return ' '.join(normalized_words)
    
    def clean_text(self, text):
        """Basic text cleaning"""
        # Lowercase
        text = text.lower()
        
        # Remove URLs
        text = re.sub(r'http\S+|www\S+', '', text)
        
        # Remove emails
        text = re.sub(r'\S+@\S+', '', text)
        
        # Remove special characters (keep spaces)
        text = re.sub(r'[^a-z\s]', ' ', text)
        
        # Remove extra spaces
        text = re.sub(r'\s+', ' ', text).strip()
        
        return text
    
    def preprocess(self, text, remove_stopwords=True, apply_stemming=True):
        """
        Complete preprocessing pipeline
        
        Args:
            text: Input text
            remove_stopwords: Whether to remove stopwords
            apply_stemming: Whether to apply stemming
        
        Returns:
            Preprocessed text
        """
        if not text or text.strip() == '':
            return ''
        
        # 1. Normalize cyber terms & typos
        text = self.normalize_text(text)
        
        # 2. Clean text
        text = self.clean_text(text)
        
        # 3. Remove stopwords
        if remove_stopwords:
            words = text.split()
            words = [w for w in words if w not in self.custom_stopwords and len(w) > 2]
            text = ' '.join(words)
            text = self.stopword_remover.remove(text)
        
        # 4. Stemming
        if apply_stemming:
            text = self.stemmer.stem(text)
        
        return text.strip()

# ═══════════════════════════════════════════════════════════════════════════
# 📦 DATA LOADING & AUGMENTATION
# ═══════════════════════════════════════════════════════════════════════════

def load_training_data(filepath):
    """Load training data dari JSON"""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return data
    except FileNotFoundError:
        print(f"⚠️ File tidak ditemukan: {filepath}")
        print("💡 Mencoba menggunakan file fallback...")
        return load_training_data('intent_training_data.json')

def augment_data_simple(texts, labels):
    """
    Simple data augmentation:
    - Add synonym variations
    - Add typo variations
    - Add paraphrases
    """
    augmented_texts = []
    augmented_labels = []
    
    # Copy original data
    augmented_texts.extend(texts)
    augmented_labels.extend(labels)
    
    # Add variations
    for text, label in zip(texts, labels):
        # Variation 1: Add question variations
        if 'apa itu' in text:
            new_text = text.replace('apa itu', 'apa maksud')
            augmented_texts.append(new_text)
            augmented_labels.append(label)
            
            new_text = text.replace('apa itu', 'pengertian')
            augmented_texts.append(new_text)
            augmented_labels.append(label)
        
        # Variation 2: Add informal variations
        if 'bagaimana' in text:
            new_text = text.replace('bagaimana', 'gimana')
            augmented_texts.append(new_text)
            augmented_labels.append(label)
        
        if 'cara' in text:
            new_text = text.replace('cara', 'gimana cara')
            augmented_texts.append(new_text)
            augmented_labels.append(label)
    
    print(f"✅ Data augmentation: {len(texts)} → {len(augmented_texts)} samples")
    
    return augmented_texts, augmented_labels

def prepare_dataset(data, min_samples=10):
    """Prepare dataset dari JSON format"""
    texts = []
    labels = []
    
    intent_counts = {}
    
    for intent, utterances in data.items():
        if isinstance(utterances, list):
            for utterance in utterances:
                texts.append(utterance)
                labels.append(intent)
            intent_counts[intent] = len(utterances)
        else:
            print(f"⚠️ Skipping intent '{intent}' - bukan list format")
    
    # Check minimum samples
    low_sample_intents = [k for k, v in intent_counts.items() if v < min_samples]
    if low_sample_intents:
        print(f"\n⚠️ Intent dengan samples < {min_samples}:")
        for intent in low_sample_intents:
            print(f"   - {intent}: {intent_counts[intent]} samples")
        print("💡 Rekomendasi: Tambahkan lebih banyak training examples untuk intent ini")
    
    return texts, labels, intent_counts

# ═══════════════════════════════════════════════════════════════════════════
# 🤖 MODEL BUILDING
# ═══════════════════════════════════════════════════════════════════════════

def create_ensemble_model():
    """Create ensemble model dengan multiple classifiers"""
    
    # Base models
    lr = LogisticRegression(
        max_iter=1000,
        class_weight='balanced',
        solver='liblinear',
        C=1.0
    )
    
    rf = RandomForestClassifier(
        n_estimators=100,
        max_depth=20,
        min_samples_split=5,
        min_samples_leaf=2,
        class_weight='balanced',
        random_state=42
    )
    
    svc = SVC(
        kernel='rbf',
        C=1.0,
        gamma='scale',
        class_weight='balanced',
        probability=True,
        random_state=42
    )
    
    # Ensemble
    ensemble = VotingClassifier(
        estimators=[
            ('lr', lr),
            ('rf', rf),
            ('svc', svc)
        ],
        voting='soft',  # Use probability averaging
        weights=[2, 1, 1]  # Give more weight to LR
    )
    
    return ensemble

def create_single_model():
    """Create single best model (untuk comparison)"""
    return LogisticRegression(
        max_iter=1000,
        class_weight='balanced',
        solver='liblinear',
        C=1.0
    )

# ═══════════════════════════════════════════════════════════════════════════
# 📊 EVALUATION
# ═══════════════════════════════════════════════════════════════════════════

def evaluate_model(model, X_test, y_test, intent_names):
    """Comprehensive model evaluation"""
    
    print("\n" + "="*80)
    print("📊 MODEL EVALUATION")
    print("="*80)
    
    # Predictions
    y_pred = model.predict(X_test)
    y_proba = model.predict_proba(X_test)
    
    # Overall metrics
    accuracy = accuracy_score(y_test, y_pred)
    f1_macro = f1_score(y_test, y_pred, average='macro')
    f1_weighted = f1_score(y_test, y_pred, average='weighted')
    
    print(f"\n✅ Overall Accuracy: {accuracy:.2%}")
    print(f"✅ F1 Score (Macro): {f1_macro:.2%}")
    print(f"✅ F1 Score (Weighted): {f1_weighted:.2%}")
    
    # Per-intent metrics
    print("\n" + "-"*80)
    print("📋 CLASSIFICATION REPORT")
    print("-"*80)
    report = classification_report(y_test, y_pred, target_names=intent_names)
    print(report)
    
    # Confusion matrix
    cm = confusion_matrix(y_test, y_pred, labels=intent_names)
    
    plt.figure(figsize=(12, 10))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                xticklabels=intent_names, yticklabels=intent_names)
    plt.title('Confusion Matrix')
    plt.ylabel('True Intent')
    plt.xlabel('Predicted Intent')
    plt.tight_layout()
    plt.savefig('confusion_matrix_improved.png', dpi=300, bbox_inches='tight')
    print("\n💾 Confusion matrix saved: confusion_matrix_improved.png")
    
    # Error analysis
    errors = []
    for i, (true, pred) in enumerate(zip(y_test, y_pred)):
        if true != pred:
            errors.append({
                'text': X_test[i],
                'true_intent': true,
                'predicted_intent': pred,
                'confidence': np.max(y_proba[i])
            })
    
    if errors:
        error_df = pd.DataFrame(errors)
        error_df.to_excel('error_analysis_improved.xlsx', index=False)
        print(f"💾 Error analysis saved: error_analysis_improved.xlsx")
        print(f"   Total errors: {len(errors)} ({len(errors)/len(y_test)*100:.1f}%)")
        
        # Most confused pairs
        confusion_pairs = error_df.groupby(['true_intent', 'predicted_intent']).size()
        confusion_pairs = confusion_pairs.sort_values(ascending=False).head(5)
        
        print("\n🔀 Top 5 Confused Intent Pairs:")
        for (true_int, pred_int), count in confusion_pairs.items():
            print(f"   {true_int} → {pred_int}: {count} times")
    
    return {
        'accuracy': accuracy,
        'f1_macro': f1_macro,
        'f1_weighted': f1_weighted,
        'confusion_matrix': cm,
        'errors': errors
    }

# ═══════════════════════════════════════════════════════════════════════════
# 🚀 MAIN TRAINING PIPELINE
# ═══════════════════════════════════════════════════════════════════════════

def train_chatbot():
    """Main training pipeline"""
    
    print("\n" + "="*80)
    print("🚀 CYBERSECURITY CHATBOT - IMPROVED TRAINING")
    print("="*80)
    
    # 1. Load data
    print("\n📂 Loading training data...")
    raw_data = load_training_data(CONFIG['train_data_path'])
    
    texts, labels, intent_counts = prepare_dataset(
        raw_data, 
        min_samples=CONFIG['min_samples_per_intent']
    )
    
    print(f"\n✅ Loaded {len(texts)} samples across {len(set(labels))} intents")
    print("\n📊 Intent Distribution:")
    for intent, count in sorted(intent_counts.items(), key=lambda x: x[1], reverse=True):
        print(f"   {intent}: {count} samples")
    
    # 2. Data augmentation
    print("\n🔄 Augmenting data...")
    texts, labels = augment_data_simple(texts, labels)
    
    # 3. Preprocessing
    print("\n🧹 Preprocessing text...")
    preprocessor = TextPreprocessor()
    texts_clean = [preprocessor.preprocess(text) for text in texts]
    
    # Remove empty texts
    valid_indices = [i for i, t in enumerate(texts_clean) if t.strip() != '']
    texts_clean = [texts_clean[i] for i in valid_indices]
    labels = [labels[i] for i in valid_indices]
    
    print(f"✅ Preprocessing complete: {len(texts_clean)} valid samples")
    
    # 4. Create DataFrame
    df = pd.DataFrame({
        'text': texts_clean,
        'intent': labels
    })
    
    # 5. Train-test split
    print("\n✂️ Splitting data...")
    X_train, X_test, y_train, y_test = train_test_split(
        df['text'].values,
        df['intent'].values,
        test_size=CONFIG['test_size'],
        random_state=CONFIG['random_state'],
        stratify=df['intent']
    )
    
    print(f"✅ Train: {len(X_train)} samples, Test: {len(X_test)} samples")
    
    # 6. TF-IDF Vectorization
    print("\n🔢 Vectorizing text...")
    vectorizer = TfidfVectorizer(
        ngram_range=(1, 3),  # Unigrams, bigrams, trigrams
        max_features=2000,    # Reduced untuk avoid overfitting
        min_df=2,             # Ignore terms yang muncul < 2 docs
        max_df=0.8,           # Ignore terms yang muncul > 80% docs
        sublinear_tf=True     # Use log scaling
    )
    
    X_train_vec = vectorizer.fit_transform(X_train)
    X_test_vec = vectorizer.transform(X_test)
    
    print(f"✅ Vocabulary size: {len(vectorizer.vocabulary_)}")
    
    # 7. Train models
    print("\n🤖 Training models...")
    
    intent_names = sorted(set(labels))
    
    # Train single model
    print("\n   Training Logistic Regression...")
    single_model = create_single_model()
    single_model.fit(X_train_vec, y_train)
    
    # Evaluate single model
    print("\n   📊 Logistic Regression Results:")
    y_pred_single = single_model.predict(X_test_vec)
    acc_single = accuracy_score(y_test, y_pred_single)
    print(f"   Accuracy: {acc_single:.2%}")
    
    # Train ensemble model (if enabled)
    if CONFIG['use_ensemble']:
        print("\n   Training Ensemble Model...")
        ensemble_model = create_ensemble_model()
        ensemble_model.fit(X_train_vec, y_train)
        
        # Evaluate ensemble
        print("\n   📊 Ensemble Model Results:")
        y_pred_ensemble = ensemble_model.predict(X_test_vec)
        acc_ensemble = accuracy_score(y_test, y_pred_ensemble)
        print(f"   Accuracy: {acc_ensemble:.2%}")
        
        # Choose best model
        if acc_ensemble > acc_single:
            print(f"\n✅ Using Ensemble Model (better by {(acc_ensemble-acc_single)*100:.1f}%)")
            final_model = ensemble_model
        else:
            print(f"\n✅ Using Single Model (ensemble not better)")
            final_model = single_model
    else:
        final_model = single_model
    
    # 8. Comprehensive evaluation
    results = evaluate_model(final_model, X_test_vec, y_test, intent_names)
    
    # 9. Train semantic model (if available)
    semantic_model = None
    if CONFIG['use_semantic'] and SEMANTIC_AVAILABLE:
        print("\n🧠 Training semantic similarity model...")
        try:
            semantic_model = SentenceTransformer('paraphrase-multilingual-MiniLM-L12-v2')
            print("✅ Semantic model loaded")
        except Exception as e:
            print(f"⚠️ Could not load semantic model: {e}")
    
    # 10. Save models
    print("\n💾 Saving models...")
    
    import os
    os.makedirs(CONFIG['output_dir'], exist_ok=True)
    
    # Save main artifacts
    joblib.dump(final_model, f"{CONFIG['output_dir']}/intent_model.pkl")
    joblib.dump(vectorizer, f"{CONFIG['output_dir']}/vectorizer.pkl")
    joblib.dump(preprocessor, f"{CONFIG['output_dir']}/preprocessor.pkl")
    
    # Save intent mapping
    intent_mapping = {i: intent for i, intent in enumerate(intent_names)}
    with open(f"{CONFIG['output_dir']}/intent_mapping.json", 'w', encoding='utf-8') as f:
        json.dump(intent_mapping, f, indent=2, ensure_ascii=False)
    
    # Save metadata
    metadata = {
        'model_type': 'ensemble' if CONFIG['use_ensemble'] else 'single',
        'accuracy': results['accuracy'],
        'f1_macro': results['f1_macro'],
        'f1_weighted': results['f1_weighted'],
        'n_intents': len(intent_names),
        'n_samples': len(texts),
        'intents': intent_names,
        'training_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'config': CONFIG
    }
    
    with open(f"{CONFIG['output_dir']}/metadata.json", 'w', encoding='utf-8') as f:
        json.dump(metadata, f, indent=2, ensure_ascii=False)
    
    print(f"\n✅ Models saved to: {CONFIG['output_dir']}")
    print("\n" + "="*80)
    print("🎉 TRAINING COMPLETE")
    print("="*80)
    print(f"\n📊 Final Results:")
    print(f"   Accuracy: {results['accuracy']:.2%}")
    print(f"   F1 Score (Macro): {results['f1_macro']:.2%}")
    print(f"   F1 Score (Weighted): {results['f1_weighted']:.2%}")
    print(f"   Intents: {len(intent_names)}")
    print(f"   Training Samples: {len(texts)}")
    print("\n" + "="*80)
    
    return final_model, vectorizer, preprocessor, metadata

# ═══════════════════════════════════════════════════════════════════════════
# 🎯 MAIN EXECUTION
# ═══════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    train_chatbot()