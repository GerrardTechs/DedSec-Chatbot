import json
import joblib
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix

# ==========================
# LOAD DATA
# ==========================
with open("intent_training_data.json", "r", encoding="utf-8") as f:
    raw = json.load(f)

texts = []
labels = []

for intent, utterances in raw.items():
    for u in utterances:
        texts.append(u.lower())
        labels.append(intent)

df = pd.DataFrame({
    "text": texts,
    "intent": labels
})

print("Total samples:", len(df))
print(df["intent"].value_counts())

# ==========================
# SPLIT
# ==========================
X_train, X_test, y_train, y_test = train_test_split(
    df["text"],
    df["intent"],
    test_size=0.2,
    random_state=42,
    stratify=df["intent"]
)

# ==========================
# TF-IDF
# ==========================
vectorizer = TfidfVectorizer(
    ngram_range=(1, 2),
    max_features=3000
)

X_train_vec = vectorizer.fit_transform(X_train)
X_test_vec = vectorizer.transform(X_test)

# ==========================
# MODEL
# ==========================
model = LogisticRegression(
    max_iter=1000,
    class_weight="balanced"
)

model.fit(X_train_vec, y_train)

# ==========================
# EVALUATION
# ==========================
y_pred = model.predict(X_test_vec)

print("\nClassification Report:")
print(classification_report(y_test, y_pred))

cm = confusion_matrix(y_test, y_pred, labels=model.classes_)
print("\nConfusion Matrix:")
print(cm)

# ==========================
# SAVE MODEL
# ==========================
joblib.dump(model, "intent_model.pkl")
joblib.dump(vectorizer, "vectorizer.pkl")

print("\n✅ Training selesai & model disimpan")
