import streamlit as st
import json
import joblib
import random
import numpy as np

# ======================
# CONFIG
# ======================
st.set_page_config(
    page_title="Cybersecurity Chatbot",
    page_icon="🛡️",
    layout="centered"
)

HIGH_CONF = 0.6

# ======================
# LOAD ASSETS
# ======================
model = joblib.load("intent_model.pkl")
vectorizer = joblib.load("vectorizer.pkl")

with open("dataset_augmented.json", "r", encoding="utf-8") as f:
    DATASET = json.load(f)

# ======================
# SESSION STATE
# ======================
if "messages" not in st.session_state:
    st.session_state.messages = []

if "last_intent" not in st.session_state:
    st.session_state.last_intent = None

if "last_section" not in st.session_state:
    st.session_state.last_section = None

# ======================
# HELPERS
# ======================
def predict_intent(text):
    vec = vectorizer.transform([text.lower()])
    intent = model.predict(vec)[0]
    score = np.max(model.decision_function(vec))
    confidence = 1 / (1 + np.exp(-score))
    return intent, round(confidence, 2)

def detect_question_type(text):
    t = text.lower()
    if any(k in t for k in ["contoh", "misalnya"]):
        return "example"
    if any(k in t for k in ["cara kerja", "gimana", "bagaimana"]):
        return "process"
    if any(k in t for k in ["bahaya", "dampak", "berbahaya"]):
        return "impact"
    if any(k in t for k in ["hindari", "mencegah", "solusi"]):
        return "mitigation"
    return "definition"

def rule_front(text):
    t = text.lower().strip()
    if t in ["halo", "hai", "hi", "hello", "hey"]:
        return "Halo 👋 Ada yang bisa saya bantu seputar cybersecurity?"
    if t in ["ya", "boleh", "lanjut", "oke"]:
        if st.session_state.last_intent and st.session_state.last_section:
            data = DATASET.get(st.session_state.last_intent, {})
            section = st.session_state.last_section
            if section in data:
                return random.choice(data[section])
    if len(t) < 3:
        return "Boleh diperjelas ya 🙂 Kamu mau tanya soal apa? (phishing, malware, dll)"
    return None

def fallback():
    return (
        "Maaf, saya belum yakin memahami pertanyaan kamu 🤔\n\n"
        "Coba jelaskan lebih spesifik (misalnya: phishing, malware, ransomware)."
    )

# ======================
# UI
# ======================
st.title("🛡️ Cybersecurity Chatbot")
st.caption("Hybrid Machine Learning + Context Awareness")

for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

user_input = st.chat_input("Tanyakan seputar cybersecurity...")

# ======================
# MAIN LOGIC
# ======================
if user_input:
    st.session_state.messages.append({
        "role": "user",
        "content": user_input
    })

    rule = rule_front(user_input)
    if rule:
        st.session_state.messages.append({
            "role": "assistant",
            "content": rule
        })
        st.rerun()

    intent, confidence = predict_intent(user_input)

    if confidence < HIGH_CONF:
        bot_reply = fallback()
    else:
        section = detect_question_type(user_input)
        data = DATASET.get(intent, {})

        if section in data:
            bot_reply = random.choice(data[section])
        else:
            bot_reply = random.choice(data.get("definition", [fallback()]))

        bot_reply += f"\n\n_Intent: **{intent}** | Confidence: **{confidence}**_"

        st.session_state.last_intent = intent
        st.session_state.last_section = section

    st.session_state.messages.append({
        "role": "assistant",
        "content": bot_reply
    })

    st.rerun()
