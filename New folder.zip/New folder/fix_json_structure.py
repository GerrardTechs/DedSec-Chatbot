"""
FIX JSON STRUCTURE
Auto-fix struktur JSON intents agar compatible dengan training script
"""

import json
import os
import shutil
from datetime import datetime

print("="*70)
print(" 🔧 JSON STRUCTURE FIXER")
print("="*70)

# Files to check
json_files = [
    'dataset_augmented.json',
    'intent_training_data_expanded.json',
]

print("\n📁 Checking JSON files...")

for filename in json_files:
    if not os.path.exists(filename):
        print(f"   ❌ {filename} not found")
        continue
    
    print(f"\n   ✓ Found: {filename}")
    
    try:
        # Load file
        with open(filename, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        file_size = os.path.getsize(filename) / 1024
        print(f"      Size: {file_size:.1f} KB")
        
        # Check structure
        needs_fix = False
        fixed_data = None
        structure_type = None
        
        if 'intents' in data and isinstance(data['intents'], list):
            print(f"      Structure: ✅ CORRECT (standard format)")
            structure_type = "standard"
            
        elif isinstance(data, list):
            print(f"      Structure: ⚠️  NEEDS FIX (array format)")
            print(f"      Converting to standard format...")
            needs_fix = True
            structure_type = "array"
            fixed_data = {'intents': data}
            
        elif isinstance(data, dict):
            # Check for other possible keys
            possible_keys = ['data', 'training_data', 'dataset', 'items']
            found_key = None
            
            for key in possible_keys:
                if key in data and isinstance(data[key], list):
                    found_key = key
                    break
            
            if found_key:
                print(f"      Structure: ⚠️  NEEDS FIX (nested in '{found_key}')")
                print(f"      Converting to standard format...")
                needs_fix = True
                structure_type = f"nested_{found_key}"
                fixed_data = {'intents': data[found_key]}
                
            else:
                # NEW: Check if it's tag-based dictionary format
                # Format: {"greeting": {...}, "phishing": {...}}
                is_tag_based = False
                sample_keys = list(data.keys())[:5]
                
                # Check if values are dict with patterns/responses
                if sample_keys:
                    first_value = data[sample_keys[0]]
                    if isinstance(first_value, dict):
                        has_patterns = 'patterns' in first_value or 'pattern' in first_value
                        has_responses = 'responses' in first_value or 'response' in first_value
                        
                        if has_patterns or has_responses:
                            is_tag_based = True
                
                if is_tag_based:
                    print(f"      Structure: ⚠️  NEEDS FIX (tag-based dictionary)")
                    print(f"      Found tags: {sample_keys}")
                    print(f"      Converting to standard format...")
                    needs_fix = True
                    structure_type = "tag_based_dict"
                    
                    # Convert tag-based dict to standard format
                    intents_list = []
                    for tag, content in data.items():
                        intent_obj = {'tag': tag}
                        
                        # Handle patterns (could be 'patterns' or 'pattern')
                        if 'patterns' in content:
                            intent_obj['patterns'] = content['patterns']
                        elif 'pattern' in content:
                            patterns = content['pattern']
                            intent_obj['patterns'] = patterns if isinstance(patterns, list) else [patterns]
                        else:
                            intent_obj['patterns'] = []
                        
                        # Handle responses (could be 'responses' or 'response')
                        if 'responses' in content:
                            intent_obj['responses'] = content['responses']
                        elif 'response' in content:
                            responses = content['response']
                            intent_obj['responses'] = responses if isinstance(responses, list) else [responses]
                        else:
                            intent_obj['responses'] = []
                        
                        intents_list.append(intent_obj)
                    
                    fixed_data = {'intents': intents_list}
                    
                else:
                    print(f"      Structure: ❌ UNKNOWN")
                    print(f"      Keys found: {list(data.keys())[:5]}")
                    continue
        
        else:
            print(f"      Structure: ❌ INVALID (not dict or list)")
            continue
        
        # If needs fix, save it
        if needs_fix and fixed_data:
            # Backup original
            backup_name = f"{filename}.backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            shutil.copy2(filename, backup_name)
            print(f"      📦 Backup created: {backup_name}")
            
            # Save fixed version
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(fixed_data, f, indent=2, ensure_ascii=False)
            
            print(f"      ✅ FIXED! Saved as standard format")
            
            # Verify
            num_intents = len(fixed_data['intents'])
            total_patterns = sum(len(intent.get('patterns', [])) for intent in fixed_data['intents'])
            print(f"      📊 Intents: {num_intents}")
            print(f"      📊 Patterns: {total_patterns}")
            
    except json.JSONDecodeError as e:
        print(f"      ❌ Invalid JSON: {e}")
    except Exception as e:
        print(f"      ❌ Error: {e}")

print("\n" + "="*70)
print(" 📊 SUMMARY")
print("="*70)

# Check again after fixes
print("\n✅ Valid files now:")
valid_count = 0

for filename in json_files:
    if os.path.exists(filename):
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            if 'intents' in data and isinstance(data['intents'], list):
                num_intents = len(data['intents'])
                total_patterns = sum(len(intent.get('patterns', [])) for intent in data['intents'])
                print(f"   ✓ {filename}")
                print(f"      - {num_intents} intents")
                print(f"      - {total_patterns} patterns")
                valid_count += 1
        except:
            pass

if valid_count == 0:
    print("\n   ❌ No valid intents files!")
    print("\n   SOLUTION: Create intents.json manually or use create_intents.py")
else:
    print(f"\n   ✅ {valid_count} valid file(s) ready for training!")
    print("\n   NEXT STEP:")
    print("   python train_sklearn_version.py")

print("\n" + "="*70)