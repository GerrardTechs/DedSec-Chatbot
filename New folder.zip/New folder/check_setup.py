"""
CHECK SETUP - Diagnosa dan fix masalah file
Versi yang lebih detail untuk troubleshooting
"""

import os
import sys
import json

print("="*70)
print(" 🔍 DIAGNOSTIC SCRIPT - Checking Your Project Setup")
print("="*70)

# 1. Check current directory
print("\n📁 1. CURRENT WORKING DIRECTORY:")
current_dir = os.getcwd()
print(f"   → {current_dir}")

# 2. List ALL files in current directory
print("\n📄 2. ALL FILES IN CURRENT DIRECTORY:")
all_files = os.listdir(current_dir)
print(f"   Total files: {len(all_files)}")
print()

# Categorize files
py_files = [f for f in all_files if f.endswith('.py')]
json_files = [f for f in all_files if f.endswith('.json')]
pkl_files = [f for f in all_files if f.endswith('.pkl')]
other_files = [f for f in all_files if not f.endswith(('.py', '.json', '.pkl'))]

if py_files:
    print("   Python files (.py):")
    for f in sorted(py_files):
        size = os.path.getsize(f) / 1024  # KB
        print(f"      ✓ {f} ({size:.1f} KB)")

if json_files:
    print("\n   JSON files (.json):")
    for f in sorted(json_files):
        size = os.path.getsize(f) / 1024  # KB
        print(f"      ✓ {f} ({size:.1f} KB)")

if pkl_files:
    print("\n   Model files (.pkl):")
    for f in sorted(pkl_files):
        size = os.path.getsize(f) / 1024  # KB
        print(f"      ✓ {f} ({size:.1f} KB)")

# 3. Check SPECIFIC intents files
print("\n🎯 3. CHECKING INTENTS FILES:")
print("="*70)

intent_files = [
    'dataset_augmented.json',        # File user yang sebenarnya
    'data_augmented.json',
    'intent_training_data_expanded.json',
    'intents.json',
    'intent_data.json'
]

found_intents = []

for filename in intent_files:
    if os.path.exists(filename):
        print(f"\n   ✅ FOUND: {filename}")
        size = os.path.getsize(filename)
        print(f"      Size: {size:,} bytes ({size/1024:.1f} KB)")
        
        # Try to load and analyze
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                data = json.load(f)
                
            if 'intents' in data:
                num_intents = len(data['intents'])
                total_patterns = sum(len(intent.get('patterns', [])) for intent in data['intents'])
                total_responses = sum(len(intent.get('responses', [])) for intent in data['intents'])
                
                print(f"      Structure: ✅ CORRECT (standard format)")
                print(f"      Intents: {num_intents}")
                print(f"      Total patterns: {total_patterns}")
                print(f"      Total responses: {total_responses}")
                
                # Show first 3 intent tags
                tags = [intent['tag'] for intent in data['intents'][:3]]
                print(f"      First intents: {', '.join(tags)}...")
                
                found_intents.append({
                    'file': filename,
                    'intents': num_intents,
                    'patterns': total_patterns,
                    'size': size,
                    'valid': True
                })
                
            elif isinstance(data, list):
                num_intents = len(data)
                total_patterns = sum(len(item.get('patterns', [])) for item in data)
                
                print(f"      Structure: ⚠️  FIXABLE (array format - needs conversion)")
                print(f"      Intents: {num_intents}")
                print(f"      Total patterns: {total_patterns}")
                print(f"      → Run: python fix_json_structure.py")
                
                found_intents.append({
                    'file': filename,
                    'intents': num_intents,
                    'patterns': total_patterns,
                    'size': size,
                    'valid': False,
                    'fix': 'array_format'
                })
                
            else:
                print(f"      Structure: ❌ INVALID (missing 'intents' key)")
                print(f"      Keys found: {list(data.keys())[:5]}")
                print(f"      → Run: python fix_json_structure.py")
                
        except json.JSONDecodeError as e:
            print(f"      Error: ❌ Invalid JSON - {e}")
        except Exception as e:
            print(f"      Error: ❌ {e}")
    else:
        print(f"   ❌ NOT FOUND: {filename}")

# 4. Check training scripts
print("\n\n🐍 4. CHECKING TRAINING SCRIPTS:")
print("="*70)

train_scripts = [
    'train_sklearn_version.py',
    'train_model_fixed.py',
    'improved_training.py',
    'train_model.py'
]

for script in train_scripts:
    if os.path.exists(script):
        size = os.path.getsize(script) / 1024
        print(f"   ✅ {script} ({size:.1f} KB)")
    else:
        print(f"   ❌ {script}")

# 5. Check app scripts
print("\n💻 5. CHECKING APP SCRIPTS:")
print("="*70)

app_scripts = [
    'app_sklearn_version.py',
    'app_improved.py',
    'chatbot.py'
]

for script in app_scripts:
    if os.path.exists(script):
        size = os.path.getsize(script) / 1024
        print(f"   ✅ {script} ({size:.1f} KB)")
    else:
        print(f"   ❌ {script}")

# 6. Check model files
print("\n🤖 6. CHECKING MODEL FILES (After Training):")
print("="*70)

model_files = [
    'anonymous_model.pkl',
    'anonymous_model.h5',
    'words.pkl',
    'classes.pkl',
    'model_info.json'
]

model_exists = False
for mfile in model_files:
    if os.path.exists(mfile):
        size = os.path.getsize(mfile) / 1024
        print(f"   ✅ {mfile} ({size:.1f} KB)")
        model_exists = True
    else:
        print(f"   ❌ {mfile} (not yet created)")

# 7. Summary and recommendations
print("\n\n" + "="*70)
print(" 📊 SUMMARY & RECOMMENDATIONS")
print("="*70)

if not found_intents:
    print("\n❌ CRITICAL: No intents file found!")
    print("\n   SOLUTION:")
    print("   1. Make sure you have one of these files:")
    for f in intent_files:
        print(f"      - {f}")
    print("   2. Or create intents.json using: python create_intents.py")
else:
    # Recommend best file
    best_file = max(found_intents, key=lambda x: x['patterns'])
    print(f"\n✅ Found {len(found_intents)} intents file(s)")
    print(f"\n   📌 RECOMMENDED: {best_file['file']}")
    print(f"      - {best_file['intents']} intents")
    print(f"      - {best_file['patterns']} patterns")
    print(f"      - {best_file['size']/1024:.1f} KB")

if not os.path.exists('train_sklearn_version.py'):
    print("\n❌ Missing training script: train_sklearn_version.py")
else:
    print("\n✅ Training script ready")

if not os.path.exists('app_sklearn_version.py'):
    print("❌ Missing app script: app_sklearn_version.py")
else:
    print("✅ App script ready")

if not model_exists:
    print("\n⚠️  Model not trained yet")
    print("\n   NEXT STEP: Train the model")
    print("   Command: python train_sklearn_version.py")
else:
    print("\n✅ Model already trained")
    print("\n   NEXT STEP: Run the app")
    print("   Command: streamlit run app_sklearn_version.py")

print("\n" + "="*70)
print(" 🚀 QUICK START COMMANDS:")
print("="*70)

if found_intents:
    print("\n   # Train model:")
    print("   python train_sklearn_version.py")
    print("\n   # Run chatbot:")
    print("   streamlit run app_sklearn_version.py")
else:
    print("\n   # First, create intents file:")
    print("   python create_intents.py")
    print("\n   # Then train:")
    print("   python train_sklearn_version.py")

print("\n" + "="*70)