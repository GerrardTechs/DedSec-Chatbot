"""
Preprocessing Module untuk Chatbot Cybersecurity
Mendukung preprocessing teks Bahasa Indonesia lengkap
"""

import re
import pandas as pd
import string
import pickle
from sklearn.feature_extraction.text import TfidfVectorizer

class IndonesianPreprocessor:
    """Preprocessing khusus untuk Bahasa Indonesia"""
    
    def __init__(self):
        # Stopwords Bahasa Indonesia (common words yang tidak membawa makna signifikan)
        self.stopwords = set([
            'yang', 'untuk', 'pada', 'ke', 'para', 'namun', 'menurut', 'antara',
            'dia', 'dua', 'ia', 'seperti', 'jika', 'jika', 'sehingga', 'kembali',
            'dan', 'ini', 'itu', 'adalah', 'dengan', 'dari', 'akan', 'oleh',
            'telah', 'dapat', 'ada', 'atau', 'lebih', 'sudah', 'dalam', 'juga',
            'di', 'tersebut', 'tidak', 'bisa', 'mereka', 'kami', 'kita', 'saya',
            'anda', 'nya', 'pun', 'lah', 'kah', 'tah', 'sangat', 'banyak', 'saat',
            'ketika', 'karena', 'bila', 'yaitu', 'sebagai', 'maka', 'serta', 'agar'
        ])
        
        # Kata tidak baku ke baku (normalisasi)
        self.normalization_dict = {
            'gak': 'tidak', 'ga': 'tidak', 'ngga': 'tidak', 'nggak': 'tidak',
            'gmn': 'bagaimana', 'gimana': 'bagaimana', 'gmana': 'bagaimana',
            'knp': 'kenapa', 'knapa': 'kenapa', 'kenapa': 'kenapa',
            'udah': 'sudah', 'udh': 'sudah', 'dah': 'sudah',
            'bgmn': 'bagaimana', 'bsa': 'bisa', 'bs': 'bisa',
            'aja': 'saja', 'ajah': 'saja', 'aj': 'saja',
            'yg': 'yang', 'dgn': 'dengan', 'utk': 'untuk',
            'tdk': 'tidak', 'gk': 'tidak', 'g': 'tidak',
            'sy': 'saya', 'aku': 'saya', 'gue': 'saya', 'gw': 'saya',
            'lo': 'kamu', 'lu': 'kamu', 'loe': 'kamu',
            'dong': '', 'deh': '', 'nih': '', 'sih': '',
            'emg': 'memang', 'emang': 'memang', 'hrs': 'harus',
            'klo': 'kalau', 'kalo': 'kalau', 'kl': 'kalau',
            'tp': 'tetapi', 'tapi': 'tetapi', 'tp': 'tetapi',
            'krn': 'karena', 'krna': 'karena', 'soalnya': 'karena',
            'mksh': 'terima kasih', 'thx': 'terima kasih', 'tq': 'terima kasih',
            'ok': 'oke', 'oke': 'oke', 'okey': 'oke',
            'bgt': 'banget', 'bgt': 'banget', 'banged': 'banget',
            'brp': 'berapa', 'mw': 'mau', 'mo': 'mau',
        }
        
        # Basic stemming rules for Indonesian (simplified)
        self.prefix = ['me', 'di', 'ke', 'ter', 'ber', 'pe', 'se']
        self.suffix = ['kan', 'an', 'i', 'nya']
        
    def lowercase(self, text):
        """Convert to lowercase"""
        return text.lower()
    
    def remove_punctuation(self, text):
        """Remove punctuation"""
        return text.translate(str.maketrans('', '', string.punctuation))
    
    def remove_numbers(self, text):
        """Remove numbers"""
        return re.sub(r'\d+', '', text)
    
    def remove_whitespace(self, text):
        """Remove extra whitespace"""
        return ' '.join(text.split())
    
    def normalize_text(self, text):
        """Normalize informal words to formal Indonesian"""
        words = text.split()
        normalized = [self.normalization_dict.get(word, word) for word in words]
        return ' '.join(normalized)
    
    def remove_stopwords(self, text):
        """Remove stopwords"""
        words = text.split()
        filtered = [word for word in words if word not in self.stopwords]
        return ' '.join(filtered)
    
    def simple_stem(self, word):
        """Simple stemming for Indonesian (basic version)"""
        # Remove prefixes
        for prefix in self.prefix:
            if word.startswith(prefix) and len(word) > len(prefix) + 2:
                word = word[len(prefix):]
                break
        
        # Remove suffixes
        for suffix in self.suffix:
            if word.endswith(suffix) and len(word) > len(suffix) + 2:
                word = word[:-len(suffix)]
                break
        
        return word
    
    def stem_text(self, text):
        """Apply stemming to all words"""
        words = text.split()
        stemmed = [self.simple_stem(word) for word in words]
        return ' '.join(stemmed)
    
    def preprocess(self, text, remove_stopwords=True, apply_stemming=True):
        """Complete preprocessing pipeline"""
        # 1. Lowercase
        text = self.lowercase(text)
        
        # 2. Remove punctuation
        text = self.remove_punctuation(text)
        
        # 3. Remove numbers
        text = self.remove_numbers(text)
        
        # 4. Normalize informal words
        text = self.normalize_text(text)
        
        # 5. Remove extra whitespace
        text = self.remove_whitespace(text)
        
        # 6. Remove stopwords (optional)
        if remove_stopwords:
            text = self.remove_stopwords(text)
        
        # 7. Stemming (optional)
        if apply_stemming:
            text = self.stem_text(text)
        
        return text


class FeatureExtractor:
    """Extract features using TF-IDF"""
    
    def __init__(self, max_features=500):
        self.vectorizer = TfidfVectorizer(
            max_features=max_features,
            ngram_range=(1, 2),  # unigram and bigram
            min_df=1,
            max_df=0.8
        )
        
    def fit_transform(self, texts):
        """Fit and transform texts to TF-IDF features"""
        return self.vectorizer.fit_transform(texts)
    
    def transform(self, texts):
        """Transform texts to TF-IDF features"""
        return self.vectorizer.transform(texts)
    
    def save(self, filepath):
        """Save vectorizer"""
        with open(filepath, 'wb') as f:
            pickle.dump(self.vectorizer, f)
    
    def load(self, filepath):
        """Load vectorizer"""
        with open(filepath, 'rb') as f:
            self.vectorizer = pickle.load(f)


def load_and_preprocess_data(filepath, test_size=0.2, random_state=42):
    """Load dataset dan apply preprocessing"""
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import LabelEncoder
    
    # Load data
    df = pd.read_excel(filepath)
    
    print(f"Dataset loaded: {len(df)} samples")
    print(f"Intents: {df['intent'].unique()}")
    print(f"\nIntent distribution:\n{df['intent'].value_counts()}")
    
    # Initialize preprocessor
    preprocessor = IndonesianPreprocessor()
    
    # Preprocess texts
    print("\nPreprocessing texts...")
    df['text_cleaned'] = df['text'].apply(
        lambda x: preprocessor.preprocess(x, remove_stopwords=True, apply_stemming=True)
    )
    
    # Show examples
    print("\nPreprocessing examples:")
    for i in range(min(3, len(df))):
        print(f"\nOriginal: {df['text'].iloc[i]}")
        print(f"Cleaned:  {df['text_cleaned'].iloc[i]}")
    
    # Encode labels
    label_encoder = LabelEncoder()
    df['label'] = label_encoder.fit_transform(df['intent'])
    
    # Split data
    X = df['text_cleaned'].values
    y = df['label'].values
    
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state, stratify=y
    )
    
    print(f"\nTrain set: {len(X_train)} samples")
    print(f"Test set: {len(X_test)} samples")
    
    return X_train, X_test, y_train, y_test, label_encoder, preprocessor


if __name__ == "__main__":
    # Test preprocessing
    preprocessor = IndonesianPreprocessor()
    
    test_texts = [
        "Apa itu phishing dan bagaimana cara mencegahnya?",
        "Gmn sih cara bikin password yg kuat?",
        "Tolong jelasin tentang malware dong",
        "Kenapa harus pake 2FA?",
    ]
    
    print("Testing Preprocessor:\n")
    for text in test_texts:
        cleaned = preprocessor.preprocess(text)
        print(f"Original: {text}")
        print(f"Cleaned:  {cleaned}\n")
