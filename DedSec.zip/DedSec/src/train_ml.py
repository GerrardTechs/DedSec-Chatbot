"""
Machine Learning Model Training
Menggunakan: Naive Bayes, SVM, Random Forest
"""

import os
import pickle
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.naive_bayes import MultinomialNB
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    classification_report, 
    confusion_matrix, 
    accuracy_score,
    precision_recall_fscore_support
)
from sklearn.model_selection import cross_val_score
import sys

# Import preprocessing module
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from preprocessing import load_and_preprocess_data, FeatureExtractor


class MLChatbotTrainer:
    """Trainer untuk model Machine Learning"""
    
    def __init__(self, model_type='naive_bayes'):
        """
        Args:
            model_type: 'naive_bayes', 'svm', or 'random_forest'
        """
        self.model_type = model_type
        self.model = None
        self.feature_extractor = None
        self.label_encoder = None
        self.preprocessor = None
        
        # Initialize model
        if model_type == 'naive_bayes':
            self.model = MultinomialNB(alpha=1.0)
        elif model_type == 'svm':
            self.model = SVC(kernel='linear', probability=True, C=1.0)
        elif model_type == 'random_forest':
            self.model = RandomForestClassifier(n_estimators=100, random_state=42)
        else:
            raise ValueError("model_type must be 'naive_bayes', 'svm', or 'random_forest'")
    
    def train(self, X_train, y_train, label_encoder, preprocessor):
        """Train the model"""
        print(f"\n{'='*60}")
        print(f"Training {self.model_type.upper()} Model")
        print(f"{'='*60}")
        
        # Store encoder and preprocessor
        self.label_encoder = label_encoder
        self.preprocessor = preprocessor
        
        # Extract features using TF-IDF
        print("\nExtracting features with TF-IDF...")
        self.feature_extractor = FeatureExtractor(max_features=500)
        X_train_features = self.feature_extractor.fit_transform(X_train)
        
        print(f"Feature matrix shape: {X_train_features.shape}")
        
        # Train model
        print(f"\nTraining {self.model_type} model...")
        self.model.fit(X_train_features, y_train)
        
        # Cross-validation
        print("\nPerforming 5-fold cross-validation...")
        cv_scores = cross_val_score(self.model, X_train_features, y_train, cv=5)
        print(f"CV Scores: {cv_scores}")
        print(f"Mean CV Accuracy: {cv_scores.mean():.4f} (+/- {cv_scores.std() * 2:.4f})")
        
        print(f"\n{self.model_type.upper()} model training completed!")
        
    def evaluate(self, X_test, y_test):
        """Evaluate model on test set"""
        print(f"\n{'='*60}")
        print(f"Evaluating {self.model_type.upper()} Model")
        print(f"{'='*60}")
        
        # Transform test data
        X_test_features = self.feature_extractor.transform(X_test)
        
        # Predictions
        y_pred = self.model.predict(X_test_features)
        y_prob = self.model.predict_proba(X_test_features)
        
        # Calculate metrics
        accuracy = accuracy_score(y_test, y_pred)
        precision, recall, f1, _ = precision_recall_fscore_support(y_test, y_pred, average='weighted')
        
        print(f"\nTest Set Performance:")
        print(f"Accuracy:  {accuracy:.4f}")
        print(f"Precision: {precision:.4f}")
        print(f"Recall:    {recall:.4f}")
        print(f"F1-Score:  {f1:.4f}")
        
        # Classification report
        print(f"\nDetailed Classification Report:")
        intent_names = self.label_encoder.classes_
        print(classification_report(y_test, y_pred, target_names=intent_names))
        
        # Confusion matrix
        cm = confusion_matrix(y_test, y_pred)
        
        return {
            'accuracy': accuracy,
            'precision': precision,
            'recall': recall,
            'f1': f1,
            'confusion_matrix': cm,
            'y_pred': y_pred,
            'y_prob': y_prob
        }
    
    def predict(self, text):
        """Predict intent for a single text"""
        # Preprocess
        text_cleaned = self.preprocessor.preprocess(text)
        
        # Extract features
        text_features = self.feature_extractor.transform([text_cleaned])
        
        # Predict
        prediction = self.model.predict(text_features)[0]
        probabilities = self.model.predict_proba(text_features)[0]
        
        # Get intent name
        intent = self.label_encoder.inverse_transform([prediction])[0]
        confidence = probabilities[prediction]
        
        # Get top 3 predictions
        top_3_idx = np.argsort(probabilities)[-3:][::-1]
        top_3_intents = self.label_encoder.inverse_transform(top_3_idx)
        top_3_probs = probabilities[top_3_idx]
        
        return {
            'intent': intent,
            'confidence': confidence,
            'top_3': list(zip(top_3_intents, top_3_probs))
        }
    
    def save_model(self, filepath):
        """Save model, vectorizer, and encoders"""
        model_data = {
            'model': self.model,
            'feature_extractor': self.feature_extractor,
            'label_encoder': self.label_encoder,
            'preprocessor': self.preprocessor,
            'model_type': self.model_type
        }
        
        with open(filepath, 'wb') as f:
            pickle.dump(model_data, f)
        
        print(f"\nModel saved to: {filepath}")
    
    @classmethod
    def load_model(cls, filepath):
        """Load saved model"""
        with open(filepath, 'rb') as f:
            model_data = pickle.load(f)
        
        trainer = cls(model_type=model_data['model_type'])
        trainer.model = model_data['model']
        trainer.feature_extractor = model_data['feature_extractor']
        trainer.label_encoder = model_data['label_encoder']
        trainer.preprocessor = model_data['preprocessor']
        
        return trainer


def plot_confusion_matrix(cm, class_names, title, save_path):
    """Plot confusion matrix"""
    plt.figure(figsize=(12, 10))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                xticklabels=class_names, yticklabels=class_names)
    plt.title(title)
    plt.ylabel('True Intent')
    plt.xlabel('Predicted Intent')
    plt.xticks(rotation=45, ha='right')
    plt.yticks(rotation=0)
    plt.tight_layout()
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"Confusion matrix saved to: {save_path}")


def compare_models(results_dict, save_path):
    """Compare performance of different models"""
    models = list(results_dict.keys())
    metrics = ['accuracy', 'precision', 'recall', 'f1']
    
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    axes = axes.ravel()
    
    for idx, metric in enumerate(metrics):
        values = [results_dict[model][metric] for model in models]
        axes[idx].bar(models, values, color=['#1f77b4', '#ff7f0e', '#2ca02c'])
        axes[idx].set_title(f'{metric.capitalize()} Comparison', fontsize=12, fontweight='bold')
        axes[idx].set_ylabel(metric.capitalize())
        axes[idx].set_ylim([0, 1])
        axes[idx].grid(axis='y', alpha=0.3)
        
        # Add value labels on bars
        for i, v in enumerate(values):
            axes[idx].text(i, v + 0.02, f'{v:.4f}', ha='center', va='bottom')
    
    plt.tight_layout()
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"Model comparison saved to: {save_path}")


def main():
    """Main training pipeline"""
    
    # Paths
    data_path = '../data/dataset.xlsx'
    models_dir = '../models'
    os.makedirs(models_dir, exist_ok=True)
    
    print("="*70)
    print(" CHATBOT CYBERSECURITY - MACHINE LEARNING TRAINING ")
    print("="*70)
    
    # Load and preprocess data
    X_train, X_test, y_train, y_test, label_encoder, preprocessor = load_and_preprocess_data(
        data_path, test_size=0.2, random_state=42
    )
    
    # Store results
    results = {}
    
    # Train all three models
    model_types = ['naive_bayes', 'svm', 'random_forest']
    
    for model_type in model_types:
        print(f"\n\n{'#'*70}")
        print(f"# {model_type.upper().replace('_', ' ')}")
        print(f"{'#'*70}")
        
        # Initialize and train
        trainer = MLChatbotTrainer(model_type=model_type)
        trainer.train(X_train, y_train, label_encoder, preprocessor)
        
        # Evaluate
        eval_results = trainer.evaluate(X_test, y_test)
        results[model_type] = eval_results
        
        # Save model
        model_path = os.path.join(models_dir, f'{model_type}_model.pkl')
        trainer.save_model(model_path)
        
        # Plot confusion matrix
        cm_path = os.path.join(models_dir, f'{model_type}_confusion_matrix.png')
        plot_confusion_matrix(
            eval_results['confusion_matrix'],
            label_encoder.classes_,
            f'{model_type.upper().replace("_", " ")} - Confusion Matrix',
            cm_path
        )
        
        # Test predictions
        print(f"\n{'='*60}")
        print("Sample Predictions:")
        print(f"{'='*60}")
        test_queries = [
            "Apa itu phishing?",
            "Bagaimana cara membuat password yang aman?",
            "Jelaskan tentang firewall",
            "Terima kasih atas bantuannya"
        ]
        
        for query in test_queries:
            result = trainer.predict(query)
            print(f"\nQuery: {query}")
            print(f"Predicted Intent: {result['intent']} (confidence: {result['confidence']:.4f})")
            print(f"Top 3 predictions:")
            for intent, prob in result['top_3']:
                print(f"  - {intent}: {prob:.4f}")
    
    # Compare models
    print(f"\n\n{'#'*70}")
    print("# MODEL COMPARISON")
    print(f"{'#'*70}\n")
    
    comparison_data = {
        'Model': [],
        'Accuracy': [],
        'Precision': [],
        'Recall': [],
        'F1-Score': []
    }
    
    for model_type, result in results.items():
        comparison_data['Model'].append(model_type.upper().replace('_', ' '))
        comparison_data['Accuracy'].append(result['accuracy'])
        comparison_data['Precision'].append(result['precision'])
        comparison_data['Recall'].append(result['recall'])
        comparison_data['F1-Score'].append(result['f1'])
    
    comparison_df = pd.DataFrame(comparison_data)
    print(comparison_df.to_string(index=False))
    
    # Save comparison
    comparison_df.to_csv(os.path.join(models_dir, 'model_comparison.csv'), index=False)
    
    # Plot comparison
    comparison_path = os.path.join(models_dir, 'model_comparison.png')
    compare_models(results, comparison_path)
    
    # Find best model
    best_model = max(results.items(), key=lambda x: x[1]['accuracy'])
    print(f"\n{'='*60}")
    print(f"BEST MODEL: {best_model[0].upper().replace('_', ' ')}")
    print(f"Accuracy: {best_model[1]['accuracy']:.4f}")
    print(f"{'='*60}")
    
    print("\nTraining completed successfully!")
    print(f"Models saved in: {models_dir}")


if __name__ == "__main__":
    main()
