"""
Re-train Model dengan Preprocessing yang Lebih Baik
Fix: Model tidak akurat karena preprocessing terlalu agresif
"""

import os
import pickle
import pandas as pd
import re
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import classification_report, accuracy_score
import numpy as np


class BetterPreprocessor:
    """Preprocessing yang lebih gentle - pertahankan context penting"""
    
    def __init__(self):
        # Stopwords yang BENAR-BENAR tidak penting (very minimal)
        self.stopwords_minimal = set([
            'yang', 'untuk', 'pada', 'ke', 'para', 'namun', 'antara',
            'dia', 'dua', 'ia', 'seperti', 'jika', 'sehingga',
            'dan', 'atau', 'dengan', 'dari', 'akan', 'oleh',
            'nya', 'pun', 'lah', 'kah', 'tah'
        ])
        
        # JANGAN hapus: apa, itu, ini, bagaimana, kenapa, dll (important context!)
        
        # Normalisasi kata tidak baku
        self.normalization = {
            'gak': 'tidak', 'ga': 'tidak', 'ngga': 'tidak', 'nggak': 'tidak',
            'gmn': 'bagaimana', 'gimana': 'bagaimana', 'gmana': 'bagaimana',
            'knp': 'kenapa', 'knapa': 'kenapa',
            'udah': 'sudah', 'udh': 'sudah', 'dah': 'sudah',
            'yg': 'yang', 'dgn': 'dengan', 'utk': 'untuk',
            'bgmn': 'bagaimana', 'bsa': 'bisa', 'bs': 'bisa',
            'aja': 'saja', 'ajah': 'saja', 'aj': 'saja',
            'tdk': 'tidak', 'gk': 'tidak',
            'sy': 'saya', 'gue': 'saya', 'gw': 'saya',
            'lo': 'kamu', 'lu': 'kamu',
            'emg': 'memang', 'emang': 'memang',
            'klo': 'kalau', 'kalo': 'kalau',
            'tp': 'tetapi', 'tapi': 'tetapi',
            'krn': 'karena', 'krna': 'karena',
            'mksh': 'terima kasih', 'thx': 'terima kasih', 'tq': 'terima kasih',
            'bgt': 'banget', 'banged': 'banget',
            'brp': 'berapa', 'mw': 'mau', 'mo': 'mau',
            'jelasin': 'jelaskan', 'ksh tau': 'kasih tahu', 'kasi tau': 'kasih tahu',
            'dr': 'dari', 'sih': '', 'dong': '', 'deh': '', 'nih': ''
        }
    
    def preprocess(self, text):
        """Preprocessing yang mempertahankan context"""
        # 1. Lowercase
        text = text.lower()
        
        # 2. Normalisasi kata tidak baku
        words = text.split()
        normalized_words = [self.normalization.get(word, word) for word in words]
        text = ' '.join(normalized_words)
        
        # 3. Remove punctuation (tapi pertahankan space)
        text = re.sub(r'[^\w\s]', ' ', text)
        
        # 4. Remove extra whitespace
        text = ' '.join(text.split())
        
        # 5. MINIMAL stopword removal (hanya yang benar-benar tidak penting)
        words = text.split()
        filtered_words = [w for w in words if w not in self.stopwords_minimal]
        text = ' '.join(filtered_words)
        
        # TIDAK pakai stemming - pertahankan kata asli!
        
        return text


def retrain_models():
    """Re-train semua model dengan preprocessing yang lebih baik"""
    
    print("="*70)
    print(" RE-TRAINING MODELS DENGAN BETTER PREPROCESSING ")
    print("="*70)
    
    # Load dataset
    data_paths = [
        '../data/dataset.xlsx',
        'data/dataset.xlsx',
        '../DedSec/data/dataset.xlsx'
    ]
    
    dataset_path = None
    for path in data_paths:
        if os.path.exists(path):
            dataset_path = path
            break
    
    if dataset_path is None:
        print("ERROR: Dataset tidak ditemukan!")
        return
    
    print(f"\n✅ Loading dataset from: {dataset_path}")
    df = pd.read_excel(dataset_path)
    
    print(f"Dataset size: {len(df)} samples")
    print(f"Intents: {df['intent'].unique()}")
    print(f"\nIntent distribution:\n{df['intent'].value_counts()}")
    
    # Initialize better preprocessor
    preprocessor = BetterPreprocessor()
    
    # Preprocess texts
    print("\n🔄 Preprocessing texts...")
    df['text_cleaned'] = df['text'].apply(preprocessor.preprocess)
    
    # Show examples
    print("\n📝 Preprocessing examples:")
    for i in range(min(5, len(df))):
        print(f"\nOriginal: {df['text'].iloc[i]}")
        print(f"Cleaned:  {df['text_cleaned'].iloc[i]}")
    
    # Encode labels
    label_encoder = LabelEncoder()
    df['label'] = label_encoder.fit_transform(df['intent'])
    
    # Split data
    X = df['text_cleaned'].values
    y = df['label'].values
    
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    
    print(f"\n✅ Train set: {len(X_train)} samples")
    print(f"✅ Test set: {len(X_test)} samples")
    
    # Feature extraction with better parameters
    print("\n🔧 Extracting features with TF-IDF...")
    vectorizer = TfidfVectorizer(
        max_features=1000,  # Increased from 500
        ngram_range=(1, 3),  # Unigram, bigram, trigram
        min_df=1,
        max_df=0.9,
        sublinear_tf=True  # Better for short texts
    )
    
    X_train_features = vectorizer.fit_transform(X_train)
    X_test_features = vectorizer.transform(X_test)
    
    print(f"Feature matrix shape: {X_train_features.shape}")
    
    # Create models directory
    models_dir = '../models'
    if not os.path.exists(models_dir):
        # Try alternative paths
        if os.path.exists('models'):
            models_dir = 'models'
        elif os.path.exists('../DedSec/models'):
            models_dir = '../DedSec/models'
        else:
            models_dir = 'models'
            os.makedirs(models_dir, exist_ok=True)
    
    print(f"\n💾 Models will be saved to: {models_dir}")
    
    # Train models
    models = {
        'naive_bayes': MultinomialNB(alpha=0.5),  # Lower alpha for less smoothing
        'svm': SVC(kernel='linear', C=1.0, probability=True),
        'random_forest': RandomForestClassifier(n_estimators=200, random_state=42)
    }
    
    results = {}
    
    for model_name, model in models.items():
        print(f"\n{'='*70}")
        print(f" TRAINING: {model_name.upper()} ")
        print(f"{'='*70}")
        
        # Train
        print("Training...")
        model.fit(X_train_features, y_train)
        
        # Evaluate
        print("Evaluating...")
        y_pred = model.predict(X_test_features)
        accuracy = accuracy_score(y_test, y_pred)
        
        print(f"\n✅ Accuracy: {accuracy:.2%}")
        print("\nClassification Report:")
        print(classification_report(y_test, y_pred, target_names=label_encoder.classes_))
        
        # Save model
        model_data = {
            'model': model,
            'vectorizer': vectorizer,
            'label_encoder': label_encoder,
            'preprocessor': preprocessor,
            'accuracy': accuracy
        }
        
        model_path = os.path.join(models_dir, f'{model_name}_model.pkl')
        with open(model_path, 'wb') as f:
            pickle.dump(model_data, f)
        
        print(f"💾 Model saved: {model_path}")
        
        results[model_name] = accuracy
        
        # Test with sample questions
        print(f"\n🧪 Testing with sample questions:")
        test_questions = [
            "Apa itu phishing?",
            "Bagaimana cara membuat password kuat?",
            "Jelaskan tentang malware",
            "Terima kasih"
        ]
        
        for question in test_questions:
            # Preprocess
            q_cleaned = preprocessor.preprocess(question)
            q_features = vectorizer.transform([q_cleaned])
            
            # Predict
            pred = model.predict(q_features)[0]
            proba = model.predict_proba(q_features)[0]
            intent = label_encoder.inverse_transform([pred])[0]
            confidence = proba[pred]
            
            print(f"\nQ: {question}")
            print(f"Intent: {intent} ({confidence:.1%})")
    
    # Summary
    print(f"\n{'='*70}")
    print(" SUMMARY ")
    print(f"{'='*70}")
    print("\nModel Accuracies:")
    for model_name, accuracy in results.items():
        print(f"  {model_name}: {accuracy:.2%}")
    
    best_model = max(results.items(), key=lambda x: x[1])
    print(f"\n🏆 Best Model: {best_model[0]} ({best_model[1]:.2%})")
    
    print(f"\n✅ All models saved to: {models_dir}")
    print("✅ Re-training completed!")
    print("\nNext steps:")
    print("1. Run: streamlit run app.py")
    print("2. Test dengan pertanyaan yang sebelumnya error")
    print("3. Seharusnya akurasi jauh lebih baik sekarang!")


if __name__ == "__main__":
    retrain_models()
