"""
Deep Learning Model Training using LSTM
Nilai tambahan: Deep Learning implementation
"""

import os
import pickle
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import json

# Suppress TensorFlow warnings
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

try:
    import tensorflow as tf
    from tensorflow import keras
    from tensorflow.keras.models import Sequential, load_model
    from tensorflow.keras.layers import (
        Embedding, LSTM, Dense, Dropout, 
        Bidirectional, GlobalMaxPooling1D
    )
    from tensorflow.keras.preprocessing.text import Tokenizer
    from tensorflow.keras.preprocessing.sequence import pad_sequences
    from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, ReduceLROnPlateau
    from tensorflow.keras.utils import to_categorical
    TENSORFLOW_AVAILABLE = True
except ImportError:
    TENSORFLOW_AVAILABLE = False
    print("TensorFlow not available. Please install: pip install tensorflow")

from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
import sys

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from preprocessing import load_and_preprocess_data, IndonesianPreprocessor


class DLChatbotTrainer:
    """Deep Learning Trainer using LSTM"""
    
    def __init__(self, vocab_size=5000, embedding_dim=128, lstm_units=64, max_length=50):
        """
        Args:
            vocab_size: Maximum vocabulary size
            embedding_dim: Dimension of embedding layer
            lstm_units: Number of LSTM units
            max_length: Maximum sequence length
        """
        if not TENSORFLOW_AVAILABLE:
            raise ImportError("TensorFlow is required for Deep Learning model")
        
        self.vocab_size = vocab_size
        self.embedding_dim = embedding_dim
        self.lstm_units = lstm_units
        self.max_length = max_length
        
        self.model = None
        self.tokenizer = None
        self.label_encoder = None
        self.preprocessor = None
        self.history = None
        
    def prepare_sequences(self, texts, fit_tokenizer=False):
        """Convert texts to padded sequences"""
        
        if fit_tokenizer or self.tokenizer is None:
            self.tokenizer = Tokenizer(num_words=self.vocab_size, oov_token='<OOV>')
            self.tokenizer.fit_on_texts(texts)
            print(f"Vocabulary size: {len(self.tokenizer.word_index)}")
        
        sequences = self.tokenizer.texts_to_sequences(texts)
        padded = pad_sequences(sequences, maxlen=self.max_length, padding='post', truncating='post')
        
        return padded
    
    def build_model(self, num_classes):
        """Build LSTM model architecture"""
        
        model = Sequential([
            # Embedding layer
            Embedding(
                input_dim=self.vocab_size,
                output_dim=self.embedding_dim,
                input_length=self.max_length,
                name='embedding'
            ),
            
            # Bidirectional LSTM layers
            Bidirectional(LSTM(self.lstm_units, return_sequences=True), name='bilstm_1'),
            Dropout(0.3),
            
            Bidirectional(LSTM(self.lstm_units // 2), name='bilstm_2'),
            Dropout(0.3),
            
            # Dense layers
            Dense(64, activation='relu', name='dense_1'),
            Dropout(0.4),
            
            Dense(32, activation='relu', name='dense_2'),
            Dropout(0.3),
            
            # Output layer
            Dense(num_classes, activation='softmax', name='output')
        ])
        
        return model
    
    def train(self, X_train, y_train, X_val, y_val, label_encoder, preprocessor, epochs=50, batch_size=16):
        """Train the LSTM model"""
        
        print(f"\n{'='*60}")
        print("Training LSTM Deep Learning Model")
        print(f"{'='*60}")
        
        # Store preprocessor and encoder
        self.label_encoder = label_encoder
        self.preprocessor = preprocessor
        
        # Prepare sequences
        print("\nPreparing sequences...")
        X_train_seq = self.prepare_sequences(X_train, fit_tokenizer=True)
        X_val_seq = self.prepare_sequences(X_val, fit_tokenizer=False)
        
        print(f"Training sequences shape: {X_train_seq.shape}")
        print(f"Validation sequences shape: {X_val_seq.shape}")
        
        # One-hot encode labels
        num_classes = len(label_encoder.classes_)
        y_train_cat = to_categorical(y_train, num_classes=num_classes)
        y_val_cat = to_categorical(y_val, num_classes=num_classes)
        
        print(f"Number of classes: {num_classes}")
        
        # Build model
        print("\nBuilding LSTM model...")
        self.model = self.build_model(num_classes)
        
        # Compile model
        self.model.compile(
            optimizer='adam',
            loss='categorical_crossentropy',
            metrics=['accuracy']
        )
        
        print("\nModel Architecture:")
        self.model.summary()
        
        # Callbacks
        callbacks = [
            EarlyStopping(
                monitor='val_loss',
                patience=10,
                restore_best_weights=True,
                verbose=1
            ),
            ReduceLROnPlateau(
                monitor='val_loss',
                factor=0.5,
                patience=5,
                min_lr=1e-7,
                verbose=1
            )
        ]
        
        # Train model
        print(f"\nTraining for {epochs} epochs with batch size {batch_size}...")
        print("="*60)
        
        self.history = self.model.fit(
            X_train_seq, y_train_cat,
            validation_data=(X_val_seq, y_val_cat),
            epochs=epochs,
            batch_size=batch_size,
            callbacks=callbacks,
            verbose=1
        )
        
        print("\nTraining completed!")
    
    def evaluate(self, X_test, y_test):
        """Evaluate model on test set"""
        
        print(f"\n{'='*60}")
        print("Evaluating LSTM Model")
        print(f"{'='*60}")
        
        # Prepare sequences
        X_test_seq = self.prepare_sequences(X_test, fit_tokenizer=False)
        
        # One-hot encode
        num_classes = len(self.label_encoder.classes_)
        y_test_cat = to_categorical(y_test, num_classes=num_classes)
        
        # Evaluate
        test_loss, test_accuracy = self.model.evaluate(X_test_seq, y_test_cat, verbose=0)
        
        # Predictions
        y_pred_probs = self.model.predict(X_test_seq, verbose=0)
        y_pred = np.argmax(y_pred_probs, axis=1)
        
        # Metrics
        from sklearn.metrics import precision_recall_fscore_support
        precision, recall, f1, _ = precision_recall_fscore_support(y_test, y_pred, average='weighted')
        
        print(f"\nTest Set Performance:")
        print(f"Loss:      {test_loss:.4f}")
        print(f"Accuracy:  {test_accuracy:.4f}")
        print(f"Precision: {precision:.4f}")
        print(f"Recall:    {recall:.4f}")
        print(f"F1-Score:  {f1:.4f}")
        
        # Classification report
        print(f"\nDetailed Classification Report:")
        intent_names = self.label_encoder.classes_
        print(classification_report(y_test, y_pred, target_names=intent_names))
        
        # Confusion matrix
        cm = confusion_matrix(y_test, y_pred)
        
        return {
            'accuracy': test_accuracy,
            'precision': precision,
            'recall': recall,
            'f1': f1,
            'loss': test_loss,
            'confusion_matrix': cm,
            'y_pred': y_pred,
            'y_prob': y_pred_probs
        }
    
    def predict(self, text):
        """Predict intent for a single text"""
        
        # Preprocess
        text_cleaned = self.preprocessor.preprocess(text)
        
        # Prepare sequence
        text_seq = self.prepare_sequences([text_cleaned], fit_tokenizer=False)
        
        # Predict
        prediction_probs = self.model.predict(text_seq, verbose=0)[0]
        prediction = np.argmax(prediction_probs)
        
        # Get intent name
        intent = self.label_encoder.inverse_transform([prediction])[0]
        confidence = prediction_probs[prediction]
        
        # Get top 3 predictions
        top_3_idx = np.argsort(prediction_probs)[-3:][::-1]
        top_3_intents = self.label_encoder.inverse_transform(top_3_idx)
        top_3_probs = prediction_probs[top_3_idx]
        
        return {
            'intent': intent,
            'confidence': float(confidence),
            'top_3': list(zip(top_3_intents, [float(p) for p in top_3_probs]))
        }
    
    def save_model(self, model_path, tokenizer_path, metadata_path):
        """Save model and tokenizer"""
        
        # Save Keras model
        self.model.save(model_path)
        print(f"Model saved to: {model_path}")
        
        # Save tokenizer
        with open(tokenizer_path, 'wb') as f:
            pickle.dump(self.tokenizer, f)
        print(f"Tokenizer saved to: {tokenizer_path}")
        
        # Save metadata
        metadata = {
            'label_encoder': self.label_encoder,
            'preprocessor': self.preprocessor,
            'vocab_size': self.vocab_size,
            'embedding_dim': self.embedding_dim,
            'lstm_units': self.lstm_units,
            'max_length': self.max_length
        }
        
        with open(metadata_path, 'wb') as f:
            pickle.dump(metadata, f)
        print(f"Metadata saved to: {metadata_path}")
    
    @classmethod
    def load_model_from_files(cls, model_path, tokenizer_path, metadata_path):
        """Load saved model"""
        
        # Load Keras model
        model = load_model(model_path)
        
        # Load tokenizer
        with open(tokenizer_path, 'rb') as f:
            tokenizer = pickle.load(f)
        
        # Load metadata
        with open(metadata_path, 'rb') as f:
            metadata = pickle.load(f)
        
        # Create trainer instance
        trainer = cls(
            vocab_size=metadata['vocab_size'],
            embedding_dim=metadata['embedding_dim'],
            lstm_units=metadata['lstm_units'],
            max_length=metadata['max_length']
        )
        
        trainer.model = model
        trainer.tokenizer = tokenizer
        trainer.label_encoder = metadata['label_encoder']
        trainer.preprocessor = metadata['preprocessor']
        
        return trainer
    
    def plot_training_history(self, save_path):
        """Plot training history"""
        
        if self.history is None:
            print("No training history available")
            return
        
        fig, axes = plt.subplots(1, 2, figsize=(14, 5))
        
        # Accuracy plot
        axes[0].plot(self.history.history['accuracy'], label='Train Accuracy', linewidth=2)
        axes[0].plot(self.history.history['val_accuracy'], label='Val Accuracy', linewidth=2)
        axes[0].set_title('Model Accuracy', fontsize=14, fontweight='bold')
        axes[0].set_xlabel('Epoch')
        axes[0].set_ylabel('Accuracy')
        axes[0].legend()
        axes[0].grid(alpha=0.3)
        
        # Loss plot
        axes[1].plot(self.history.history['loss'], label='Train Loss', linewidth=2)
        axes[1].plot(self.history.history['val_loss'], label='Val Loss', linewidth=2)
        axes[1].set_title('Model Loss', fontsize=14, fontweight='bold')
        axes[1].set_xlabel('Epoch')
        axes[1].set_ylabel('Loss')
        axes[1].legend()
        axes[1].grid(alpha=0.3)
        
        plt.tight_layout()
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.close()
        print(f"Training history plot saved to: {save_path}")


def plot_confusion_matrix(cm, class_names, save_path):
    """Plot confusion matrix"""
    import seaborn as sns
    
    plt.figure(figsize=(12, 10))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                xticklabels=class_names, yticklabels=class_names)
    plt.title('LSTM Model - Confusion Matrix', fontsize=14, fontweight='bold')
    plt.ylabel('True Intent')
    plt.xlabel('Predicted Intent')
    plt.xticks(rotation=45, ha='right')
    plt.yticks(rotation=0)
    plt.tight_layout()
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"Confusion matrix saved to: {save_path}")


def main():
    """Main training pipeline for Deep Learning"""
    
    if not TENSORFLOW_AVAILABLE:
        print("TensorFlow is not available. Please install it to use Deep Learning models.")
        return
    
    # Paths
    data_path = '../data/dataset.xlsx'
    models_dir = '../models'
    os.makedirs(models_dir, exist_ok=True)
    
    print("="*70)
    print(" CHATBOT CYBERSECURITY - DEEP LEARNING (LSTM) TRAINING ")
    print("="*70)
    
    # Load and preprocess data
    X_train, X_test, y_train, y_test, label_encoder, preprocessor = load_and_preprocess_data(
        data_path, test_size=0.2, random_state=42
    )
    
    # Split train into train and validation
    from sklearn.model_selection import train_test_split
    X_train, X_val, y_train, y_val = train_test_split(
        X_train, y_train, test_size=0.15, random_state=42, stratify=y_train
    )
    
    print(f"\nFinal split:")
    print(f"Train: {len(X_train)}, Val: {len(X_val)}, Test: {len(X_test)}")
    
    # Initialize trainer
    trainer = DLChatbotTrainer(
        vocab_size=5000,
        embedding_dim=128,
        lstm_units=64,
        max_length=50
    )
    
    # Train model
    trainer.train(
        X_train, y_train,
        X_val, y_val,
        label_encoder, preprocessor,
        epochs=50,
        batch_size=16
    )
    
    # Plot training history
    history_path = os.path.join(models_dir, 'lstm_training_history.png')
    trainer.plot_training_history(history_path)
    
    # Evaluate on test set
    results = trainer.evaluate(X_test, y_test)
    
    # Save model
    model_path = os.path.join(models_dir, 'lstm_model.h5')
    tokenizer_path = os.path.join(models_dir, 'lstm_tokenizer.pkl')
    metadata_path = os.path.join(models_dir, 'lstm_metadata.pkl')
    
    trainer.save_model(model_path, tokenizer_path, metadata_path)
    
    # Plot confusion matrix
    cm_path = os.path.join(models_dir, 'lstm_confusion_matrix.png')
    plot_confusion_matrix(results['confusion_matrix'], label_encoder.classes_, cm_path)
    
    # Test predictions
    print(f"\n{'='*60}")
    print("Sample Predictions:")
    print(f"{'='*60}")
    
    test_queries = [
        "Apa itu phishing?",
        "Bagaimana cara membuat password yang aman?",
        "Jelaskan tentang firewall",
        "Terima kasih atas bantuannya",
        "Halo bot",
        "Bagaimana cara kerja enkripsi?"
    ]
    
    for query in test_queries:
        result = trainer.predict(query)
        print(f"\nQuery: {query}")
        print(f"Predicted Intent: {result['intent']} (confidence: {result['confidence']:.4f})")
        print(f"Top 3 predictions:")
        for intent, prob in result['top_3']:
            print(f"  - {intent}: {prob:.4f}")
    
    # Save results summary
    results_summary = {
        'model': 'LSTM',
        'accuracy': float(results['accuracy']),
        'precision': float(results['precision']),
        'recall': float(results['recall']),
        'f1': float(results['f1']),
        'loss': float(results['loss'])
    }
    
    with open(os.path.join(models_dir, 'lstm_results.json'), 'w') as f:
        json.dump(results_summary, f, indent=4)
    
    print(f"\n{'='*60}")
    print("LSTM Training completed successfully!")
    print(f"Model saved in: {models_dir}")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
