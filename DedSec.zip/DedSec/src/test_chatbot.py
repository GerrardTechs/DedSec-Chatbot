"""
Testing Script untuk Chatbot Cybersecurity
Test berbagai pertanyaan dan analisis response
"""

import pickle
import pandas as pd
import sys
import os

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from preprocessing import IndonesianPreprocessor

def load_ml_model(model_type='naive_bayes'):
    """Load ML model"""
    model_path = f'../models/{model_type}_model.pkl'
    
    if not os.path.exists(model_path):
        print(f"Model {model_type} not found!")
        return None
    
    with open(model_path, 'rb') as f:
        model_data = pickle.load(f)
    
    return model_data

def get_response(intent, dataset):
    """Get response from dataset"""
    responses = dataset[dataset['intent'] == intent]['response'].values
    if len(responses) > 0:
        return responses[0]
    return "Maaf, saya tidak memiliki jawaban untuk pertanyaan tersebut."

def predict_ml(text, model_data, dataset):
    """Predict using ML model"""
    preprocessor = model_data['preprocessor']
    feature_extractor = model_data['feature_extractor']
    model = model_data['model']
    label_encoder = model_data['label_encoder']
    
    # Preprocess
    text_cleaned = preprocessor.preprocess(text)
    
    # Extract features
    text_features = feature_extractor.transform([text_cleaned])
    
    # Predict
    prediction = model.predict(text_features)[0]
    probabilities = model.predict_proba(text_features)[0]
    
    # Get intent
    intent = label_encoder.inverse_transform([prediction])[0]
    confidence = probabilities[prediction]
    
    # Get response
    response = get_response(intent, dataset)
    
    # Top 3
    top_3_idx = probabilities.argsort()[-3:][::-1]
    top_3_intents = label_encoder.inverse_transform(top_3_idx)
    top_3_probs = probabilities[top_3_idx]
    
    return {
        'intent': intent,
        'confidence': confidence,
        'response': response,
        'top_3': list(zip(top_3_intents, top_3_probs))
    }

def main():
    """Main testing function"""
    
    print("="*70)
    print(" CHATBOT CYBERSECURITY - TESTING SCRIPT ")
    print("="*70)
    
    # Load dataset
    dataset = pd.read_excel('../data/dataset.xlsx')
    
    # Load model (default: naive_bayes)
    model_type = 'naive_bayes'
    model_data = load_ml_model(model_type)
    
    if not model_data:
        print("Please train the model first!")
        return
    
    print(f"\nModel loaded: {model_type.upper()}")
    print(f"Intents available: {', '.join(model_data['label_encoder'].classes_)}")
    
    # Test questions by intent
    test_cases = {
        'greeting': [
            "Halo bot",
            "Selamat pagi",
            "Hi, apa kabar?"
        ],
        'phishing': [
            "Apa itu phishing?",
            "Bagaimana cara mengenali email phishing?",
            "Gimana cara hindari phishing?",
            "Jelaskan tentang spear phishing"
        ],
        'malware': [
            "Apa itu malware?",
            "Bedanya virus sama worm apa?",
            "Bagaimana cara mencegah malware?",
            "Jelaskan tentang ransomware"
        ],
        'password_security': [
            "Bagaimana membuat password yang kuat?",
            "Apa itu two factor authentication?",
            "Aman gak nyimpen password di browser?",
            "Boleh pake password yang sama untuk semua akun?"
        ],
        'firewall': [
            "Apa itu firewall?",
            "Bagaimana cara kerja firewall?",
            "Kenapa perlu firewall?",
            "Apa beda hardware dan software firewall?"
        ],
        'encryption': [
            "Apa itu enkripsi?",
            "Jelaskan tentang AES encryption",
            "Bagaimana cara kerja HTTPS?",
            "Apa itu end-to-end encryption?"
        ],
        'network_security': [
            "Apa itu network security?",
            "Bagaimana mengamankan WiFi rumah?",
            "Apa itu VPN?",
            "Jelaskan tentang DDoS attack"
        ],
        'social_engineering': [
            "Apa itu social engineering?",
            "Jelaskan tentang pretexting",
            "Bahaya oversharing di social media apa?",
            "Apa itu shoulder surfing?"
        ],
        'incident_response': [
            "Apa itu incident response?",
            "Tahapan incident response apa saja?",
            "Apa yang dilakukan saat terdeteksi security breach?",
            "Jelaskan tentang forensik digital"
        ],
        'thanks': [
            "Terima kasih",
            "Makasih ya",
            "Thanks bot",
            "Sampai jumpa"
        ]
    }
    
    print("\n" + "="*70)
    print(" TESTING RESULTS ")
    print("="*70)
    
    total_correct = 0
    total_tests = 0
    
    for expected_intent, questions in test_cases.items():
        print(f"\n{'='*70}")
        print(f"Testing Intent: {expected_intent.upper()}")
        print(f"{'='*70}")
        
        correct = 0
        for question in questions:
            result = predict_ml(question, model_data, dataset)
            
            is_correct = result['intent'] == expected_intent
            status = "✓ CORRECT" if is_correct else "✗ INCORRECT"
            
            print(f"\nQuestion: {question}")
            print(f"Expected: {expected_intent}")
            print(f"Predicted: {result['intent']} ({result['confidence']:.2%}) {status}")
            
            if result['confidence'] < 0.5:
                print("⚠️  WARNING: Low confidence!")
            
            print(f"Top 3 predictions:")
            for intent, prob in result['top_3']:
                print(f"  - {intent}: {prob:.2%}")
            
            if is_correct:
                correct += 1
            
            total_tests += 1
        
        accuracy = correct / len(questions) * 100
        print(f"\nAccuracy for {expected_intent}: {correct}/{len(questions)} ({accuracy:.1f}%)")
        total_correct += correct
    
    # Overall results
    overall_accuracy = total_correct / total_tests * 100
    print(f"\n{'='*70}")
    print(f" OVERALL RESULTS ")
    print(f"{'='*70}")
    print(f"Total Tests: {total_tests}")
    print(f"Correct Predictions: {total_correct}")
    print(f"Overall Accuracy: {overall_accuracy:.2f}%")
    print(f"{'='*70}")
    
    # Edge cases testing
    print(f"\n{'='*70}")
    print(" EDGE CASES & CHALLENGING QUESTIONS ")
    print(f"{'='*70}")
    
    edge_cases = [
        "Apa bedanya phishing dan malware?",  # Multi-intent
        "Bagaimana cara mengamankan password dari social engineering?",  # Multi-intent
        "adwadawd",  # Gibberish
        "Berapa harga laptop?",  # Out of scope
        "gmn cara bikin firewallnya utk jaringan wifi di rmh biar aman dr hacker???"  # Informal + complex
    ]
    
    for question in edge_cases:
        result = predict_ml(question, model_data, dataset)
        
        print(f"\nQuestion: {question}")
        print(f"Predicted: {result['intent']} ({result['confidence']:.2%})")
        print(f"Top 3:")
        for intent, prob in result['top_3']:
            print(f"  - {intent}: {prob:.2%}")
        
        if result['confidence'] < 0.5:
            print("⚠️  Low confidence - might be out of scope or ambiguous")
    
    print(f"\n{'='*70}")
    print(" TESTING COMPLETED ")
    print(f"{'='*70}")

if __name__ == "__main__":
    main()
