# 🎥 PANDUAN VIDEO DEMO CHATBOT CYBERSECURITY

## Durasi: 5-7 Menit

---

## 📋 STRUKTUR VIDEO

### **SEGMENT 1: OPENING & INTRODUCTION (30-45 detik)**

**Visual:**
- Title slide dengan judul project
- Nama, NIM, Program Studi
- Logo universitas

**Narasi:**
```
"Selamat pagi/siang, perkenalkan nama saya [NAMA], NIM [NIM] dari [PROGRAM STUDI].

Pada kesempatan ini, saya akan mempresentasikan project saya yang berjudul 
'Pengembangan Chatbot Cybersecurity Berbasis Machine Learning'.

Project ini bertujuan untuk membangun chatbot yang dapat menjawab pertanyaan 
seputar keamanan siber menggunakan teknologi Natural Language Processing 
dan Machine Learning."
```

---

### **SEGMENT 2: OVERVIEW PROJECT (45-60 detik)**

**Visual:**
- Diagram alur project
- Statistik dataset
- Daftar teknologi yang digunakan

**Narasi:**
```
"Project ini menggunakan dataset yang saya buat sendiri berisi 100 sampel 
dengan 10 kategori intent cybersecurity, meliputi: phishing, malware, 
password security, firewall, encryption, network security, social engineering, 
incident response, dan lainnya.

Teknologi yang digunakan meliputi:
- Python sebagai bahasa pemrograman utama
- Scikit-learn untuk machine learning
- TensorFlow untuk deep learning
- Streamlit untuk deployment web application

Saya mengimplementasikan 4 model: Naive Bayes, SVM, Random Forest, 
dan LSTM untuk deep learning."
```

---

### **SEGMENT 3: DATASET & PREPROCESSING (60-75 detik)**

**Visual:**
- Screenshot Excel dataset
- Contoh data per intent
- Flowchart preprocessing

**Narasi:**
```
"Mari kita lihat dataset yang saya gunakan. [Tunjukkan Excel]

Dataset terdiri dari 3 kolom: intent, text (pertanyaan), dan response (jawaban).
Setiap intent memiliki 10 sampel pertanyaan dengan variasi yang berbeda.

[Tunjukkan contoh data beberapa intent]

Untuk preprocessing, saya menggunakan pipeline lengkap untuk Bahasa Indonesia:
1. Case folding - mengubah ke lowercase
2. Cleaning - menghapus tanda baca dan angka
3. Normalisasi - mengubah kata tidak baku menjadi baku
4. Stopword removal - menghapus kata-kata umum
5. Stemming - mengambil kata dasar

[Tunjukkan contoh sebelum dan sesudah preprocessing]

Preprocessing ini sangat penting untuk meningkatkan akurasi model."
```

---

### **SEGMENT 4: TRAINING MODELS (60-75 detik)**

**Visual:**
- Code snippet training
- Training progress/output
- Grafik training history (untuk LSTM)

**Narasi:**
```
"Sekarang kita masuk ke tahap training model.

[Jalankan train_ml.py atau tunjukkan hasil]

Saya melatih 3 model machine learning: Naive Bayes, SVM, dan Random Forest.
Model menggunakan TF-IDF untuk feature extraction, yang mengubah teks 
menjadi vektor numerik berdasarkan frekuensi kata.

Proses training memakan waktu sekitar [X] detik untuk semua model ML.

[Tunjukkan hasil training]

Untuk deep learning, saya menggunakan LSTM Bidirectional dengan arsitektur:
- Embedding layer untuk representasi kata
- 2 layer LSTM bidirectional
- Dense layers dengan dropout untuk regularisasi
- Output layer dengan 10 classes

[Tunjukkan training curves jika ada]

Model LSTM dilatih selama 50 epochs dengan early stopping untuk mencegah overfitting."
```

---

### **SEGMENT 5: EVALUASI & HASIL (75-90 detik)**

**Visual:**
- Tabel perbandingan metrics
- Confusion matrices
- Grafik perbandingan model

**Narasi:**
```
"Mari kita lihat hasil evaluasi model.

[Tunjukkan tabel metrics]

Model Naive Bayes mencapai akurasi [X]%
Model SVM mencapai akurasi [Y]%
Model Random Forest mencapai akurasi [Z]%
Dan model LSTM mencapai akurasi [W]%

[Tunjukkan confusion matrix terbaik]

Dari confusion matrix, kita bisa lihat bahwa model [BEST MODEL] memiliki 
performa terbaik dengan prediksi yang akurat untuk hampir semua intent.

[Tunjukkan classification report]

Precision, recall, dan F1-score juga menunjukkan performa yang baik,
dengan rata-rata di atas [X]%.

Beberapa intent seperti [INTENT] memiliki akurasi sempurna 100%, 
sementara [INTENT] masih ada sedikit confusion dengan [INTENT LAIN].

Secara keseluruhan, model [BEST MODEL] memberikan hasil terbaik dan 
akan digunakan untuk deployment."
```

---

### **SEGMENT 6: DEMO CHATBOT (90-120 detik)**

**Visual:**
- Launch Streamlit app
- Interface chatbot
- Test berbagai pertanyaan

**Narasi:**
```
"Sekarang mari kita lihat chatbot dalam aksi!

[Buka Streamlit app]

Ini adalah interface chatbot yang saya deploy menggunakan Streamlit.
Di sidebar, user bisa memilih model yang ingin digunakan.
Ada juga informasi tentang topik yang bisa ditanyakan.

Mari kita test dengan beberapa pertanyaan:

[Ketik: "Apa itu phishing?"]
Bot berhasil mendeteksi intent 'phishing' dengan confidence [X]% 
dan memberikan jawaban yang informatif tentang phishing.

[Ketik: "Bagaimana cara membuat password yang kuat?"]
Bot mendeteksi intent 'password_security' dan memberikan panduan 
lengkap tentang membuat password yang aman.

[Ketik: "Jelaskan tentang firewall"]
Bot memahami pertanyaan tentang firewall dan memberikan penjelasan 
yang mudah dipahami.

[Ketik pertanyaan informal: "gmn sih cara aman dr malware?"]
Bahkan dengan pertanyaan informal dan kata tidak baku, bot tetap 
bisa memahami dan memberikan jawaban yang tepat tentang malware.

[Ketik: "Terima kasih"]
Bot juga bisa handle sapaan dan ucapan terima kasih dengan natural.

Kita juga bisa lihat confidence score dan top 3 predictions untuk 
setiap response, yang menunjukkan seberapa yakin model dengan prediksinya."
```

---

### **SEGMENT 7: ANALISIS & DISKUSI (45-60 detik)**

**Visual:**
- Key findings
- Kelebihan dan kekurangan
- Perbandingan dengan penelitian lain (opsional)

**Narasi:**
```
"Dari hasil penelitian ini, beberapa temuan penting:

Pertama, preprocessing Bahasa Indonesia yang lengkap terbukti sangat efektif
dalam meningkatkan akurasi model. Normalisasi kata tidak baku menjadi baku
membantu model memahami variasi input yang berbeda.

Kedua, model deep learning LSTM memberikan performa terbaik dibandingkan
model ML tradisional, menunjukkan kemampuan LSTM dalam memahami 
konteks sequence yang lebih baik.

Ketiga, feature extraction menggunakan TF-IDF cukup efektif untuk 
dataset berukuran kecil hingga medium.

Kelebihan chatbot ini:
- Akurasi tinggi untuk intent yang telah dilatih
- Response cepat (< 1 detik)
- User-friendly interface
- Support Bahasa Indonesia dengan baik

Kekurangan:
- Dataset masih terbatas
- Belum bisa handle multi-intent questions
- Belum ada mechanism untuk out-of-scope questions

Untuk pengembangan kedepan, chatbot ini bisa ditingkatkan dengan:
- Dataset yang lebih besar dan beragam
- Implementasi context handling untuk multi-turn conversation
- Integrasi dengan knowledge base real-time
- User feedback mechanism untuk continuous learning"
```

---

### **SEGMENT 8: CLOSING (30-45 detik)**

**Visual:**
- Summary points
- Thank you slide
- Contact info (opsional)

**Narasi:**
```
"Sebagai kesimpulan, project ini berhasil mengembangkan chatbot cybersecurity
berbasis machine learning yang dapat:
- Memahami pertanyaan dalam Bahasa Indonesia
- Memberikan jawaban akurat tentang berbagai topik cybersecurity
- Mencapai akurasi [X]% pada test set
- Di-deploy dengan interface yang user-friendly

Project ini menunjukkan bahwa kombinasi NLP, machine learning, dan 
deep learning dapat digunakan untuk membangun chatbot edukatif yang
bermanfaat untuk meningkatkan awareness cybersecurity.

Terima kasih atas perhatiannya. Saya siap menjawab pertanyaan."
```

---

## 🎬 TIPS RECORDING

### **Persiapan:**
1. ✅ Test semua script dan aplikasi sebelum recording
2. ✅ Siapkan script narasi dan hafalkan poin-poin penting
3. ✅ Bersihkan desktop dan close aplikasi tidak perlu
4. ✅ Check audio quality (gunakan mic eksternal jika ada)
5. ✅ Gunakan resolusi minimal 1080p
6. ✅ Pastikan lighting bagus jika pakai webcam

### **During Recording:**
1. 🎤 Berbicara dengan jelas dan tidak terlalu cepat
2. 🖱️ Gerakan mouse smooth, tidak terlalu cepat
3. ⏸️ Pause sebentar saat transition antar segment
4. 👁️ Highlight area penting di screen (gunakan pointer/zoom)
5. 📊 Beri waktu cukup untuk viewer membaca grafik/tabel
6. 🔄 Jika salah, pause dan ulangi dari awal segment

### **Editing:**
1. ✂️ Cut bagian yang kurang perlu atau terlalu lama
2. 🎵 Tambahkan background music subtle (opsional)
3. 📝 Tambahkan text overlay untuk highlight poin penting
4. 🎨 Tambahkan transition smooth antar segment
5. 🔊 Normalize audio level
6. ✨ Tambahkan intro/outro slide professional

### **Software Recommendations:**
- **Screen Recording:** OBS Studio, Camtasia, ScreenFlow
- **Video Editing:** DaVinci Resolve, Adobe Premiere, Filmora
- **Audio:** Audacity (untuk improve audio quality)

---

## 📊 CHECKLIST CONTENT

### **Harus Ada:**
- ✅ Introduction diri dan project
- ✅ Overview dataset dan preprocessing
- ✅ Penjelasan model yang digunakan
- ✅ Hasil training dan evaluasi
- ✅ Demo chatbot dengan berbagai pertanyaan
- ✅ Analisis hasil dan discussion
- ✅ Kesimpulan

### **Nice to Have:**
- ✅ Visualisasi confusion matrix
- ✅ Training curves untuk LSTM
- ✅ Perbandingan metrics antar model
- ✅ Code snippet penting
- ✅ Future improvements

---

## 🎯 EVALUASI CRITERIA

Video Anda akan dinilai berdasarkan:

1. **Clarity (25%)** - Penjelasan jelas dan mudah dipahami
2. **Technical Depth (25%)** - Menunjukkan pemahaman teknis yang baik
3. **Demonstration (25%)** - Demo efektif dan comprehensive
4. **Presentation Quality (15%)** - Audio-visual quality dan struktur
5. **Time Management (10%)** - Durasi sesuai (5-7 menit)

---

## 💡 EXAMPLE SCRIPT OUTLINE

```
00:00 - 00:30  | Opening & Title
00:30 - 01:15  | Project Overview
01:15 - 02:15  | Dataset & Preprocessing
02:15 - 03:15  | Training Models
03:15 - 04:15  | Evaluation Results
04:15 - 06:00  | Chatbot Demo
06:00 - 06:45  | Discussion & Analysis
06:45 - 07:00  | Closing
```

---

## 📝 NOTES

- Sesuaikan narasi dengan hasil aktual penelitian Anda
- Tunjukkan enthusiasm dan confidence
- Fokus pada highlights, tidak perlu detail berlebihan
- Pastikan semua visual clear dan readable
- Practice beberapa kali sebelum final recording

**Good luck with your video demo! 🎬🚀**
