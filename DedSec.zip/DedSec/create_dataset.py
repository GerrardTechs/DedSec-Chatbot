import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

# Dataset lengkap dengan 10 intent dan variasi pertanyaan
dataset = {
    'intent': [],
    'text': [],
    'response': []
}

# 1. GREETING
greetings = [
    ("Halo", "Halo! Saya chatbot cybersecurity. Ada yang bisa saya bantu terkait keamanan siber?"),
    ("Hi", "Hi! Saya siap membantu Anda dengan pertanyaan seputar cybersecurity."),
    ("Selamat pagi", "Selamat pagi! Ada pertanyaan tentang keamanan siber yang ingin Anda tanyakan?"),
    ("Hai bot", "Hai! Saya di sini untuk membantu dengan informasi cybersecurity. Silakan tanya!"),
    ("Permisi", "Ya, ada yang bisa saya bantu?"),
    ("Assalamualaikum", "Waalaikumsalam! Silakan tanyakan seputar cybersecurity."),
    ("Halo chatbot", "Halo! Saya chatbot khusus cybersecurity. Ada yang ingin ditanyakan?"),
    ("Selamat siang", "Selamat siang! Bagaimana saya bisa membantu Anda hari ini?"),
    ("Hei", "Hei! Ada pertanyaan tentang keamanan komputer?"),
    ("Apa kabar", "Baik! Saya siap membantu dengan pertanyaan cybersecurity Anda."),
]

for text, response in greetings:
    dataset['intent'].append('greeting')
    dataset['text'].append(text)
    dataset['response'].append(response)

# 2. PHISHING
phishing_data = [
    ("Apa itu phishing?", "Phishing adalah teknik penipuan siber yang menggunakan email, pesan, atau situs web palsu untuk mencuri informasi sensitif seperti password, nomor kartu kredit, atau data pribadi lainnya dengan menyamar sebagai entitas terpercaya."),
    ("Bagaimana cara mengenali email phishing?", "Ciri-ciri email phishing: 1) Pengirim tidak dikenal atau mencurigakan, 2) Berisi link atau attachment mencurigakan, 3) Ada kesalahan ejaan atau grammar, 4) Meminta informasi pribadi atau finansial, 5) Menggunakan ancaman atau urgensi berlebihan, 6) Alamat email tidak sesuai domain resmi."),
    ("Apa yang harus dilakukan jika menerima email phishing?", "Jika menerima email phishing: 1) Jangan klik link atau buka attachment, 2) Jangan balas atau berikan informasi pribadi, 3) Laporkan ke tim IT atau admin email, 4) Hapus email tersebut, 5) Jika sudah klik link, segera ganti password dan scan komputer Anda."),
    ("Jelaskan tentang spear phishing", "Spear phishing adalah jenis phishing yang lebih tertarget, di mana penyerang melakukan riset terlebih dahulu tentang korban spesifik dan membuat pesan yang sangat personal dan meyakinkan. Lebih berbahaya karena tampak sangat legitimate."),
    ("Apa beda phishing dan smishing?", "Phishing dilakukan via email, sedangkan smishing (SMS phishing) dilakukan via SMS atau pesan teks. Keduanya bertujuan mencuri informasi dengan cara menipu korban, namun media yang digunakan berbeda."),
    ("Bagaimana melindungi diri dari phishing?", "Cara melindungi diri: 1) Jangan sembarangan klik link, 2) Verifikasi pengirim sebelum memberi info, 3) Gunakan two-factor authentication, 4) Update software security, 5) Gunakan email filter, 6) Edukasi diri tentang teknik phishing terbaru."),
    ("Apakah phishing berbahaya?", "Ya, phishing sangat berbahaya karena dapat menyebabkan: pencurian identitas, kerugian finansial, kebocoran data pribadi/perusahaan, akses tidak sah ke akun, dan penyebaran malware. Banyak serangan siber dimulai dari phishing."),
    ("Contoh serangan phishing", "Contoh: Email mengaku dari bank meminta verifikasi akun dengan klik link, padahal link menuju situs palsu untuk mencuri kredensial. Atau email mengaku dari HR meminta isi formulir data karyawan yang sebenarnya phishing."),
    ("Apa itu vishing?", "Vishing (voice phishing) adalah phishing melalui telepon. Penyerang menelepon korban dan berpura-pura dari institusi terpercaya untuk meminta informasi sensitif atau meminta korban melakukan transfer uang."),
    ("Bagaimana cara kerja phishing?", "Cara kerja: 1) Penyerang membuat email/web palsu mirip asli, 2) Kirim ke banyak target, 3) Korban tertipu dan klik link/isi form, 4) Kredensial atau data dicuri, 5) Penyerang gunakan data untuk akses tidak sah atau dijual ke dark web."),
]

for text, response in phishing_data:
    dataset['intent'].append('phishing')
    dataset['text'].append(text)
    dataset['response'].append(response)

# 3. MALWARE
malware_data = [
    ("Apa itu malware?", "Malware (malicious software) adalah perangkat lunak berbahaya yang dirancang untuk merusak, mengeksploitasi, atau mendapatkan akses tidak sah ke sistem komputer. Jenis malware meliputi virus, worm, trojan, ransomware, spyware, dan adware."),
    ("Jelaskan tentang ransomware", "Ransomware adalah jenis malware yang mengenkripsi file korban dan meminta tebusan (ransom) untuk mendekripsi kembali. Contoh terkenal: WannaCry, Petya. Sangat berbahaya karena dapat melumpuhkan operasional organisasi."),
    ("Apa beda virus dan worm?", "Virus memerlukan file host untuk menyebar dan perlu aksi user untuk aktif. Worm dapat menyebar sendiri melalui jaringan tanpa perlu file host atau interaksi user, sehingga lebih cepat menyebar dan lebih berbahaya."),
    ("Bagaimana cara mencegah malware?", "Pencegahan malware: 1) Install antivirus/antimalware terpercaya, 2) Update OS dan software rutin, 3) Jangan download dari sumber tidak terpercaya, 4) Hati-hati dengan email attachment, 5) Gunakan firewall, 6) Backup data secara berkala, 7) Hindari USB tidak dikenal."),
    ("Apa itu trojan horse?", "Trojan horse adalah malware yang menyamar sebagai software legitimate untuk menipu user agar menginstallnya. Setelah terinstall, trojan dapat membuka backdoor untuk hacker, mencuri data, atau menginstal malware lain tanpa sepengetahuan user."),
    ("Bagaimana cara mendeteksi malware di komputer?", "Tanda-tanda malware: 1) Komputer lambat tiba-tiba, 2) Program crash sering, 3) Pop-up tidak normal, 4) Disk space berkurang drastis, 5) File hilang/corrupt, 6) Aktivitas jaringan tinggi tidak wajar, 7) Antivirus disabled sendiri. Gunakan antimalware scan untuk memastikan."),
    ("Apa itu spyware?", "Spyware adalah malware yang mengintai dan mengumpulkan informasi tentang user tanpa sepengetahuan mereka, seperti kebiasaan browsing, keystroke, kredensial login, dan data pribadi lainnya. Data ini kemudian dikirim ke penyerang."),
    ("Jelaskan tentang rootkit", "Rootkit adalah malware yang memberikan akses tingkat administrator/root kepada penyerang sambil menyembunyikan keberadaannya. Sangat sulit dideteksi karena dapat memodifikasi OS dan bersembunyi dari antivirus."),
    ("Apa yang dilakukan jika terinfeksi malware?", "Langkah mengatasi: 1) Disconnect dari internet/jaringan, 2) Masuk safe mode, 3) Hapus temporary files, 4) Scan dengan antimalware terpercaya, 5) Hapus malware terdeteksi, 6) Reset password penting, 7) Update semua software, 8) Monitor sistem beberapa hari ke depan."),
    ("Bagaimana malware menyebar?", "Cara penyebaran: 1) Email attachment berbahaya, 2) Download dari website tidak aman, 3) Exploit vulnerabilities software, 4) USB/external drive terinfeksi, 5) Iklan online jahat (malvertising), 6) Social engineering, 7) Network berbagi file tidak aman."),
]

for text, response in malware_data:
    dataset['intent'].append('malware')
    dataset['text'].append(text)
    dataset['response'].append(response)

# 4. PASSWORD SECURITY
password_data = [
    ("Bagaimana membuat password yang kuat?", "Password kuat harus: 1) Minimal 12-16 karakter, 2) Kombinasi huruf besar-kecil, angka, simbol, 3) Tidak menggunakan info pribadi (nama, tanggal lahir), 4) Tidak menggunakan kata umum/kamus, 5) Unik untuk setiap akun, 6) Hindari pola keyboard (qwerty, 12345). Contoh: M@1nK4n!p@g1#2024."),
    ("Apa itu two factor authentication?", "Two-factor authentication (2FA) adalah lapisan keamanan tambahan yang memerlukan dua bentuk verifikasi: sesuatu yang Anda tahu (password) dan sesuatu yang Anda miliki (kode SMS, app authenticator, biometrik). Sangat disarankan untuk akun penting."),
    ("Apakah aman menyimpan password di browser?", "Menyimpan password di browser kurang aman karena: 1) Rentan jika komputer terinfeksi malware, 2) Bisa diakses siapa saja yang buka komputer Anda, 3) Sync ke cloud bisa berisiko jika akun diretas. Lebih baik gunakan password manager khusus dengan enkripsi kuat."),
    ("Seberapa sering harus ganti password?", "Rekomendasi modern: Ganti password hanya jika: 1) Ada indikasi breach/kompromi, 2) Password lemah/mudah ditebak, 3) Dibagikan ke orang lain. Tidak perlu rutin 30-90 hari jika passwordnya sudah kuat dan unik, karena justru membuat user cenderung pilih password lemah."),
    ("Apa itu password manager?", "Password manager adalah aplikasi untuk menyimpan dan mengelola password dengan aman menggunakan enkripsi. Anda hanya perlu ingat satu master password. Fitur: generate password kuat, autofill, audit keamanan password. Contoh: 1Password, Bitwarden, LastPass, KeePass."),
    ("Bolehkah menggunakan password yang sama untuk banyak akun?", "Tidak boleh! Menggunakan password sama sangat berbahaya karena jika satu akun diretas, semua akun lain juga terancam (credential stuffing attack). Gunakan password unik untuk setiap akun, dibantu dengan password manager."),
    ("Apa itu brute force attack?", "Brute force attack adalah metode hacking yang mencoba semua kombinasi password hingga menemukan yang benar. Cara mencegah: 1) Gunakan password panjang dan kompleks, 2) Aktifkan account lockout setelah gagal login beberapa kali, 3) Gunakan CAPTCHA, 4) Aktifkan 2FA."),
    ("Jelaskan tentang passphrase", "Passphrase adalah password berupa rangkaian kata atau kalimat yang panjang tapi mudah diingat, seperti 'SayaSukaKopiPanasDiPagiHari!23'. Lebih aman daripada password pendek kompleks karena panjangnya, dan lebih mudah diingat daripada string acak."),
    ("Apa bahaya password yang lemah?", "Password lemah membuat akun mudah diretas melalui: 1) Brute force attack, 2) Dictionary attack, 3) Social engineering, 4) Credential stuffing. Akibatnya: pencurian identitas, akses tidak sah ke data pribadi/finansial, penyalahgunaan akun untuk aktivitas kriminal."),
    ("Bagaimana cara mengamankan password?", "Cara mengamankan: 1) Gunakan password unik dan kuat untuk tiap akun, 2) Aktifkan 2FA/MFA, 3) Jangan share password, 4) Gunakan password manager, 5) Jangan tulis password di tempat terlihat, 6) Ganti jika curiga kompromi, 7) Hindari WiFi publik saat login akun penting."),
]

for text, response in password_data:
    dataset['intent'].append('password_security')
    dataset['text'].append(text)
    dataset['response'].append(response)

# 5. FIREWALL
firewall_data = [
    ("Apa itu firewall?", "Firewall adalah sistem keamanan jaringan yang memonitor dan mengontrol lalu lintas jaringan berdasarkan aturan keamanan yang telah ditentukan. Firewall bertindak sebagai barrier antara jaringan internal yang aman dan jaringan eksternal (internet) yang tidak terpercaya."),
    ("Bagaimana cara kerja firewall?", "Firewall bekerja dengan: 1) Memeriksa setiap paket data yang masuk/keluar, 2) Membandingkan dengan aturan keamanan (rules), 3) Mengizinkan atau memblokir berdasarkan rules tersebut, 4) Logging aktivitas untuk monitoring. Filter berdasarkan IP address, port, protokol, dan konten."),
    ("Apa beda hardware dan software firewall?", "Hardware firewall adalah perangkat fisik terpisah yang ditempatkan antara jaringan dan internet, cocok untuk melindungi seluruh jaringan. Software firewall adalah program yang diinstall di komputer individual, cocok untuk proteksi personal. Idealnya gunakan keduanya."),
    ("Apakah Windows Firewall cukup aman?", "Windows Firewall cukup untuk proteksi dasar user rumahan jika dikonfigurasi dengan benar. Namun untuk keamanan lebih tinggi atau bisnis, disarankan menambah: 1) Third-party firewall lebih advanced, 2) Hardware firewall, 3) IDS/IPS system, 4) Antivirus/antimalware."),
    ("Apa itu next generation firewall?", "Next Generation Firewall (NGFW) adalah firewall modern yang tidak hanya filter packet tradisional, tapi juga: 1) Deep packet inspection, 2) Application awareness & control, 3) Intrusion prevention system (IPS), 4) Malware detection, 5) SSL/TLS inspection. Lebih canggih dari traditional firewall."),
    ("Kenapa perlu firewall?", "Firewall penting untuk: 1) Blokir akses tidak sah ke jaringan, 2) Mencegah malware masuk, 3) Kontrol aplikasi yang boleh akses internet, 4) Monitor traffic mencurigakan, 5) Proteksi dari DDoS attack, 6) Compliance dengan regulasi keamanan data. Lini pertahanan keamanan siber."),
    ("Apa itu stateful vs stateless firewall?", "Stateless firewall memeriksa setiap paket secara independen tanpa context. Stateful firewall melacak state koneksi dan lebih intelligent dalam decision making, bisa bedakan paket legitimate dalam session vs unsolicited. Stateful lebih aman dan efisien."),
    ("Bagaimana mengkonfigurasi firewall dengan benar?", "Best practices: 1) Deny all, allow specific (default deny), 2) Blokir unused ports, 3) Whitelist IP terpercaya, 4) Enable logging, 5) Regular review rules, 6) Segment network dengan firewall, 7) Update firmware rutin, 8) Test konfigurasi dengan penetration testing."),
    ("Apa keterbatasan firewall?", "Keterbatasan: 1) Tidak bisa deteksi ancaman dalam encrypted traffic tanpa SSL inspection, 2) Tidak proteksi dari insider threats, 3) Tidak bisa blokir malware dalam allowed traffic, 4) Perlu kombinasi dengan tools lain (IDS, antivirus, EDR) untuk proteksi komprehensif."),
    ("Apa itu WAF (Web Application Firewall)?", "WAF adalah firewall khusus untuk melindungi aplikasi web dari serangan seperti SQL injection, XSS, CSRF, dan vulnerabilities OWASP Top 10. Bekerja di layer aplikasi (Layer 7), memeriksa HTTP/HTTPS traffic secara detail. Penting untuk keamanan web application."),
]

for text, response in firewall_data:
    dataset['intent'].append('firewall')
    dataset['text'].append(text)
    dataset['response'].append(response)

# 6. ENCRYPTION
encryption_data = [
    ("Apa itu enkripsi?", "Enkripsi adalah proses mengubah data plaintext (terbaca) menjadi ciphertext (terenkripsi) menggunakan algoritma dan kunci tertentu, sehingga hanya pihak yang memiliki kunci dekripsi yang dapat membaca data asli. Essential untuk melindungi kerahasiaan data."),
    ("Jelaskan tentang enkripsi simetris", "Enkripsi simetris menggunakan kunci yang sama untuk enkripsi dan dekripsi. Lebih cepat dan efisien untuk data besar. Contoh algoritma: AES, DES, 3DES. Tantangan: distribusi kunci yang aman. Cocok untuk enkripsi data storage dan komunikasi private."),
    ("Apa itu enkripsi asimetris?", "Enkripsi asimetris menggunakan sepasang kunci: public key (untuk enkripsi) dan private key (untuk dekripsi). Data dienkripsi dengan public key hanya bisa didekripsi dengan private key pasangannya. Contoh: RSA, ECC. Digunakan untuk key exchange dan digital signature."),
    ("Bagaimana cara kerja HTTPS?", "HTTPS menggunakan SSL/TLS untuk enkripsi komunikasi web. Prosesnya: 1) Browser request koneksi aman, 2) Server kirim certificate SSL, 3) Browser verifikasi certificate, 4) Kedua pihak establish encrypted session dengan symmetric key, 5) Data ditransmisikan terenkripsi. Melindungi dari eavesdropping dan MITM attack."),
    ("Apa itu end-to-end encryption?", "End-to-end encryption (E2EE) adalah enkripsi di mana data dienkripsi di device pengirim dan hanya bisa didekripsi di device penerima. Pihak ketiga (termasuk service provider) tidak bisa baca data. Contoh: WhatsApp, Signal. Sangat aman untuk komunikasi pribadi."),
    ("Jelaskan tentang AES encryption", "AES (Advanced Encryption Standard) adalah algoritma enkripsi simetris yang paling banyak digunakan saat ini. Menggunakan key size 128, 192, atau 256 bit. Sangat cepat dan aman, disetujui oleh NIST untuk data rahasia pemerintah. Standard industri untuk enkripsi data."),
    ("Apa itu hashing dan bedanya dengan enkripsi?", "Hashing adalah one-way function yang mengubah data menjadi fixed-size hash value yang tidak bisa dikembalikan ke data asli. Enkripsi two-way (bisa didekripsi). Hashing untuk: verifikasi integritas data, password storage, digital signature. Contoh algoritma: SHA-256, MD5, bcrypt."),
    ("Kenapa perlu enkripsi data?", "Enkripsi penting untuk: 1) Melindungi confidentiality data sensitif, 2) Compliance dengan regulasi (GDPR, HIPAA), 3) Proteksi saat transmisi data, 4) Keamanan data tersimpan jika storage dicuri, 5) Mencegah data breach merugikan, 6) Build trust dengan customer/stakeholder."),
    ("Apa itu VPN dan bagaimana enkripsinya?", "VPN (Virtual Private Network) membuat tunnel terenkripsi antara device Anda dan server VPN, menyembunyikan IP dan enkripsi semua internet traffic. Menggunakan protokol seperti OpenVPN, IPSec, WireGuard. Melindungi privasi dan keamanan, terutama di WiFi publik."),
    ("Bagaimana mengenkripsi file dan folder?", "Cara enkripsi: 1) Windows: BitLocker untuk drive encryption, EFS untuk file/folder, 2) macOS: FileVault untuk disk, 3) Linux: LUKS, dm-crypt, 4) Tools third-party: VeraCrypt, 7-Zip (with password), GPG. Pastikan backup encryption key/password dengan aman!"),
]

for text, response in encryption_data:
    dataset['intent'].append('encryption')
    dataset['text'].append(text)
    dataset['response'].append(response)

# 7. NETWORK SECURITY
network_security_data = [
    ("Apa itu network security?", "Network security adalah praktik melindungi jaringan komputer dari ancaman, akses tidak sah, penyalahgunaan, dan gangguan. Meliputi hardware, software, dan policies untuk menjaga confidentiality, integrity, dan availability data dalam jaringan."),
    ("Jelaskan tentang VPN untuk keamanan jaringan", "VPN menciptakan koneksi terenkripsi melalui internet, menyembunyikan IP address dan mengamankan data transmisi. Penting untuk: remote work aman, bypass geo-restriction, proteksi di WiFi publik. Jenis: Remote Access VPN, Site-to-Site VPN. Pilih provider terpercaya dengan no-logs policy."),
    ("Apa itu intrusion detection system (IDS)?", "IDS adalah sistem yang memonitor network traffic untuk mendeteksi aktivitas mencurigakan atau policy violation. Jenis: 1) NIDS (Network-based) - monitor seluruh network, 2) HIDS (Host-based) - monitor individual device. Memberikan alert saat terdeteksi ancaman. Contoh: Snort, Suricata."),
    ("Bagaimana mengamankan WiFi rumah?", "Cara amankan WiFi: 1) Ganti default admin password router, 2) Gunakan WPA3 atau minimal WPA2 encryption, 3) Buat password WiFi kuat, 4) Sembunyikan SSID jika perlu, 5) Enable firewall router, 6) Disable WPS, 7) Update firmware router rutin, 8) Gunakan guest network untuk tamu."),
    ("Apa itu DMZ dalam network security?", "DMZ (Demilitarized Zone) adalah subnet terpisah yang menambah layer keamanan antara jaringan internal dan eksternal. Server yang perlu akses public (web, email, DNS) ditempatkan di DMZ, terisolasi dari internal network. Jika DMZ dikompromi, internal network tetap aman."),
    ("Jelaskan tentang network segmentation", "Network segmentation membagi jaringan besar menjadi sub-network lebih kecil untuk meningkatkan keamanan dan performance. Benefit: 1) Batasi lateral movement attacker, 2) Kontrol akses lebih granular, 3) Isolasi sistem critical, 4) Mudah monitor dan manage. Implementasi dengan VLAN, subnet, firewalls."),
    ("Apa itu DDoS attack dan cara mencegahnya?", "DDoS (Distributed Denial of Service) adalah serangan yang membanjiri target dengan traffic untuk melumpuhkan layanan. Pencegahan: 1) Gunakan DDoS protection service (Cloudflare, AWS Shield), 2) Configure rate limiting, 3) Implement traffic filtering, 4) Increase bandwidth, 5) Use CDN, 6) Monitor traffic patterns."),
    ("Apa itu port scanning dan bahayanya?", "Port scanning adalah teknik untuk menemukan port terbuka pada sistem target, sering digunakan attacker untuk reconnaissance sebelum serangan. Port terbuka bisa jadi celah masuk. Proteksi: tutup unused ports, gunakan firewall, implement port knocking, monitor dengan IDS."),
    ("Bagaimana cara kerja SSL/TLS?", "SSL/TLS mengamankan komunikasi internet melalui: 1) Handshake protocol - establish secure connection, 2) Authentication - verifikasi identitas server dengan certificate, 3) Key exchange - sepakati encryption key, 4) Data encryption - enkripsi data transmisi. Proteksi dari eavesdropping dan tampering."),
    ("Apa itu zero trust security model?", "Zero Trust adalah model keamanan yang tidak trust siapapun/apapun by default, bahkan dalam internal network. Prinsip: 'never trust, always verify'. Setiap user, device, dan request harus autentikasi dan autorisasi. Implementasi: MFA, least privilege access, micro-segmentation, continuous monitoring."),
]

for text, response in network_security_data:
    dataset['intent'].append('network_security')
    dataset['text'].append(text)
    dataset['response'].append(response)

# 8. SOCIAL ENGINEERING
social_engineering_data = [
    ("Apa itu social engineering?", "Social engineering adalah manipulasi psikologis untuk menipu orang agar memberikan informasi rahasia atau melakukan tindakan yang mengkompromikan keamanan. Mengeksploitasi sifat manusia (trust, rasa ingin tahu, takut) daripada technical vulnerabilities. Sangat berbahaya karena sulit dideteksi teknologi."),
    ("Jelaskan tentang pretexting", "Pretexting adalah teknik social engineering di mana attacker membuat skenario palsu (pretext) untuk mendapatkan informasi. Contoh: menelepon mengaku dari IT support meminta password untuk 'maintenance', atau mengaku dari bank untuk 'verifikasi'. Selalu verifikasi identitas sebelum berikan info."),
    ("Apa itu baiting dalam social engineering?", "Baiting adalah teknik yang menggunakan 'umpan' untuk memikat korban. Contoh fisik: meninggalkan USB infected malware di tempat umum dengan label menarik, berharap ada yang colok ke komputer. Contoh digital: menawarkan free download/hadiah yang sebenarnya malware. Jangan tergiur sesuatu yang 'terlalu bagus'."),
    ("Bagaimana mencegah social engineering attack?", "Pencegahan: 1) Skeptis terhadap permintaan info sensitif, 2) Verifikasi identitas lewat channel resmi, 3) Jangan sharing too much info di social media, 4) Edukasi awareness security rutin, 5) Implement policies ketat, 6) Gunakan multi-factor authentication, 7) Report aktivitas mencurigakan."),
    ("Apa itu tailgating?", "Tailgating (piggybacking) adalah masuk ke area restricted dengan mengikuti orang authorized tanpa proper authentication sendiri. Contoh: mengikut masuk pintu yang memerlukan access card dengan alasan 'lupa kartu'. Proteksi: enforce security policy ketat, gunakan mantraps, security awareness training."),
    ("Jelaskan tentang quid pro quo attack", "Quid pro quo adalah social engineering yang menawarkan layanan/benefit sebagai imbalan informasi. Contoh umum: attacker menelepon berpura-pura dari IT support menawarkan bantuan teknis, kemudian meminta akses remote atau credentials. Selalu verifikasi dengan IT dept langsung jika ada penawaran tak diminta."),
    ("Apa bahaya oversharing di social media?", "Oversharing berbahaya karena attacker bisa: 1) Build profile lengkap untuk spear phishing, 2) Jawaban security questions (nama hewan, kota lahir, dll), 3) Tahu kapan rumah kosong (vacation posts), 4) Pretexting lebih meyakinkan dengan info personal. Batasi info publik, careful dengan apa yang dipost."),
    ("Bagaimana mengenali social engineering?", "Red flags: 1) Urgency berlebihan ('lakukan sekarang!'), 2) Permintaan info sensitif tanpa prosedur normal, 3) Offer too good to be true, 4) Sender/caller tidak bisa diverifikasi, 5) Tekanan emosional (takut, bersalah, keserakahan), 6) Komunikasi mencurigakan (typo, grammar buruk). Trust your instinct!"),
    ("Apa itu shoulder surfing?", "Shoulder surfing adalah teknik mengintip layar atau keyboard orang lain untuk mencuri informasi seperti password, PIN, atau data sensitif. Bisa terjadi di tempat umum, ATM, kafe. Proteksi: gunakan privacy screen, aware dengan sekitar saat input sensitif info, posisikan body untuk block view."),
    ("Jelaskan tentang impersonation attack", "Impersonation adalah berpura-pura menjadi orang lain (authority figure, kolega, vendor) untuk mendapat trust dan informasi. Bisa via email, telepon, atau in-person. Contoh: email dari 'CEO' minta transfer dana urgent. Selalu verifikasi permintaan unusual melalui channel alternatif yang terpercaya."),
]

for text, response in social_engineering_data:
    dataset['intent'].append('social_engineering')
    dataset['text'].append(text)
    dataset['response'].append(response)

# 9. INCIDENT RESPONSE
incident_response_data = [
    ("Apa itu incident response?", "Incident response adalah pendekatan terstruktur untuk menangani dan mengelola security breach atau cyber attack. Tujuan: minimize damage, reduce recovery time and cost, dan learn dari insiden. Meliputi: preparation, detection, containment, eradication, recovery, dan post-incident review."),
    ("Jelaskan tahapan incident response", "6 tahapan: 1) Preparation - siapkan tools, team, prosedur, 2) Identification - deteksi dan konfirmasi insiden, 3) Containment - isolasi untuk stop penyebaran, 4) Eradication - hapus ancaman dari sistem, 5) Recovery - restore ke operasi normal, 6) Lessons Learned - analisis dan improve. Framework: NIST, SANS."),
    ("Apa yang dilakukan saat terdeteksi security breach?", "Langkah immediate: 1) Jangan panik, dokumentasikan semua, 2) Isolasi sistem terinfeksi dari network, 3) Preserve evidence untuk forensik, 4) Notify incident response team, 5) Assess scope dan severity, 6) Activate incident response plan, 7) Komunikasi ke stakeholders sesuai protocol, 8) Begin containment dan remediation."),
    ("Apa itu forensik digital?", "Forensik digital adalah proses mengidentifikasi, preserve, analyze, dan present digital evidence dari insiden security. Tujuan: understand what happened, how, when, who. Meliputi: disk forensics, memory forensics, network forensics, malware analysis. Penting untuk legal proceedings dan improve security posture."),
    ("Bagaimana membuat incident response plan?", "Komponen IRP: 1) Roles & responsibilities tim, 2) Communication plan internal/eksternal, 3) Incident classification matrix, 4) Response procedures per incident type, 5) Contact list emergency, 6) Tools & resources, 7) Legal & compliance requirements, 8) Post-incident review process. Test dan update regularly."),
    ("Apa itu containment strategy?", "Containment bertujuan stop damage dan prevent spread. Jenis: 1) Short-term containment - quick action (disconnect network, shutdown sistem), 2) Long-term containment - sementara perbaikan sistem (patch, rebuild). Trade-off: kecepatan vs preserve evidence. Dokumentasi penting untuk forensik."),
    ("Kenapa perlu incident response team?", "IRT penting karena: 1) Response cepat dan terkoordinasi, 2) Minimize downtime dan damage, 3) Proper evidence preservation, 4) Effective communication stakeholders, 5) Compliance dengan regulations, 6) Learn dan improve defenses. Team harus multidisciplinary: IT, security, legal, PR, management."),
    ("Apa yang dilakukan di tahap recovery?", "Recovery activities: 1) Restore systems dari clean backups, 2) Rebuild compromised systems, 3) Apply patches dan security updates, 4) Strengthen defenses (change passwords, update rules), 5) Monitor closely untuk reinfection, 6) Gradual return to normal ops, 7) Verify system integrity dan functionality."),
    ("Bagaimana komunikasi saat insiden security?", "Komunikasi harus: 1) Clear, accurate, timely, 2) Follow communication plan, 3) Internal: notify management, affected teams, 4) External: customers jika affected, law enforcement jika required, media jika needed, 5) Protect sensitive info, 6) Provide updates regular, 7) Post-incident summary. Transparency penting untuk trust."),
    ("Apa itu lessons learned dalam incident response?", "Lessons learned adalah post-incident review untuk: 1) Analyze apa yang terjadi, 2) Evaluate response effectiveness, 3) Identify improvements diperlukan, 4) Update policies, procedures, tools, 5) Training tambahan, 6) Share knowledge dengan team. Goal: prevent similar incidents, improve response capability. Dokumentasi penting."),
]

for text, response in incident_response_data:
    dataset['intent'].append('incident_response')
    dataset['text'].append(text)
    dataset['response'].append(response)

# 10. THANKS/GOODBYE
thanks_data = [
    ("Terima kasih", "Sama-sama! Senang bisa membantu dengan informasi cybersecurity. Jangan ragu bertanya lagi jika butuh!"),
    ("Thanks", "You're welcome! Stay safe and secure online!"),
    ("Makasih ya", "Sama-sama! Semoga informasinya bermanfaat untuk keamanan digital Anda."),
    ("Sampai jumpa", "Sampai jumpa! Tetap waspada terhadap ancaman siber. Jaga keamanan data Anda!"),
    ("Bye", "Goodbye! Remember to stay vigilant about cybersecurity. See you!"),
    ("Selesai", "Baik! Jika ada pertanyaan lagi tentang cybersecurity, jangan sungkan untuk bertanya. Stay safe!"),
    ("Sudah cukup", "Oke, terima kasih sudah menggunakan layanan chatbot kami. Tetap aman di dunia digital!"),
    ("Ok terima kasih banyak", "Sama-sama! Senang bisa membantu. Jaga selalu keamanan sistem dan data Anda!"),
    ("Oke sip", "Siap! Tetap aware dengan cybersecurity threats. Sampai jumpa!"),
    ("Mantap", "Terima kasih! Jangan lupa apply best practices cybersecurity yang sudah dibahas ya. Stay secure!"),
]

for text, response in thanks_data:
    dataset['intent'].append('thanks')
    dataset['text'].append(text)
    dataset['response'].append(response)

# Buat DataFrame
df = pd.DataFrame(dataset)

# Save ke Excel dengan formatting
wb = Workbook()
ws = wb.active
ws.title = "Chatbot Dataset"

# Header dengan formatting
headers = ['intent', 'text', 'response']
header_fill = PatternFill(start_color='4472C4', end_color='4472C4', fill_type='solid')
header_font = Font(bold=True, color='FFFFFF', size=12)

for col_num, header in enumerate(headers, 1):
    cell = ws.cell(row=1, column=col_num)
    cell.value = header
    cell.fill = header_fill
    cell.font = header_font
    cell.alignment = Alignment(horizontal='center', vertical='center')

# Data
for row_num, row_data in enumerate(df.values, 2):
    for col_num, value in enumerate(row_data, 1):
        cell = ws.cell(row=row_num, column=col_num)
        cell.value = value
        cell.alignment = Alignment(vertical='top', wrap_text=True)

# Set column widths
ws.column_dimensions['A'].width = 20
ws.column_dimensions['B'].width = 50
ws.column_dimensions['C'].width = 80

# Freeze header row
ws.freeze_panes = 'A2'

# Save
wb.save('/home/claude/chatbot-cybersecurity/data/dataset.xlsx')

print(f"Dataset created successfully!")
print(f"Total data: {len(df)} rows")
print(f"\nIntent distribution:")
print(df['intent'].value_counts())
