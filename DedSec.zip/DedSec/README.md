# 🔒 Chatbot Cybersecurity - Machine Learning Project

Chatbot berbasis Machine Learning dan Deep Learning untuk menjawab pertanyaan seputar **Cybersecurity** dalam Bahasa Indonesia.

## 📋 Deskripsi Project

Project ini merupakan implementasi chatbot akademik yang menggunakan:
- **Supervised Learning** dengan algoritma Machine Learning (Naive Bayes, SVM, Random Forest)
- **Deep Learning** menggunakan LSTM (BiDirectional) untuk nilai tambahan
- **Preprocessing teks Bahasa Indonesia** yang lengkap
- **Deployment** menggunakan Streamlit web application

### 🎯 Topik Cybersecurity yang Dicakup:
1. 🎣 **Phishing** - Penipuan digital
2. 🦠 **Malware** - Virus dan software berbahaya
3. 🔑 **Password Security** - Keamanan password
4. 🛡️ **Firewall** - Pertahanan jaringan
5. 🔐 **Encryption** - Enkripsi data
6. 🌐 **Network Security** - Keamanan jaringan
7. 🎭 **Social Engineering** - Manipulasi psikologis
8. 🚨 **Incident Response** - Tanggap insiden
9. 👋 **Greeting & Thanks** - Sapaan dan ucapan terima kasih

## 📁 Struktur Project

```
chatbot-cybersecurity/
├── data/
│   ├── dataset.xlsx              # Dataset utama (100 samples, 10 intents)
│   └── create_dataset.py         # Script untuk generate dataset
├── models/
│   ├── naive_bayes_model.pkl     # Model Naive Bayes
│   ├── svm_model.pkl             # Model SVM
│   ├── random_forest_model.pkl   # Model Random Forest
│   ├── lstm_model.h5             # Model LSTM (Deep Learning)
│   ├── lstm_tokenizer.pkl        # Tokenizer untuk LSTM
│   ├── lstm_metadata.pkl         # Metadata LSTM
│   └── *.png                     # Visualisasi hasil
├── src/
│   ├── preprocessing.py          # Modul preprocessing Bahasa Indonesia
│   ├── train_ml.py              # Training Machine Learning models
│   ├── train_dl.py              # Training Deep Learning model
│   └── evaluate.py              # Evaluasi model
├── deployment/
│   └── app.py                   # Streamlit web application
├── notebooks/
│   └── exploration.ipynb        # Jupyter notebook eksplorasi
├── requirements.txt             # Dependencies
└── README.md                    # Dokumentasi
```

## 🚀 Cara Menjalankan Project

### 1️⃣ Setup Environment

```bash
# Clone atau download project
cd chatbot-cybersecurity

# Install dependencies
pip install -r requirements.txt
```

### 2️⃣ Generate Dataset

```bash
cd data
python create_dataset.py
```

Output: `dataset.xlsx` berisi 100 samples dengan 10 intent.

### 3️⃣ Training Models

#### Machine Learning (Naive Bayes, SVM, Random Forest)
```bash
cd src
python train_ml.py
```

Output:
- 3 model terlatih (`.pkl` files)
- Confusion matrices
- Model comparison chart
- Performance metrics

#### Deep Learning (LSTM)
```bash
cd src
python train_dl.py
```

Output:
- LSTM model (`.h5` file)
- Training history plot
- Confusion matrix
- Performance metrics

### 4️⃣ Deploy Chatbot

```bash
cd deployment
streamlit run app.py
```

Chatbot akan terbuka di browser: `http://localhost:8501`

## 🧪 Preprocessing Pipeline

Preprocessing lengkap untuk Bahasa Indonesia:

1. **Case Folding** - Lowercase semua teks
2. **Remove Punctuation** - Hapus tanda baca
3. **Remove Numbers** - Hapus angka
4. **Text Normalization** - Konversi kata tidak baku ke baku
   - Contoh: "gmn" → "bagaimana", "gak" → "tidak"
5. **Remove Stopwords** - Hapus kata-kata umum
6. **Stemming** - Ambil kata dasar
   - Contoh: "mengamankan" → "aman"

## 🤖 Model Architecture

### Machine Learning
- **Feature Extraction**: TF-IDF Vectorizer
  - Max features: 500
  - N-gram: (1, 2) - unigram dan bigram
- **Algorithms**:
  1. Naive Bayes (Multinomial)
  2. Support Vector Machine (Linear kernel)
  3. Random Forest (100 trees)

### Deep Learning (LSTM)
```
Model: Sequential
_________________________________________________________________
Layer (type)                Output Shape              Param #   
=================================================================
embedding                   (None, 50, 128)           640,000   
bilstm_1                    (None, 50, 128)           98,816    
dropout                     (None, 50, 128)           0         
bilstm_2                    (None, 64)                41,216    
dropout                     (None, 64)                0         
dense_1                     (None, 64)                4,160     
dropout                     (None, 64)                0         
dense_2                     (None, 32)                2,080     
dropout                     (None, 32)                0         
output                      (None, 10)                330       
=================================================================
Total params: 786,602
```

## 📊 Evaluasi Model

Metrics yang digunakan:
- **Accuracy** - Akurasi keseluruhan
- **Precision** - Presisi per class
- **Recall** - Recall per class
- **F1-Score** - Harmonic mean precision & recall
- **Confusion Matrix** - Visualisasi prediksi

### Expected Performance
- Machine Learning: ~85-95% accuracy
- Deep Learning: ~90-98% accuracy

## 💡 Cara Menggunakan Chatbot

1. Buka aplikasi Streamlit
2. Pilih model di sidebar (ML atau DL)
3. Ketik pertanyaan di chat input
4. Bot akan menjawab dengan:
   - Response berdasarkan intent
   - Intent yang terdeteksi
   - Confidence score
   - Visualisasi confidence bar

### Contoh Pertanyaan:
- "Apa itu phishing dan bagaimana cara mencegahnya?"
- "Bagaimana cara membuat password yang kuat?"
- "Jelaskan tentang malware"
- "Apa itu firewall?"
- "Bagaimana cara kerja enkripsi?"

## 📝 Laporan Project

Template laporan (8-10 halaman) mencakup:

### BAB 1: Pendahuluan
- Latar belakang
- Rumusan masalah
- Tujuan penelitian
- Manfaat penelitian

### BAB 2: Tinjauan Pustaka
- Natural Language Processing
- Machine Learning untuk text classification
- Deep Learning (LSTM)
- Cybersecurity fundamentals

### BAB 3: Metodologi
- Dataset dan preprocessing
- Feature extraction (TF-IDF)
- Model architecture
- Training process
- Evaluation metrics

### BAB 4: Hasil dan Pembahasan
- Model performance comparison
- Confusion matrix analysis
- Prediction examples
- Discussion

### BAB 5: Kesimpulan dan Saran
- Kesimpulan
- Keterbatasan
- Saran pengembangan

## 🎥 Video Demo

Buat video 5-7 menit yang menampilkan:
1. Overview project dan dataset
2. Proses preprocessing
3. Training process (ML & DL)
4. Evaluasi dan visualisasi hasil
5. Demo chatbot (berbagai pertanyaan)
6. Penjelasan hasil dan kesimpulan

## 🎓 Kriteria Penilaian

| Komponen | Bobot | Checklist |
|----------|-------|-----------|
| **Dataset & Preprocessing** | 15% | ✅ 100 samples, 10 intents<br>✅ Preprocessing Bahasa Indonesia lengkap<br>✅ Train-test split |
| **Implementasi Model ML** | 25% | ✅ 3 algoritma ML (NB, SVM, RF)<br>✅ TF-IDF feature extraction<br>✅ Model training & saving |
| **Evaluasi & Analisis** | 20% | ✅ Multiple metrics<br>✅ Confusion matrix<br>✅ Model comparison |
| **Laporan** | 25% | ✅ 8-10 halaman<br>✅ Struktur lengkap<br>✅ Analisis mendalam |
| **Demo/Presentasi** | 15% | ✅ Video 5-7 menit<br>✅ Penjelasan jelas |

### 🌟 Nilai Tambahan:
- ✅ **Deep Learning implementation** (LSTM)
- ✅ **Deployment** (Streamlit web app)
- ✅ **Bahasa Indonesia** dengan preprocessing lengkap
- ✅ **Model comparison** dan visualisasi

## 🔧 Troubleshooting

### Error: TensorFlow not found
```bash
pip install tensorflow==2.13.0
```

### Error: Streamlit not found
```bash
pip install streamlit
```

### Error: Dataset not found
Pastikan file `dataset.xlsx` ada di folder `data/`

## 📚 Referensi

1. Scikit-learn Documentation
2. TensorFlow/Keras Documentation
3. NLTK and Text Preprocessing
4. Cybersecurity Best Practices

## 👨‍💻 Author

**[Nama Anda]**
- Program Studi: [Program Studi]
- NIM: [NIM]
- Email: [Email]

## 📄 License

Project ini dibuat untuk keperluan akademik.

---

**Happy Learning! 🎓🔒**
