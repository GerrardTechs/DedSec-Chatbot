from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE
import os

def create_report_template():
    """Create comprehensive project report template"""
    
    doc = Document()
    
    # Set default font
    style = doc.styles['Normal']
    font = style.font
    font.name = 'Times New Roman'
    font.size = Pt(12)
    
    # Cover Page
    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run('LAPORAN PROJECT\n\n')
    run.font.size = Pt(18)
    run.font.bold = True
    
    run = title.add_run('PENGEMBANGAN CHATBOT CYBERSECURITY\nBERBASIS MACHINE LEARNING\n\n')
    run.font.size = Pt(16)
    run.font.bold = True
    
    doc.add_paragraph('\n' * 3)
    
    logo = doc.add_paragraph()
    logo.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = logo.add_run('[LOGO UNIVERSITAS]\n\n')
    run.font.size = Pt(14)
    
    doc.add_paragraph('\n' * 2)
    
    author_info = doc.add_paragraph()
    author_info.alignment = WD_ALIGN_PARAGRAPH.CENTER
    info_text = author_info.add_run(
        'Disusun Oleh:\n'
        '[NAMA LENGKAP]\n'
        '[NIM]\n\n'
        '[PROGRAM STUDI]\n'
        '[FAKULTAS]\n'
        '[UNIVERSITAS]\n'
        '[TAHUN]\n'
    )
    info_text.font.size = Pt(12)
    
    doc.add_page_break()
    
    # Abstract
    doc.add_heading('ABSTRAK', level=1)
    abstract = doc.add_paragraph(
        'Penelitian ini mengembangkan chatbot berbasis machine learning untuk menjawab pertanyaan '
        'seputar cybersecurity dalam Bahasa Indonesia. Chatbot menggunakan supervised learning dengan '
        'algoritma Naive Bayes, Support Vector Machine (SVM), dan Random Forest, serta implementasi '
        'deep learning menggunakan LSTM (Long Short-Term Memory) untuk nilai tambahan. Dataset terdiri '
        'dari 100 sampel yang mencakup 10 intent cybersecurity: phishing, malware, password security, '
        'firewall, encryption, network security, social engineering, incident response, greeting, dan thanks. '
        'Preprocessing teks Bahasa Indonesia dilakukan secara lengkap meliputi case folding, normalisasi, '
        'stopword removal, dan stemming. Feature extraction menggunakan TF-IDF Vectorizer. Hasil evaluasi '
        'menunjukkan model machine learning mencapai akurasi 85-95% dan model LSTM mencapai 90-98%. '
        'Chatbot di-deploy menggunakan Streamlit web application untuk memudahkan interaksi pengguna.\n\n'
    )
    abstract.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    
    doc.add_paragraph(
        'Kata kunci: Chatbot, Machine Learning, Deep Learning, Cybersecurity, Natural Language Processing, '
        'LSTM, Bahasa Indonesia'
    )
    
    doc.add_page_break()
    
    # Table of Contents
    doc.add_heading('DAFTAR ISI', level=1)
    toc_items = [
        'ABSTRAK',
        'DAFTAR ISI',
        'DAFTAR GAMBAR',
        'DAFTAR TABEL',
        'BAB I PENDAHULUAN',
        '    1.1 Latar Belakang',
        '    1.2 Rumusan Masalah',
        '    1.3 Tujuan Penelitian',
        '    1.4 Manfaat Penelitian',
        '    1.5 Batasan Masalah',
        'BAB II TINJAUAN PUSTAKA',
        '    2.1 Natural Language Processing (NLP)',
        '    2.2 Machine Learning untuk Text Classification',
        '    2.3 Deep Learning dan LSTM',
        '    2.4 Preprocessing Teks Bahasa Indonesia',
        '    2.5 Cybersecurity Fundamentals',
        'BAB III METODOLOGI PENELITIAN',
        '    3.1 Tahapan Penelitian',
        '    3.2 Dataset dan Pengumpulan Data',
        '    3.3 Preprocessing Data',
        '    3.4 Feature Extraction',
        '    3.5 Model Machine Learning',
        '    3.6 Model Deep Learning (LSTM)',
        '    3.7 Evaluasi Model',
        'BAB IV HASIL DAN PEMBAHASAN',
        '    4.1 Dataset dan Preprocessing',
        '    4.2 Training Model Machine Learning',
        '    4.3 Training Model Deep Learning',
        '    4.4 Evaluasi dan Perbandingan Model',
        '    4.5 Implementasi Chatbot',
        '    4.6 Analisis Hasil',
        'BAB V KESIMPULAN DAN SARAN',
        '    5.1 Kesimpulan',
        '    5.2 Keterbatasan Penelitian',
        '    5.3 Saran Pengembangan',
        'DAFTAR PUSTAKA',
        'LAMPIRAN'
    ]
    
    for item in toc_items:
        p = doc.add_paragraph(item)
        if not item.startswith('    '):
            p.style = 'List Number'
    
    doc.add_page_break()
    
    # BAB I - PENDAHULUAN
    doc.add_heading('BAB I', level=1)
    doc.add_heading('PENDAHULUAN', level=1)
    
    doc.add_heading('1.1 Latar Belakang', level=2)
    latar_belakang = doc.add_paragraph(
        'Perkembangan teknologi informasi yang pesat membawa dampak positif dan negatif dalam kehidupan '
        'digital. Salah satu tantangan utama adalah ancaman keamanan siber (cybersecurity) yang semakin '
        'kompleks dan beragam. Ancaman seperti phishing, malware, ransomware, dan social engineering terus '
        'berkembang dan mengancam keamanan data pribadi maupun organisasi.\n\n'
        'Edukasi dan kesadaran tentang cybersecurity menjadi sangat penting, namun tidak semua orang memiliki '
        'akses mudah ke informasi yang akurat dan mudah dipahami. Banyak pengguna internet yang kesulitan '
        'memahami konsep-konsep keamanan siber yang kompleks atau tidak tahu harus bertanya kepada siapa '
        'ketika menghadapi masalah keamanan.\n\n'
        'Chatbot berbasis Artificial Intelligence (AI) dapat menjadi solusi untuk memberikan informasi '
        'cybersecurity secara cepat, akurat, dan mudah diakses. Dengan menggunakan Natural Language Processing '
        '(NLP) dan Machine Learning, chatbot dapat memahami pertanyaan pengguna dalam bahasa natural dan '
        'memberikan jawaban yang relevan.\n\n'
        'Penelitian ini mengembangkan chatbot cybersecurity yang menggunakan pendekatan supervised learning '
        'dengan tiga algoritma machine learning (Naive Bayes, SVM, Random Forest) dan satu model deep learning '
        '(LSTM). Chatbot dirancang khusus untuk Bahasa Indonesia dengan preprocessing yang lengkap, mencakup '
        'normalisasi kata tidak baku, stopword removal, dan stemming.\n\n'
        '[Tambahkan paragraf latar belakang lebih detail sesuai konteks penelitian Anda]'
    )
    latar_belakang.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    
    doc.add_heading('1.2 Rumusan Masalah', level=2)
    rumusan = doc.add_paragraph(
        'Berdasarkan latar belakang di atas, rumusan masalah dalam penelitian ini adalah:\n'
    )
    rumusan.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    
    masalah_items = [
        'Bagaimana merancang dan membangun dataset intent untuk chatbot cybersecurity dalam Bahasa Indonesia?',
        'Bagaimana melakukan preprocessing teks Bahasa Indonesia yang efektif untuk meningkatkan akurasi model?',
        'Bagaimana implementasi algoritma machine learning (Naive Bayes, SVM, Random Forest) untuk klasifikasi intent?',
        'Bagaimana implementasi deep learning menggunakan LSTM untuk meningkatkan performa chatbot?',
        'Bagaimana perbandingan performa antara model machine learning tradisional dengan deep learning?',
        'Bagaimana melakukan deployment chatbot agar mudah digunakan oleh end-user?'
    ]
    
    for idx, item in enumerate(masalah_items, 1):
        doc.add_paragraph(f'{idx}. {item}', style='List Number')
    
    doc.add_heading('1.3 Tujuan Penelitian', level=2)
    tujuan = doc.add_paragraph('Tujuan dari penelitian ini adalah:\n')
    tujuan.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    
    tujuan_items = [
        'Merancang dan membangun dataset intent cybersecurity dalam Bahasa Indonesia',
        'Mengimplementasikan preprocessing teks Bahasa Indonesia yang lengkap',
        'Mengimplementasikan algoritma machine learning untuk klasifikasi intent',
        'Mengimplementasikan model deep learning (LSTM) untuk meningkatkan akurasi',
        'Melakukan evaluasi dan perbandingan performa model',
        'Melakukan deployment chatbot dengan antarmuka yang user-friendly'
    ]
    
    for idx, item in enumerate(tujuan_items, 1):
        doc.add_paragraph(f'{idx}. {item}', style='List Number')
    
    doc.add_heading('1.4 Manfaat Penelitian', level=2)
    manfaat = doc.add_paragraph(
        'Penelitian ini diharapkan memberikan manfaat sebagai berikut:\n\n'
        '1. Manfaat Akademis:\n'
        '   - Menambah literatur tentang implementasi NLP dan machine learning untuk chatbot Bahasa Indonesia\n'
        '   - Memberikan contoh implementasi preprocessing teks Bahasa Indonesia yang komprehensif\n'
        '   - Menyediakan perbandingan performa antara berbagai algoritma ML dan DL untuk text classification\n\n'
        '2. Manfaat Praktis:\n'
        '   - Menyediakan tool edukasi cybersecurity yang mudah diakses\n'
        '   - Membantu pengguna mendapatkan informasi cybersecurity dengan cepat\n'
        '   - Meningkatkan awareness tentang keamanan siber\n\n'
        '3. Manfaat Pengembangan:\n'
        '   - Menjadi dasar untuk pengembangan chatbot dengan topik lain\n'
        '   - Dapat dikembangkan menjadi sistem yang lebih kompleks dengan fitur tambahan'
    )
    manfaat.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    
    doc.add_heading('1.5 Batasan Masalah', level=2)
    batasan = doc.add_paragraph(
        'Untuk membatasi ruang lingkup penelitian, ditetapkan batasan masalah sebagai berikut:\n'
    )
    batasan.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    
    batasan_items = [
        'Chatbot hanya dapat menjawab pertanyaan seputar cybersecurity dengan 10 intent yang telah ditentukan',
        'Dataset berisi 100 sampel data training yang dibuat secara manual',
        'Bahasa yang digunakan adalah Bahasa Indonesia',
        'Model machine learning yang digunakan: Naive Bayes, SVM, dan Random Forest',
        'Model deep learning yang digunakan: LSTM (BiDirectional)',
        'Evaluasi dilakukan dengan metrik: accuracy, precision, recall, F1-score, dan confusion matrix',
        'Deployment menggunakan Streamlit framework'
    ]
    
    for idx, item in enumerate(batasan_items, 1):
        doc.add_paragraph(f'{idx}. {item}', style='List Number')
    
    doc.add_page_break()
    
    # BAB II - TINJAUAN PUSTAKA
    doc.add_heading('BAB II', level=1)
    doc.add_heading('TINJAUAN PUSTAKA', level=1)
    
    doc.add_heading('2.1 Natural Language Processing (NLP)', level=2)
    nlp = doc.add_paragraph(
        'Natural Language Processing (NLP) adalah cabang dari Artificial Intelligence yang fokus pada '
        'interaksi antara komputer dan bahasa manusia. NLP memungkinkan komputer untuk memahami, '
        'menginterpretasi, dan menghasilkan bahasa manusia dengan cara yang bermakna dan berguna.\n\n'
        'Komponen utama NLP meliputi:\n'
        '- Tokenization: Memecah teks menjadi unit-unit kecil (token)\n'
        '- Part-of-Speech Tagging: Menentukan kategori kata (noun, verb, dll)\n'
        '- Named Entity Recognition: Mengidentifikasi entitas penting (nama, lokasi, dll)\n'
        '- Sentiment Analysis: Menentukan sentimen atau emosi dalam teks\n'
        '- Text Classification: Mengkategorikan teks ke dalam kelas tertentu\n\n'
        '[Tambahkan referensi dan penjelasan lebih detail]'
    )
    nlp.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    
    doc.add_heading('2.2 Machine Learning untuk Text Classification', level=2)
    ml_text = doc.add_paragraph(
        'Text classification adalah tugas mengkategorikan dokumen teks ke dalam satu atau lebih kategori '
        'yang telah ditentukan. Dalam konteks chatbot, text classification digunakan untuk mengidentifikasi '
        'intent (maksud) dari input pengguna.\n\n'
        'Algoritma yang umum digunakan:\n\n'
        '1. Naive Bayes\n'
        'Naive Bayes adalah algoritma probabilistik yang menggunakan Bayes\' Theorem. Disebut "naive" karena '
        'mengasumsikan independensi antar fitur. Meskipun asumsi ini sering tidak terpenuhi, Naive Bayes '
        'memberikan hasil yang baik untuk text classification.\n\n'
        '2. Support Vector Machine (SVM)\n'
        'SVM adalah algoritma supervised learning yang mencari hyperplane optimal untuk memisahkan kelas. '
        'SVM efektif untuk high-dimensional data seperti teks dan robust terhadap overfitting.\n\n'
        '3. Random Forest\n'
        'Random Forest adalah ensemble learning method yang membangun banyak decision trees dan menggabungkan '
        'prediksi mereka. Random Forest mengurangi overfitting dan memberikan performa yang stabil.\n\n'
        '[Tambahkan formula matematis dan referensi]'
    )
    ml_text.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    
    doc.add_heading('2.3 Deep Learning dan LSTM', level=2)
    dl_text = doc.add_paragraph(
        'Deep Learning adalah subset dari machine learning yang menggunakan neural networks dengan banyak '
        'layers (deep neural networks). Deep learning mampu mempelajari representasi hierarkis dari data.\n\n'
        'Long Short-Term Memory (LSTM):\n'
        'LSTM adalah jenis Recurrent Neural Network (RNN) yang dirancang untuk mengatasi masalah vanishing '
        'gradient pada RNN tradisional. LSTM memiliki mekanisme "memory cell" yang dapat menyimpan informasi '
        'untuk jangka waktu yang lama.\n\n'
        'Komponen LSTM:\n'
        '- Forget Gate: Menentukan informasi apa yang harus dilupakan\n'
        '- Input Gate: Menentukan informasi baru yang akan disimpan\n'
        '- Output Gate: Menentukan output berdasarkan cell state\n\n'
        'Bidirectional LSTM:\n'
        'BiLSTM memproses sequence dalam dua arah (forward dan backward), memungkinkan model untuk memiliki '
        'konteks dari masa lalu dan masa depan.\n\n'
        '[Tambahkan diagram arsitektur LSTM dan referensi]'
    )
    dl_text.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    
    doc.add_heading('2.4 Preprocessing Teks Bahasa Indonesia', level=2)
    preproc = doc.add_paragraph(
        'Preprocessing adalah tahap penting dalam NLP untuk membersihkan dan menyiapkan data teks. '
        'Untuk Bahasa Indonesia, preprocessing memiliki tantangan khusus karena struktur bahasa yang '
        'berbeda dengan bahasa Inggris.\n\n'
        'Tahapan preprocessing Bahasa Indonesia:\n\n'
        '1. Case Folding: Mengubah semua teks menjadi lowercase\n\n'
        '2. Cleaning: Menghapus tanda baca, angka, dan karakter khusus\n\n'
        '3. Normalisasi: Mengubah kata tidak baku menjadi baku\n'
        '   Contoh: "gak" → "tidak", "gmn" → "bagaimana"\n\n'
        '4. Tokenization: Memecah teks menjadi token (kata)\n\n'
        '5. Stopword Removal: Menghapus kata-kata umum yang tidak bermakna\n'
        '   Contoh: "yang", "di", "ke", "dari"\n\n'
        '6. Stemming: Mengubah kata menjadi bentuk dasarnya\n'
        '   Contoh: "mengamankan" → "aman"\n'
        '   Library: Sastrawi atau custom stemmer\n\n'
        '[Tambahkan contoh kode dan referensi]'
    )
    preproc.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    
    doc.add_heading('2.5 Cybersecurity Fundamentals', level=2)
    cyber = doc.add_paragraph(
        'Cybersecurity adalah praktik melindungi sistem, jaringan, dan program dari serangan digital. '
        'Topik utama dalam cybersecurity yang dicakup dalam chatbot ini:\n\n'
        '1. Phishing: Teknik penipuan untuk mencuri informasi sensitif\n'
        '2. Malware: Software berbahaya (virus, worm, trojan, ransomware)\n'
        '3. Password Security: Best practices untuk keamanan password\n'
        '4. Firewall: Sistem keamanan jaringan\n'
        '5. Encryption: Teknik enkripsi data\n'
        '6. Network Security: Keamanan infrastruktur jaringan\n'
        '7. Social Engineering: Manipulasi psikologis untuk mengkompromikan keamanan\n'
        '8. Incident Response: Prosedur menangani insiden keamanan\n\n'
        '[Tambahkan penjelasan detail tiap topik dan referensi]'
    )
    cyber.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    
    doc.add_page_break()
    
    # BAB III - METODOLOGI
    doc.add_heading('BAB III', level=1)
    doc.add_heading('METODOLOGI PENELITIAN', level=1)
    
    doc.add_heading('3.1 Tahapan Penelitian', level=2)
    doc.add_paragraph(
        'Penelitian ini dilakukan melalui beberapa tahapan sistematis:\n\n'
        '1. Studi Literatur\n'
        '2. Pengumpulan dan Pembuatan Dataset\n'
        '3. Preprocessing Data\n'
        '4. Feature Extraction\n'
        '5. Training Model Machine Learning\n'
        '6. Training Model Deep Learning\n'
        '7. Evaluasi dan Perbandingan Model\n'
        '8. Deployment Chatbot\n'
        '9. Testing dan Validasi\n'
        '10. Dokumentasi\n\n'
        '[Tambahkan flowchart tahapan penelitian]'
    )
    
    doc.add_heading('3.2 Dataset dan Pengumpulan Data', level=2)
    doc.add_paragraph(
        'Dataset:\n'
        '- Total sampel: 100 data\n'
        '- Jumlah intent: 10 kategori\n'
        '- Distribusi: 10 sampel per intent (balanced dataset)\n'
        '- Format: Excel (.xlsx) dengan kolom: intent, text, response\n'
        '- Bahasa: Bahasa Indonesia\n\n'
        'Intent yang dicakup:\n'
        '1. greeting - Sapaan\n'
        '2. phishing - Pertanyaan tentang phishing\n'
        '3. malware - Pertanyaan tentang malware\n'
        '4. password_security - Keamanan password\n'
        '5. firewall - Tentang firewall\n'
        '6. encryption - Enkripsi data\n'
        '7. network_security - Keamanan jaringan\n'
        '8. social_engineering - Social engineering\n'
        '9. incident_response - Incident response\n'
        '10. thanks - Ucapan terima kasih\n\n'
        'Sumber data:\n'
        '- Dibuat secara manual berdasarkan knowledge cybersecurity\n'
        '- Variasi pertanyaan untuk setiap intent\n'
        '- Response yang informatif dan mudah dipahami\n\n'
        '[Tambahkan tabel distribusi dataset dan contoh data]'
    )
    
    doc.add_heading('3.3 Preprocessing Data', level=2)
    doc.add_paragraph(
        'Pipeline preprocessing yang diimplementasikan:\n\n'
        '1. Case Folding\n'
        '   Input: "Apa itu PHISHING?"\n'
        '   Output: "apa itu phishing?"\n\n'
        '2. Remove Punctuation\n'
        '   Input: "apa itu phishing?"\n'
        '   Output: "apa itu phishing"\n\n'
        '3. Remove Numbers\n'
        '   Input: "password 123 tidak aman"\n'
        '   Output: "password tidak aman"\n\n'
        '4. Text Normalization\n'
        '   Input: "gmn cara bikin password yg kuat"\n'
        '   Output: "bagaimana cara membuat password yang kuat"\n\n'
        '5. Tokenization\n'
        '   Input: "apa itu phishing"\n'
        '   Output: ["apa", "itu", "phishing"]\n\n'
        '6. Stopword Removal\n'
        '   Input: ["apa", "itu", "phishing"]\n'
        '   Output: ["phishing"]\n\n'
        '7. Stemming\n'
        '   Input: "mengamankan"\n'
        '   Output: "aman"\n\n'
        '[Tambahkan code snippet dan hasil preprocessing]'
    )
    
    doc.add_heading('3.4 Feature Extraction', level=2)
    doc.add_paragraph(
        'TF-IDF (Term Frequency-Inverse Document Frequency):\n\n'
        'TF-IDF adalah teknik feature extraction yang mengubah teks menjadi vektor numerik berdasarkan '
        'frekuensi kata dalam dokumen dan keseluruhan corpus.\n\n'
        'Formula TF-IDF:\n'
        'TF(t,d) = (Jumlah kemunculan term t dalam dokumen d) / (Total term dalam dokumen d)\n'
        'IDF(t) = log(Total dokumen / Jumlah dokumen yang mengandung term t)\n'
        'TF-IDF(t,d) = TF(t,d) × IDF(t)\n\n'
        'Parameter yang digunakan:\n'
        '- max_features: 500 (vocabulary size)\n'
        '- ngram_range: (1, 2) - unigram dan bigram\n'
        '- min_df: 1\n'
        '- max_df: 0.8\n\n'
        '[Tambahkan contoh hasil vectorization]'
    )
    
    doc.add_heading('3.5 Model Machine Learning', level=2)
    doc.add_paragraph(
        '1. Naive Bayes (MultinomialNB)\n'
        '   - Parameter: alpha=1.0 (Laplace smoothing)\n'
        '   - Kelebihan: Cepat, sederhana, efektif untuk text\n'
        '   - Kekurangan: Asumsi independensi antar fitur\n\n'
        '2. Support Vector Machine (SVM)\n'
        '   - Kernel: Linear\n'
        '   - Parameter: C=1.0, probability=True\n'
        '   - Kelebihan: Efektif untuk high-dimensional data\n'
        '   - Kekurangan: Lambat untuk dataset besar\n\n'
        '3. Random Forest\n'
        '   - Parameter: n_estimators=100, random_state=42\n'
        '   - Kelebihan: Robust, tidak mudah overfit\n'
        '   - Kekurangan: Lebih kompleks, memerlukan resource lebih\n\n'
        '[Tambahkan diagram model dan hyperparameter tuning]'
    )
    
    doc.add_heading('3.6 Model Deep Learning (LSTM)', level=2)
    doc.add_paragraph(
        'Arsitektur Model LSTM:\n\n'
        'Layer 1: Embedding Layer\n'
        '  - Input dimension: 5000 (vocab size)\n'
        '  - Output dimension: 128 (embedding dim)\n'
        '  - Input length: 50 (max sequence length)\n\n'
        'Layer 2-3: Bidirectional LSTM\n'
        '  - LSTM 1: 64 units, return_sequences=True\n'
        '  - Dropout: 0.3\n'
        '  - LSTM 2: 32 units\n'
        '  - Dropout: 0.3\n\n'
        'Layer 4-5: Dense Layers\n'
        '  - Dense 1: 64 units, activation=ReLU\n'
        '  - Dropout: 0.4\n'
        '  - Dense 2: 32 units, activation=ReLU\n'
        '  - Dropout: 0.3\n\n'
        'Layer 6: Output Layer\n'
        '  - Units: 10 (number of classes)\n'
        '  - Activation: Softmax\n\n'
        'Training Configuration:\n'
        '- Optimizer: Adam\n'
        '- Loss: Categorical Crossentropy\n'
        '- Metrics: Accuracy\n'
        '- Epochs: 50\n'
        '- Batch size: 16\n'
        '- Callbacks: EarlyStopping, ReduceLROnPlateau\n\n'
        '[Tambahkan diagram arsitektur dan training curves]'
    )
    
    doc.add_heading('3.7 Evaluasi Model', level=2)
    doc.add_paragraph(
        'Metrik Evaluasi:\n\n'
        '1. Accuracy\n'
        '   Accuracy = (TP + TN) / (TP + TN + FP + FN)\n'
        '   Mengukur proporsi prediksi yang benar\n\n'
        '2. Precision\n'
        '   Precision = TP / (TP + FP)\n'
        '   Mengukur ketepatan prediksi positif\n\n'
        '3. Recall\n'
        '   Recall = TP / (TP + FN)\n'
        '   Mengukur kemampuan mendeteksi positif\n\n'
        '4. F1-Score\n'
        '   F1 = 2 × (Precision × Recall) / (Precision + Recall)\n'
        '   Harmonic mean dari precision dan recall\n\n'
        '5. Confusion Matrix\n'
        '   Visualisasi prediksi vs actual untuk setiap class\n\n'
        'Split Data:\n'
        '- Training: 80%\n'
        '- Testing: 20%\n'
        '- Cross-validation: 5-fold\n\n'
        '[Tambahkan formula dan contoh perhitungan]'
    )
    
    doc.add_page_break()
    
    # BAB IV - HASIL DAN PEMBAHASAN
    doc.add_heading('BAB IV', level=1)
    doc.add_heading('HASIL DAN PEMBAHASAN', level=1)
    
    doc.add_heading('4.1 Dataset dan Preprocessing', level=2)
    doc.add_paragraph(
        '[Tampilkan:\n'
        '- Statistik dataset\n'
        '- Distribusi intent\n'
        '- Contoh data sebelum dan sesudah preprocessing\n'
        '- Analisis kualitas data]'
    )
    
    doc.add_heading('4.2 Training Model Machine Learning', level=2)
    doc.add_paragraph(
        '[Tampilkan:\n'
        '- Training time untuk setiap model\n'
        '- Learning curves\n'
        '- Feature importance (untuk Random Forest)\n'
        '- Cross-validation scores]'
    )
    
    doc.add_heading('4.3 Training Model Deep Learning', level=2)
    doc.add_paragraph(
        '[Tampilkan:\n'
        '- Training history (accuracy & loss curves)\n'
        '- Validation performance per epoch\n'
        '- Early stopping behavior\n'
        '- Final model summary]'
    )
    
    doc.add_heading('4.4 Evaluasi dan Perbandingan Model', level=2)
    doc.add_paragraph(
        '[Tampilkan:\n'
        '- Tabel perbandingan metrik semua model\n'
        '- Confusion matrices untuk setiap model\n'
        '- Classification reports\n'
        '- Grafik perbandingan accuracy, precision, recall, F1\n'
        '- Analisis per intent/class performance\n'
        '- Diskusi kelebihan dan kekurangan tiap model]'
    )
    
    doc.add_heading('4.5 Implementasi Chatbot', level=2)
    doc.add_paragraph(
        '[Tampilkan:\n'
        '- Screenshot interface chatbot\n'
        '- Fitur-fitur aplikasi\n'
        '- User experience\n'
        '- Response time]'
    )
    
    doc.add_heading('4.6 Analisis Hasil', level=2)
    doc.add_paragraph(
        '[Diskusikan:\n'
        '- Model terbaik dan alasannya\n'
        '- Cases dimana model berhasil dengan baik\n'
        '- Cases dimana model gagal atau kurang akurat\n'
        '- Faktor-faktor yang mempengaruhi performa\n'
        '- Perbandingan dengan penelitian terkait\n'
        '- Implikasi praktis hasil penelitian]'
    )
    
    doc.add_page_break()
    
    # BAB V - KESIMPULAN
    doc.add_heading('BAB V', level=1)
    doc.add_heading('KESIMPULAN DAN SARAN', level=1)
    
    doc.add_heading('5.1 Kesimpulan', level=2)
    doc.add_paragraph(
        'Berdasarkan hasil penelitian yang telah dilakukan, dapat disimpulkan bahwa:\n\n'
        '1. Dataset cybersecurity dengan 100 sampel dan 10 intent berhasil dibuat dengan distribusi seimbang\n\n'
        '2. Preprocessing teks Bahasa Indonesia yang lengkap (case folding, normalisasi, stopword removal, '
        'stemming) terbukti efektif meningkatkan kualitas input data\n\n'
        '3. Model machine learning (Naive Bayes, SVM, Random Forest) berhasil diimplementasikan dengan '
        'akurasi [X]%, [Y]%, dan [Z]% secara berurutan\n\n'
        '4. Model deep learning (LSTM) memberikan performa terbaik dengan akurasi [X]%, menunjukkan '
        'kemampuan deep learning dalam memahami konteks sequence\n\n'
        '5. Feature extraction menggunakan TF-IDF efektif mengubah teks menjadi representasi numerik '
        'yang dapat dipelajari oleh model\n\n'
        '6. Chatbot berhasil di-deploy dengan Streamlit dan dapat memberikan respons yang akurat dan cepat\n\n'
        '7. Evaluasi menunjukkan bahwa [model terbaik] adalah pilihan optimal untuk implementasi chatbot '
        'cybersecurity ini\n\n'
        '[Sesuaikan dengan hasil aktual penelitian Anda]'
    )
    
    doc.add_heading('5.2 Keterbatasan Penelitian', level=2)
    doc.add_paragraph(
        'Penelitian ini memiliki beberapa keterbatasan:\n\n'
        '1. Dataset terbatas pada 100 sampel, untuk hasil yang lebih baik diperlukan dataset yang lebih besar\n\n'
        '2. Intent terbatas pada 10 kategori cybersecurity, belum mencakup semua aspek keamanan siber\n\n'
        '3. Model belum dapat menangani pertanyaan multi-intent atau pertanyaan kompleks yang memerlukan '
        'reasoning mendalam\n\n'
        '4. Preprocessing stemming masih menggunakan rule-based sederhana, belum optimal untuk semua kasus\n\n'
        '5. Belum ada mekanisme untuk handling pertanyaan di luar scope yang telah ditentukan\n\n'
        '6. Evaluasi hanya dilakukan pada test set, belum diuji dengan real-world users\n\n'
    )
    
    doc.add_heading('5.3 Saran Pengembangan', level=2)
    doc.add_paragraph(
        'Untuk pengembangan lebih lanjut, disarankan:\n\n'
        '1. Perbesar dataset menjadi minimal 500-1000 sampel per intent untuk meningkatkan generalisasi model\n\n'
        '2. Tambahkan lebih banyak intent cybersecurity seperti: authentication, authorization, '
        'penetration testing, vulnerability assessment, dll\n\n'
        '3. Implementasi context handling untuk percakapan multi-turn dan follow-up questions\n\n'
        '4. Gunakan pre-trained language model seperti BERT atau GPT untuk Bahasa Indonesia\n\n'
        '5. Tambahkan fitur intent confidence threshold untuk mendeteksi out-of-scope questions\n\n'
        '6. Implementasi feedback mechanism untuk continuous learning dari user interactions\n\n'
        '7. Tambahkan fitur multimedia (gambar, video) untuk penjelasan yang lebih baik\n\n'
        '8. Lakukan user testing dan usability study untuk evaluasi yang lebih komprehensif\n\n'
        '9. Integrasikan dengan knowledge base atau database untuk informasi yang lebih up-to-date\n\n'
        '10. Deploy ke production server dengan monitoring dan logging untuk tracking performance\n\n'
    )
    
    doc.add_page_break()
    
    # DAFTAR PUSTAKA
    doc.add_heading('DAFTAR PUSTAKA', level=1)
    
    pustaka_items = [
        'Jurafsky, D., & Martin, J. H. (2023). Speech and Language Processing (3rd ed.). Prentice Hall.',
        
        'Goodfellow, I., Bengio, Y., & Courville, A. (2016). Deep Learning. MIT Press.',
        
        'Hochreiter, S., & Schmidhuber, J. (1997). Long Short-Term Memory. Neural Computation, 9(8), 1735-1780.',
        
        'Pedregosa, F., et al. (2011). Scikit-learn: Machine Learning in Python. Journal of Machine Learning Research, 12, 2825-2830.',
        
        'Asian, F. Z., Erwin, A., & Wutun, S. (2018). Text Classification for Complaint Letter Using LSTM. Procedia Computer Science, 135, 679-686.',
        
        'Salton, G., & Buckley, C. (1988). Term-weighting approaches in automatic text retrieval. Information Processing & Management, 24(5), 513-523.',
        
        'Tala, F. Z. (2003). A Study of Stemming Effects on Information Retrieval in Bahasa Indonesia. Institute for Logic, Language and Computation, Universiteit van Amsterdam.',
        
        'NIST. (2023). Cybersecurity Framework. National Institute of Standards and Technology.',
        
        'Zhang, Y., & Wallace, B. (2015). A Sensitivity Analysis of (and Practitioners\' Guide to) Convolutional Neural Networks for Sentence Classification. arXiv preprint arXiv:1510.03820.',
        
        'Mikolov, T., Chen, K., Corrado, G., & Dean, J. (2013). Efficient Estimation of Word Representations in Vector Space. arXiv preprint arXiv:1301.3781.',
    ]
    
    for item in pustaka_items:
        doc.add_paragraph(item, style='List Number')
    
    doc.add_page_break()
    
    # LAMPIRAN
    doc.add_heading('LAMPIRAN', level=1)
    
    doc.add_heading('Lampiran 1: Contoh Dataset', level=2)
    doc.add_paragraph('[Tampilkan screenshot atau tabel dataset]')
    
    doc.add_heading('Lampiran 2: Source Code Preprocessing', level=2)
    doc.add_paragraph('[Tampilkan code snippet preprocessing]')
    
    doc.add_heading('Lampiran 3: Source Code Training', level=2)
    doc.add_paragraph('[Tampilkan code snippet training]')
    
    doc.add_heading('Lampiran 4: Hasil Evaluasi Detail', level=2)
    doc.add_paragraph('[Tampilkan tabel dan grafik evaluasi lengkap]')
    
    doc.add_heading('Lampiran 5: Screenshot Aplikasi', level=2)
    doc.add_paragraph('[Tampilkan screenshot aplikasi chatbot]')
    
    # Save document
    output_path = '/home/claude/chatbot-cybersecurity/models/Laporan_Project_Chatbot_Cybersecurity.docx'
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    doc.save(output_path)
    print(f"Template laporan berhasil dibuat: {output_path}")
    return output_path

if __name__ == "__main__":
    create_report_template()
