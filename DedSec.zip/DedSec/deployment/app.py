"""
Chatbot Cybersecurity - ULTIMATE FIX
Compatible dengan model yang di-retrain dengan better preprocessing
"""

import streamlit as st
import pickle
import pandas as pd
import os
import sys

# Setup paths
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)

# Page config
st.set_page_config(
    page_title="Chatbot Cybersecurity",
    page_icon="🔒",
    layout="centered"
)

# CSS
st.markdown("""
<style>
    .stChatMessage {
        padding: 1rem;
        border-radius: 0.5rem;
    }
    .intent-badge {
        display: inline-block;
        padding: 0.4rem 0.8rem;
        border-radius: 1rem;
        font-size: 0.85rem;
        font-weight: bold;
        margin-top: 0.5rem;
    }
    .confidence-high { background: #4caf50; color: white; }
    .confidence-med { background: #ff9800; color: white; }
    .confidence-low { background: #f44336; color: white; }
</style>
""", unsafe_allow_html=True)

st.title("🔒 Chatbot Cybersecurity")
st.caption("Asisten Virtual Keamanan Siber")


@st.cache_resource
def load_model(model_type):
    """Load model"""
    try:
        paths = [
            os.path.join(parent_dir, 'models', f'{model_type}_model.pkl'),
            os.path.join('..', 'models', f'{model_type}_model.pkl'),
            os.path.join('models', f'{model_type}_model.pkl'),
            f'../models/{model_type}_model.pkl',
            f'models/{model_type}_model.pkl'
        ]
        
        for path in paths:
            if os.path.exists(path):
                with open(path, 'rb') as f:
                    model_data = pickle.load(f)
                
                # Check if model has new structure
                if 'vectorizer' in model_data:
                    # New model structure
                    return {
                        'model': model_data['model'],
                        'feature_extractor': model_data['vectorizer'],
                        'label_encoder': model_data['label_encoder'],
                        'preprocessor': model_data['preprocessor']
                    }
                else:
                    # Old model structure
                    return model_data
        
        return None
    except Exception as e:
        st.sidebar.error(f"Error: {str(e)}")
        return None


@st.cache_data
def load_dataset():
    """Load dataset"""
    try:
        paths = [
            os.path.join(parent_dir, 'data', 'dataset.xlsx'),
            '../data/dataset.xlsx',
            'data/dataset.xlsx',
            os.path.join('..', 'data', 'dataset.xlsx')
        ]
        
        for path in paths:
            if os.path.exists(path):
                return pd.read_excel(path)
        return None
    except Exception as e:
        st.error(f"Error: {str(e)}")
        return None


def predict(text, model_data, dataset):
    """Predict intent"""
    try:
        # Get components
        preprocessor = model_data['preprocessor']
        vectorizer = model_data['feature_extractor']
        model = model_data['model']
        label_encoder = model_data['label_encoder']
        
        # Preprocess (using model's preprocessor)
        text_cleaned = preprocessor.preprocess(text)
        
        # Vectorize
        features = vectorizer.transform([text_cleaned])
        
        # Predict
        prediction = model.predict(features)[0]
        probabilities = model.predict_proba(features)[0]
        
        # Get intent
        intent = label_encoder.inverse_transform([prediction])[0]
        confidence = float(probabilities[prediction])
        
        # Get top 3
        top_3_idx = probabilities.argsort()[-3:][::-1]
        top_3 = [
            (label_encoder.inverse_transform([i])[0], float(probabilities[i]))
            for i in top_3_idx
        ]
        
        # Get response
        responses = dataset[dataset['intent'] == intent]['response'].values
        response_text = responses[0] if len(responses) > 0 else "Maaf, tidak ada jawaban."
        
        return intent, confidence, response_text, top_3
        
    except Exception as e:
        return "error", 0.0, f"Error: {str(e)}", []


# Sidebar
with st.sidebar:
    st.header("⚙️ Pengaturan")
    
    model_choice = st.selectbox(
        "Pilih Model",
        ["naive_bayes", "svm", "random_forest"],
        format_func=lambda x: {
            "naive_bayes": "Naive Bayes",
            "svm": "SVM",
            "random_forest": "Random Forest"
        }[x]
    )
    
    st.markdown("---")
    
    # Model info
    model_data = load_model(model_choice)
    if model_data:
        st.success("✅ Model loaded")
        if 'accuracy' in model_data:
            st.metric("Accuracy", f"{model_data['accuracy']:.1%}")
    else:
        st.error("❌ Model not found")
        st.warning("Jalankan: `python retrain_better.py`")
    
    st.markdown("---")
    st.markdown("""
    ### 📚 Topik:
    - 🎣 Phishing
    - 🦠 Malware  
    - 🔑 Password Security
    - 🛡️ Firewall
    - 🔐 Encryption
    - 🌐 Network Security
    - 🎭 Social Engineering
    - 🚨 Incident Response
    """)
    
    if st.button("🗑️ Clear Chat"):
        st.session_state.messages = []
        st.rerun()

# Load dataset
dataset = load_dataset()

if model_data is None or dataset is None:
    st.warning("⚠️ Model atau dataset tidak tersedia")
    st.info("**Langkah perbaikan:**\n1. Jalankan `python retrain_better.py`\n2. Restart aplikasi")
    st.stop()

# Initialize chat
if "messages" not in st.session_state:
    st.session_state.messages = []

# Display messages
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.write(msg["content"])
        
        if msg["role"] == "assistant" and "intent" in msg:
            # Confidence badge
            conf = msg['confidence']
            if conf >= 0.7:
                badge_class = "confidence-high"
                emoji = "🟢"
            elif conf >= 0.4:
                badge_class = "confidence-med"
                emoji = "🟡"
            else:
                badge_class = "confidence-low"
                emoji = "🔴"
            
            st.markdown(f"""
            <div class="intent-badge {badge_class}">
                {emoji} Intent: {msg['intent']} | Confidence: {conf:.1%}
            </div>
            """, unsafe_allow_html=True)
            
            if msg.get('top_3'):
                with st.expander("🔍 Detail Predictions"):
                    for i, (intent, prob) in enumerate(msg['top_3'], 1):
                        st.write(f"{i}. **{intent}**: {prob:.1%}")

# Chat input
if prompt := st.chat_input("Ketik pertanyaan Anda..."):
    # Validate
    if len(prompt.strip()) < 2:
        st.warning("Pertanyaan terlalu pendek")
        st.stop()
    
    # Add user message
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.write(prompt)
    
    # Get response
    with st.spinner("Thinking..."):
        intent, confidence, response, top_3 = predict(prompt, model_data, dataset)
    
    # Add bot message
    st.session_state.messages.append({
        "role": "assistant",
        "content": response,
        "intent": intent,
        "confidence": confidence,
        "top_3": top_3
    })
    
    with st.chat_message("assistant"):
        st.write(response)
        
        # Badge
        if confidence >= 0.7:
            badge_class = "confidence-high"
            emoji = "🟢"
        elif confidence >= 0.4:
            badge_class = "confidence-med"
            emoji = "🟡"
        else:
            badge_class = "confidence-low"
            emoji = "🔴"
        
        st.markdown(f"""
        <div class="intent-badge {badge_class}">
            {emoji} Intent: {intent} | Confidence: {confidence:.1%}
        </div>
        """, unsafe_allow_html=True)
        
        if top_3:
            with st.expander("🔍 Detail Predictions"):
                for i, (int_name, prob) in enumerate(top_3, 1):
                    st.write(f"{i}. **{int_name}**: {prob:.1%}")

# Examples
if len(st.session_state.messages) == 0:
    st.markdown("### 💡 Contoh Pertanyaan:")
    
    examples = [
        "Apa itu phishing?",
        "Bagaimana cara membuat password yang kuat?",
        "Jelaskan tentang malware",
        "Apa itu firewall?",
        "Bagaimana cara kerja enkripsi?",
        "Apa itu social engineering?"
    ]
    
    cols = st.columns(2)
    for idx, ex in enumerate(examples):
        with cols[idx % 2]:
            if st.button(ex, key=f"ex_{idx}", use_container_width=True):
                st.session_state.messages.append({"role": "user", "content": ex})
                st.rerun()

st.markdown("---")
st.caption("🔒 Chatbot Cybersecurity | Powered by Machine Learning")
